# CampFix: reports and approval source

Snapshot: 48fe3b979bdd9398c1c04557b86db65a0c2e9c71
Source: committed Git source matching the last push in this conversation. Local uncommitted edits are excluded.

This is a source reference package for the existing CampFix Laravel project. It is not a standalone installation; runtime configuration, vendor dependencies, uploaded files, and full site assets are not included.

## 1. Report / concern flow

Submit concern -> create/link report -> classify priority -> assign staff -> In Progress -> Resolved.

- app/Http/Controllers/ConcernController.php: store() accepts concerns and creates/links report records.
- app/Http/Controllers/AdminController.php: reports() lists reports; assignReport() assigns maintenance or MIS work; setReportPriority() and setConcernPriority() classify priority.
- app/Http/Controllers/ReportController.php: apiShow() supplies modal/progress data; updateStatus() updates progress and synchronizes the linked concern.
- app/Support/ConcernDecision.php: System Admin can decide all priorities; School Admin can decide urgent or safety-hazard concerns.
- app/Models/Report.php: forOperationalRole() and forDecisionQueue() scope report lists.
- resources/views/admin/reports.blade.php: report table, assignment dialogs, Progress popup and status update requests.
- app/Http/Middleware/RolePrefixMiddleware.php: keeps JSON/POST requests on their registered endpoints; role aliases apply to page navigation.
- app/Http/Controllers/ReopenTicketController.php and app/Services/ReopenTicketService.php: reopening completed tickets.

Key routes in routes/web.php:
- POST /submit-concern
- GET /admin/reports
- POST /admin/report/{id}/assign
- POST /admin/report/{id}/priority
- GET /admin/reports/{report}/modal-data
- POST /reports/{id}/update-status

## 2. Report budget approval flow

Request budget -> pending -> School Admin approves or rejects -> rejected budgets may be revised and resubmitted.
Requested budgets must be approved before resolution; requesting a budget is optional.

- app/Http/Controllers/BudgetApprovalController.php: request(), approve(), reject(), index() and canRequest().
- app/Support/BudgetApprovalSchema.php: budget-field schema support.
- app/Models/Report.php and app/Models/Concern.php: budget fields/status checks.
- app/Notifications/BudgetApprovalNotification.php: approval notifications.
- resources/views/school-admin/budget-approvals.blade.php: School Admin review queue.
- resources/views/admin/reports.blade.php: request budget from Progress.
- database/migrations/2026_09_27_000001_add_budget_approval_to_reports_and_concerns.php: budget fields.
- tests/Feature/BudgetApprovalWorkflowTest.php and BudgetQueueActionsTest.php: behavior checks.

## 3. Facility / event approval flow

Submit facility request -> determine configured approval route -> current approver approves -> move to next approver -> final Approved.
Rejection records the decision and reason. Requests with no configured approvers can be approved immediately. The precise chain depends on configuration and the request.

- app/Http/Controllers/EventRequestController.php: store(), approve(), reject(), adminIndex() and approval notifications.
- app/Models/EventRequest.php: request state and approval behavior.
- app/Models/EventApprovalChain.php, EventIntendedUser.php, EventRequestType.php and EventDepartment.php: approval-chain configuration.
- app/Services/FacilityApprovalProgress.php: approval timeline.
- app/Services/NotificationService.php and app/Notifications/EventRequestApprovalNotification.php: notifications.
- resources/views/events/: requester pages.
- routes/web.php and routes/api.php: endpoint declarations and middleware.
- tests/Feature/FacilityApprovalProgressTest.php: timeline checks.

## Supporting source

Models, services, support helpers, notifications, middleware, migrations and feature tests are included to make the flow easier to follow. AdminController contains other modules too; use the method names above to locate the report code.