<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SupabaseStorage
{
    protected $url;
    protected $key;
    protected $bucket;

    public function __construct()
    {
        // Try integration variables first, fallback to custom variables
        $this->url = config('services.supabase.url') 
            ?? env('NEXT_PUBLIC_SUPABASE_URL') 
            ?? env('SUPABASE_URL');
        
        // Use service_role key from integration or custom variable
        $this->key = config('services.supabase.key') 
            ?? env('SUPABASE_SERVICE_ROLE_KEY') 
            ?? env('SUPABASE_KEY');
        
        $this->bucket = config('services.supabase.bucket', 'concerns');
        
        // Clean up URL - remove https:// if present
        if ($this->url) {
            $this->url = str_replace(['https://', 'http://'], '', $this->url);
        }
    }

    /**
     * Upload file to Supabase Storage
     *
     * @param UploadedFile $file
     * @param string $path
     * @return string|null Public URL of uploaded file or null on failure
     */
    public function upload(UploadedFile $file, string $path): ?string
    {
        ImageUploadSecurity::validate($file);
        try {
            $filename = $path . '/' . ImageUploadSecurity::filename($file);
            
            Log::info('Attempting Supabase upload', [
                'filename' => $filename,
                'url' => $this->url,
                'bucket' => $this->bucket,
                'has_key' => !empty($this->key)
            ]);
            
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->key,
                'Content-Type' => $file->getMimeType(),
            ])->withBody(
                file_get_contents($file->getRealPath()),
                $file->getMimeType()
            )->post("https://{$this->url}/storage/v1/object/{$this->bucket}/{$filename}");

            Log::info('Supabase upload response', [
                'status' => $response->status(),
                'body' => $response->body()
            ]);

            if ($response->successful()) {
                // Return public HTTPS URL
                $publicUrl = "https://{$this->url}/storage/v1/object/public/{$this->bucket}/{$filename}";
                Log::info('Supabase upload successful', ['url' => $publicUrl]);
                return $publicUrl;
            }

            Log::error('Supabase upload failed', [
                'status' => $response->status(),
                'body' => $response->body()
            ]);

            return null;
        } catch (\Exception $e) {
            Log::error('Supabase upload exception: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return null;
        }
    }

    /**
     * Delete file from Supabase Storage
     *
     * @param string $url
     * @return bool
     */
    public function delete(string $url): bool
    {
        try {
            // Extract filename from URL
            $filename = str_replace("https://{$this->url}/storage/v1/object/public/{$this->bucket}/", '', $url);
            
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->key,
            ])->delete("https://{$this->url}/storage/v1/object/{$this->bucket}/{$filename}");

            return $response->successful();
        } catch (\Exception $e) {
            Log::error('Supabase delete exception: ' . $e->getMessage());
            return false;
        }
    }
}
