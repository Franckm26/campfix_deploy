<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('reports', function (Blueprint $table) {
            $table->boolean('is_safety_hazard')->default(false)->after('severity');
        });

        Schema::table('concerns', function (Blueprint $table) {
            $table->boolean('is_safety_hazard')->default(false)->after('priority');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('reports', function (Blueprint $table) {
            $table->dropColumn('is_safety_hazard');
        });

        Schema::table('concerns', function (Blueprint $table) {
            $table->dropColumn('is_safety_hazard');
        });
    }
};
