<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('event_requests', 'requested_rooms')) {
            Schema::table('event_requests', fn (Blueprint $table) => $table->json('requested_rooms')->nullable());
        }
    }

    public function down(): void
    {
        Schema::table('event_requests', fn (Blueprint $table) => $table->dropColumn('requested_rooms'));
    }
};
