﻿@extends('layouts.app')

@section('styles')
<link href="{{ asset('css/admin.css') }}" rel="stylesheet">
<style>
    /* Mobile Responsive Styles */
    @media screen and (max-width: 768px) {
        /* Hide tables on mobile */
        .card-body .table-responsive {
            display: none !important;
        }
        
        /* Show mobile cards */
        .mobile-event-cards {
            display: block !important;
        }
        
        /* Event card styling */
        .event-card {
            background: #fff;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .event-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .event-card-header div {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .event-card-checkbox {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .event-card-ticket {
            font-weight: 600;
            font-size: 14px;
            color: #333;
        }
        
        .event-card-body {
            margin-bottom: 12px;
        }
        
        .event-card-field {
            display: flex;
            margin-bottom: 8px;
            font-size: 13px;
        }
        
        .event-card-label {
            font-weight: 600;
            min-width: 100px;
            color: #666;
        }
        
        .event-card-value {
            color: #333;
            flex: 1;
            word-break: break-word;
        }
        
        .event-card-value a {
            color: #007bff;
            text-decoration: none;
        }
        
        .event-card-value a:hover {
            text-decoration: underline;
        }
        
        .event-card-actions {
            display: flex;
            gap: 8px;
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px solid #e9ecef;
            flex-wrap: wrap;
        }
        
        .event-card-actions .btn {
            flex: 1;
            font-size: 12px;
            min-width: 80px;
        }
        
        .event-card-actions form {
            flex: 1;
            display: flex;
        }
        
        .event-card-actions form .btn {
            width: 100%;
        }
        
        /* Dark mode support */
        [data-bs-theme="dark"] .event-card {
            background: #2d3238;
            border-color: #495057;
        }
        
        [data-bs-theme="dark"] .event-card-header {
            border-bottom-color: #495057;
        }
        
        [data-bs-theme="dark"] .event-card-ticket,
        [data-bs-theme="dark"] .event-card-value {
            color: #e9ecef;
        }
        
        [data-bs-theme="dark"] .event-card-label {
            color: #adb5bd;
        }
        
        [data-bs-theme="dark"] .event-card-actions {
            border-top-color: #495057;
        }
    }
    
    /* Hide mobile cards on desktop */
    .mobile-event-cards {
        display: none;
    }
</style>
@endsection

@section('page_title')
<h2><i class="fas fa-calendar-alt"></i> Facility Requests</h2>
<p>Manage all facility requests</p>
@endsection

@section('content')
@php
    $eventsIndexRoute = auth()->user()->isSystemAdministrator() ? 'superadmin.events' : 'admin.events';
@endphp
<div class="container-fluid px-3">


    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <!-- Event Action Confirmation Modal -->
    <div class="modal fade" id="eventActionModal" tabindex="-1" aria-labelledby="eventActionModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header" id="eventActionModalHeader">
                    <h5 class="modal-title" id="eventActionModalLabel"><i class="fas fa-exclamation-circle"></i> Confirm Action</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p id="eventActionMessage"></p>
                    <div id="eventActionAlert" class="alert d-none"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="eventActionConfirmBtn"><i class="fas fa-check"></i> Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Archive Facility Request Modal -->
    <div class="modal fade" id="archiveEventModal" tabindex="-1" aria-labelledby="archiveEventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="archiveEventModalLabel">Archive Facility Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="archiveEventForm" method="POST">
                    @csrf
                    <div class="modal-body">
                        <input type="hidden" id="archiveEventId" name="event_id" value="">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i> This facility request will be archived and hidden from your active list.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning"><i class="fas fa-archive"></i> Archive</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Facility Request Modal -->
    <div class="modal fade" id="deleteEventModal" tabindex="-1" aria-labelledby="deleteEventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteEventModalLabel">Delete Facility Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="deleteEventForm" method="POST">
                    @csrf
                    <div class="modal-body">
                        <input type="hidden" id="deleteEventId" name="event_id" value="">
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle"></i> This facility request will be moved to deleted. You can restore it later from the Deleted tab.
                        </div>
                        <p class="mb-0">Are you sure you want to delete this facility request?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body py-3">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                <ul class="nav nav-pills mb-0 flex-wrap">
                    <li class="nav-item">
                        <a class="nav-link {{ ($viewType ?? 'pending') == 'pending' ? 'active' : '' }}" href="{{ route($eventsIndexRoute, ['view' => 'pending']) }}">
                            <i class="fas fa-calendar-check"></i> Pending
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ ($viewType ?? '') == 'approved' ? 'active' : '' }}" href="{{ route($eventsIndexRoute, ['view' => 'approved']) }}" style="{{ ($viewType ?? '') == 'approved' ? '' : 'color: #28a745;' }}">
                            <i class="fas fa-check-circle"></i> Approved
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ ($viewType ?? '') == 'finished' ? 'active' : '' }}" href="{{ route($eventsIndexRoute, ['view' => 'finished']) }}" style="{{ ($viewType ?? '') == 'finished' ? '' : 'color: #6f42c1;' }}">
                            <i class="fas fa-flag-checkered"></i> Finished
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ ($viewType ?? '') == 'rejected' ? 'active' : '' }}" href="{{ route($eventsIndexRoute, ['view' => 'rejected']) }}" style="{{ ($viewType ?? '') == 'rejected' ? '' : 'color: #dc3545;' }}">
                            <i class="fas fa-times-circle"></i> Rejected
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ ($viewType ?? '') == 'archives' ? 'active' : '' }}" href="{{ route($eventsIndexRoute, ['view' => 'archives']) }}">
                            <i class="fas fa-archive"></i> Archived
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ ($viewType ?? '') == 'deleted' ? 'active' : '' }}" href="{{ route($eventsIndexRoute, ['view' => 'deleted']) }}" style="color: #dc3545;">
                            <i class="fas fa-trash-alt"></i> Deleted
                        </a>
                    </li>
                </ul>
                <div class="d-flex gap-2 flex-wrap">
                    <a href="{{ route('events.calendar') }}" class="btn btn-info btn-sm">
                        <i class="fas fa-calendar"></i> Calendar View
                    </a>
                </div>
            </div>
            <form method="GET" action="{{ route($eventsIndexRoute) }}">
                <input type="hidden" name="view" value="{{ $viewType ?? 'pending' }}">
                <div class="row g-2">
                    <div class="col-12 col-md">
                        <input type="text" name="search" class="form-control form-control-sm" placeholder="Search by title..."
                            value="{{ request('search') }}" enterkeyhint="search" inputmode="search" onkeypress="if(event.key==='Enter'){this.form.submit();}">
                    </div>
                    <div class="col-6 col-md">
                        <select name="status" class="form-select form-select-sm">
                            <option value="">All Status</option>
                            <option value="Pending" {{ request('status') == 'Pending' ? 'selected' : '' }}>Pending</option>
                            <option value="Approved" {{ request('status') == 'Approved' ? 'selected' : '' }}>Approved</option>
                            <option value="Rejected" {{ request('status') == 'Rejected' ? 'selected' : '' }}>Rejected</option>
                            <option value="Cancelled" {{ request('status') == 'Cancelled' ? 'selected' : '' }}>Cancelled</option>
                        </select>
                    </div>
                    <div class="col-6 col-md">
                        <select name="category" class="form-select form-select-sm">
                            <option value="">All Categories</option>
                            <option value="Area Use" {{ request('category') == 'Area Use' ? 'selected' : '' }}>Area Use</option>
                        </select>
                    </div>
                    <div class="col-6 col-md">
                        <input type="date" name="date_from" class="form-control form-control-sm"
                            value="{{ request('date_from') }}">
                    </div>
                    <div class="col-6 col-md">
                        <input type="date" name="date_to" class="form-control form-control-sm"
                            value="{{ request('date_to') }}">
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                        <a href="{{ route($eventsIndexRoute) }}" class="btn btn-secondary btn-sm ms-1"><i class="fas fa-times"></i></a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    @if(($viewType ?? 'pending') == 'pending')
    @if($requests->count() > 0)
        <div class="table-responsive" style="display: block !important; visibility: visible !important; opacity: 1 !important;">
            <table class="table table-hover" style="display: table !important;">
                <thead>
                    <tr>
                        <th>Request Ticket</th>
                        <th>Requestor</th>                        <th>Date of Use</th>
                        <th>Time</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($requests as $request)
                        <tr>
                            <td>EVT-{{ str_pad($request->id, 5, '0', STR_PAD_LEFT) }}</td>
                            <td>{{ $request->user->name ?? 'N/A' }}</td>                            <td>{{ \Carbon\Carbon::parse($request->event_date)->format('m/d/Y') }}</td>
                            <td>{{ \Carbon\Carbon::parse($request->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($request->end_time)->format('g:i A') }}</td>
                            <td>{{ $request->location }}</td>
                            <td>
                                <span class="badge bg-{{ 
                                    $request->status == 'Approved' ? 'success' : 
                                    ($request->status == 'Pending' ? 'warning' : 
                                    ($request->status == 'Rejected' ? 'danger' : 'secondary'))
                                }}">
                                    {{ $request->status }}
                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-primary bg-transparent border-0" data-bs-toggle="modal"
                                        data-bs-target="#viewModal{{ $request->id }}">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    @if($request->status == 'Pending' && auth()->user()->role !== 'mis')
                                        <button type="button" class="btn btn-sm btn-success bg-transparent border-0" title="Approve" onclick="approveEvent({{ $request->id }})">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger bg-transparent border-0" title="Reject" onclick="rejectEvent({{ $request->id }})">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    @endif
                                    @php
                                        $userRole = auth()->user()->role;
                                        $archiveColumn = $userRole . '_archived';
                                        $isArchivedByRole = $request->$archiveColumn ?? false;
                                    @endphp
                                    @if(!$isArchivedByRole)
                                        <button type="button" class="btn btn-sm btn-secondary bg-transparent border-0" title="Archive" onclick="showArchiveEventModal({{ $request->id }})">
                                            <i class="fas fa-archive"></i>
                                        </button>
                                    @endif
                                    <button type="button" class="btn btn-sm btn-danger bg-transparent border-0" title="Delete" onclick="showDeleteEventModal({{ $request->id }})">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        
                        <!-- View Modal -->
                        <div class="modal fade" id="viewModal{{ $request->id }}" tabindex="-1">
                            <div class="modal-dialog modal-lg modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Facility Request Details</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p><strong>Ticket Number:</strong> EVT-{{ str_pad($request->id, 5, '0', STR_PAD_LEFT) }}</p>                                                <p><strong>Status:</strong> 
                                                    <span class="badge bg-{{ 
                                                        $request->status == 'Approved' ? 'success' : 
                                                        ($request->status == 'Pending' ? 'warning' : 
                                                        ($request->status == 'Rejected' ? 'danger' : 'secondary'))
                                                    }}">
                                                        {{ $request->status }}
                                                    </span>
                                                </p>
                                            </div>
                                            <div class="col-md-6">
                                                <p><strong>Requestor:</strong> {{ $request->user->name ?? 'N/A' }}</p>
                                                <p><strong>Date of Use:</strong> {{ \Carbon\Carbon::parse($request->event_date)->format('m/d/Y') }}</p>
                                                <p><strong>Time:</strong> {{ \Carbon\Carbon::parse($request->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($request->end_time)->format('g:i A') }}</p>
                                                <p><strong>Location:</strong> {{ $request->location }}</p>
                                            </div>
                                        </div>
                                        <hr>
                                        <p><strong>Description:</strong></p>
                                        <p style="white-space:pre-wrap">{{ $request->description }}</p>
                                        @if($request->notes)
                                            <hr>
                                            <p><strong>Notes:</strong></p>
                                            <p>{{ $request->notes }}</p>
                                        @endif
                                        
                                        <!-- Progress Tracker -->
                                        <hr>
                                        <x-request-progress-tracker :request="$request" title="Approval Progress" />
                                        
                                        <!-- PDF Download Button for Approved Facility Requests -->
                                        @if($request->status == 'Approved')
                                        <div class="text-center my-3">
                                            <a href="{{ route('events.pdf', $request->id) }}" class="btn btn-primary btn-lg" target="_blank">
                                                <i class="fas fa-file-pdf me-2"></i> Download PDF
                                            </a>
                                        </div>
                                        @endif
                                        
                                        @if($request->approved_by)
                                            <hr>
                                            <p><strong>Processed By:</strong> {{ $request->approver->name ?? 'N/A' }}</p>
                                            <p><strong>Processed At:</strong> {{ $request->approved_at ? \Carbon\Carbon::parse($request->approved_at)->format('M d, Y h:i A') : 'N/A' }}</p>
                                        @endif
                                    </div>
                                    <div class="modal-footer">
                                        @if($request->status == 'Pending' && auth()->user()->role !== 'mis')
                                            <form method="POST" action="{{ route('events.approve', $request->id) }}" class="d-inline">
                                                @csrf
                                                <div class="input-group">
                                                    <input type="text" name="notes" class="form-control" placeholder="Notes (optional)">
                                                    <button type="submit" class="btn btn-success">Approve</button>
                                                </div>
                                            </form>
                                            <form method="POST" action="{{ route('events.reject', $request->id) }}" class="d-inline">
                                                @csrf
                                                <div class="input-group">
                                                    <input type="text" name="notes" class="form-control" placeholder="Reason for rejection">
                                                    <button type="submit" class="btn btn-danger">Reject</button>
                                                </div>
                                            </form>
                                        @endif
                                        @if($request->status == 'Approved')
                                            <a href="{{ route('events.pdf', $request->id) }}" class="btn btn-primary" target="_blank">
                                                <i class="fas fa-file-pdf me-1"></i> Download PDF
                                            </a>
                                        @endif
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Mobile Card Layout for Pending Facility Requests -->
        <div class="mobile-event-cards">
            @foreach($requests as $request)
                <div class="event-card">
                    <div class="event-card-header">
                        <span class="event-card-ticket">EVT-{{ str_pad($request->id, 5, '0', STR_PAD_LEFT) }}</span>
                        <span class="badge bg-{{ 
                            $request->status == 'Approved' ? 'success' : 
                            ($request->status == 'Pending' ? 'warning' : 
                            ($request->status == 'Rejected' ? 'danger' : 'secondary'))
                        }}">
                            {{ $request->status }}
                        </span>
                    </div>
                    <div class="event-card-body">
                        <div class="event-card-field">
                            <span class="event-card-label">Requestor:</span>
                            <span class="event-card-value">{{ $request->user->name ?? 'N/A' }}</span>
                        </div>
                        <div class="event-card-field">
                            <span class="event-card-label">Date of Use:</span>
                            <span class="event-card-value">{{ \Carbon\Carbon::parse($request->event_date)->format('m/d/Y') }}</span>
                        </div>
                        <div class="event-card-field">
                            <span class="event-card-label">Time:</span>
                            <span class="event-card-value">{{ \Carbon\Carbon::parse($request->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($request->end_time)->format('g:i A') }}</span>
                        </div>
                        <div class="event-card-field">
                            <span class="event-card-label">Location:</span>
                            <span class="event-card-value">{{ $request->location }}</span>
                        </div>
                    </div>
                    <div class="event-card-actions">
                        <button type="button" class="btn btn-sm btn-info" onclick="viewEvent({{ $request->id }})">
                            <i class="fas fa-eye"></i> View
                        </button>
                        @if(auth()->user()->canAccess('events_approve') && $request->status == 'Pending')
                        <button type="button" class="btn btn-sm btn-success" onclick="showApproveModal({{ $request->id }}, '{{ $request->title }}')">
                            <i class="fas fa-check"></i> Approve
                        </button>
                        @endif
                        @if(auth()->user()->canAccess('events_reject') && $request->status == 'Pending')
                        <button type="button" class="btn btn-sm btn-danger" onclick="showRejectModal({{ $request->id }}, '{{ $request->title }}')">
                            <i class="fas fa-times"></i> Reject
                        </button>
                        @endif
                        @if(auth()->user()->canAccess('events_delete'))
                        <button type="button" class="btn btn-sm btn-danger" onclick="showDeleteModal({{ $request->id }}, '{{ $request->title }}')">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>

    @else
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">No facility requests found</h4>
                <p>There are no facility requests matching your filters.</p>
                <a href="{{ route($eventsIndexRoute) }}" class="btn btn-primary">View All Requests</a>
            </div>
        </div>
    @endif
    @endif

    @if(($viewType ?? '') == 'approved')
    <!-- Approved Facility Requests Section -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-check-circle text-success"></i> Approved Facility Requests
                @if(isset($approvedEvents))
                    <span class="badge bg-success ms-2">{{ $approvedEvents->count() }}</span>
                @endif
            </h5>
        </div>
        <div class="card-body">
            @if(isset($approvedEvents) && $approvedEvents->count() > 0)
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Request Ticket</th>
                                <th>Requestor</th>                                <th>Date of Use</th>
                                <th>Time</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($approvedEvents as $event)
                                <tr>
                                    <td>EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</td>
                                    <td>{{ $event->user->name ?? 'N/A' }}</td>                                    <td>{{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</td>
                                    <td>{{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</td>
                                    <td>{{ $event->location }}</td>
                                    <td>
                                        <span class="badge bg-{{ $event->status == 'Approved' ? 'success' : ($event->status == 'Rejected' ? 'danger' : ($event->status == 'Cancelled' ? 'secondary' : 'warning')) }}">
                                            {{ $event->status }}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-primary bg-transparent border-0"
                                                data-bs-toggle="modal" data-bs-target="#approvedViewModal{{ $event->id }}" title="View">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-secondary bg-transparent border-0" title="Archive" onclick="showArchiveEventModal({{ $event->id }})">
                                                <i class="fas fa-archive"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger bg-transparent border-0" title="Delete" onclick="showDeleteEventModal({{ $event->id }})">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>

                                <!-- View Modal -->
                                <div class="modal fade" id="approvedViewModal{{ $event->id }}" tabindex="-1">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Facility Request Details</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <p><strong>Ticket Number:</strong> EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</p>                                                        <p><strong>Status:</strong> <span class="badge bg-{{ $event->status == 'Approved' ? 'success' : ($event->status == 'Rejected' ? 'danger' : ($event->status == 'Cancelled' ? 'secondary' : 'warning')) }}">{{ $event->status }}</span></p>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <p><strong>Requestor:</strong> {{ $event->user->name ?? 'N/A' }}</p>
                                                        <p><strong>Date of Use:</strong> {{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</p>
                                                        <p><strong>Time:</strong> {{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</p>
                                                        <p><strong>Location:</strong> {{ $event->location }}</p>
                                                    </div>
                                                </div>
                                                <hr>
                                                <p><strong>Description:</strong></p>
                                                <p style="white-space:pre-wrap">{{ $event->description }}</p>
                                                @if($event->notes)
                                                    <hr>
                                                    <p><strong>Notes:</strong></p>
                                                    <p>{{ $event->notes }}</p>
                                                @endif
                                                <hr>
                                                <x-request-progress-tracker :request="$event" title="Approval Progress" />
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Mobile Card Layout for Approved Facility Requests -->
                <div class="mobile-event-cards">
                    @foreach($approvedEvents as $event)
                        <div class="event-card">
                            <div class="event-card-header">
                                <span class="event-card-ticket">EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</span>
                                <span class="badge bg-{{ $event->status == 'Approved' ? 'success' : ($event->status == 'Rejected' ? 'danger' : ($event->status == 'Cancelled' ? 'secondary' : 'warning')) }}">{{ $event->status }}</span>
                            </div>
                            <div class="event-card-body">
                                <div class="event-card-field">
                                    <span class="event-card-label">Requestor:</span>
                                    <span class="event-card-value">{{ $event->user->name ?? 'N/A' }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Date of Use:</span>
                                    <span class="event-card-value">{{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Time:</span>
                                    <span class="event-card-value">{{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Location:</span>
                                    <span class="event-card-value">{{ $event->location }}</span>
                                </div>
                            </div>
                            <div class="event-card-actions">
                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#approvedViewModal{{ $event->id }}">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button type="button" class="btn btn-sm btn-secondary" onclick="showArchiveEventModal({{ $event->id }})">
                                    <i class="fas fa-archive"></i> Archive
                                </button>
                                <button type="button" class="btn btn-sm btn-danger" onclick="showDeleteEventModal({{ $event->id }})">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                    @endforeach
                </div>

            @else
                <div class="text-center py-5">
                    <i class="fas fa-check-circle fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No approved upcoming facility requests</h5>
                    <p class="text-muted">Approved facility requests with a future date will appear here.</p>
                </div>
            @endif
        </div>
    </div>
    @endif

    @if(($viewType ?? '') == 'finished')
    <!-- Finished Facility Requests Section -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-flag-checkered" style="color:#6f42c1;"></i> Finished Facility Requests
                @if(isset($finishedEvents))
                    <span class="badge ms-2" style="background:#6f42c1;">{{ $finishedEvents->count() }}</span>
                @endif
            </h5>
        </div>
        <div class="card-body">
            @if(isset($finishedEvents) && $finishedEvents->count() > 0)
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Request Ticket</th>
                                <th>Requestor</th>                                <th>Date of Use</th>
                                <th>Time</th>
                                <th>Location</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($finishedEvents as $event)
                                <tr>
                                    <td>EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</td>
                                    <td>{{ $event->user->name ?? 'N/A' }}</td>                                    <td>{{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</td>
                                    <td>{{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</td>
                                    <td>{{ $event->location }}</td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-primary bg-transparent border-0"
                                                data-bs-toggle="modal" data-bs-target="#finishedViewModal{{ $event->id }}" title="View">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-secondary bg-transparent border-0" title="Archive" onclick="showArchiveEventModal({{ $event->id }})">
                                                <i class="fas fa-archive"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger bg-transparent border-0" title="Delete" onclick="showDeleteEventModal({{ $event->id }})">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>

                                <!-- View Modal -->
                                <div class="modal fade" id="finishedViewModal{{ $event->id }}" tabindex="-1">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Facility Request Details</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <p><strong>Ticket Number:</strong> EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</p>                                                        <p><strong>Status:</strong> <span class="badge" style="background:#6f42c1;">Finished</span></p>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <p><strong>Requestor:</strong> {{ $event->user->name ?? 'N/A' }}</p>
                                                        <p><strong>Date of Use:</strong> {{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</p>
                                                        <p><strong>Time:</strong> {{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</p>
                                                        <p><strong>Location:</strong> {{ $event->location }}</p>
                                                    </div>
                                                </div>
                                                <hr>
                                                <p><strong>Description:</strong></p>
                                                <p style="white-space:pre-wrap">{{ $event->description }}</p>
                                                @if($event->notes)
                                                    <hr>
                                                    <p><strong>Notes:</strong></p>
                                                    <p>{{ $event->notes }}</p>
                                                @endif
                                                <hr>
                                                <x-request-progress-tracker :request="$event" title="Approval Progress" />
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Mobile Card Layout for Finished Facility Requests -->
                <div class="mobile-event-cards">
                    @foreach($finishedEvents as $event)
                        <div class="event-card">
                            <div class="event-card-header">
                                <span class="event-card-ticket">EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</span>
                                <span class="badge" style="background:#6f42c1;">Finished</span>
                            </div>
                            <div class="event-card-body">
                                <div class="event-card-field">
                                    <span class="event-card-label">Requestor:</span>
                                    <span class="event-card-value">{{ $event->user->name ?? 'N/A' }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Date of Use:</span>
                                    <span class="event-card-value">{{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Time:</span>
                                    <span class="event-card-value">{{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Location:</span>
                                    <span class="event-card-value">{{ $event->location }}</span>
                                </div>
                            </div>
                            <div class="event-card-actions">
                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#finishedViewModal{{ $event->id }}">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button type="button" class="btn btn-sm btn-secondary" onclick="showArchiveEventModal({{ $event->id }})">
                                    <i class="fas fa-archive"></i> Archive
                                </button>
                                <button type="button" class="btn btn-sm btn-danger" onclick="showDeleteEventModal({{ $event->id }})">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                    @endforeach
                </div>

            @else
                <div class="text-center py-5">
                    <i class="fas fa-flag-checkered fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No finished facility requests yet</h5>
                    <p class="text-muted">Approved facility requests whose date has passed will appear here.</p>
                </div>
            @endif
        </div>
    </div>
    @endif

    @if(($viewType ?? '') == 'rejected')
    <!-- Rejected Facility Requests Section -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-times-circle text-danger"></i> Rejected Facility Requests
                @if(isset($rejectedEvents))
                    <span class="badge bg-danger ms-2">{{ $rejectedEvents->count() }}</span>
                @endif
            </h5>
        </div>
        <div class="card-body">
            @if(isset($rejectedEvents) && $rejectedEvents->count() > 0)
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Request Ticket</th>
                                <th>Requestor</th>                                <th>Date of Use</th>
                                <th>Time</th>
                                <th>Location</th>
                                <th>Reason</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($rejectedEvents as $event)
                                <tr>
                                    <td>EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</td>
                                    <td>{{ $event->user->name ?? 'N/A' }}</td>                                    <td>{{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</td>
                                    <td>{{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</td>
                                    <td>{{ $event->location }}</td>
                                    <td>{{ $event->notes ? \Illuminate\Support\Str::limit($event->notes, 40) : '-' }}</td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-primary bg-transparent border-0"
                                                data-bs-toggle="modal" data-bs-target="#rejectedViewModal{{ $event->id }}" title="View">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-secondary bg-transparent border-0" title="Archive" onclick="showArchiveEventModal({{ $event->id }})">
                                                <i class="fas fa-archive"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger bg-transparent border-0" title="Delete" onclick="showDeleteEventModal({{ $event->id }})">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>

                                <!-- View Modal -->
                                <div class="modal fade" id="rejectedViewModal{{ $event->id }}" tabindex="-1">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Facility Request Details</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <p><strong>Ticket Number:</strong> EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</p>                                                        <p><strong>Status:</strong> <span class="badge bg-danger">Rejected</span></p>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <p><strong>Requestor:</strong> {{ $event->user->name ?? 'N/A' }}</p>
                                                        <p><strong>Date of Use:</strong> {{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</p>
                                                        <p><strong>Time:</strong> {{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</p>
                                                        <p><strong>Location:</strong> {{ $event->location }}</p>
                                                    </div>
                                                </div>
                                                <hr>
                                                <p><strong>Description:</strong></p>
                                                <p style="white-space:pre-wrap">{{ $event->description }}</p>
                                                @if($event->notes)
                                                    <hr>
                                                    <p><strong>Reason for Rejection:</strong></p>
                                                    <p class="text-danger">{{ $event->notes }}</p>
                                                @endif
                                                <hr>
                                                <x-request-progress-tracker :request="$event" title="Approval Progress" />
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Mobile Card Layout for Rejected Facility Requests -->
                <div class="mobile-event-cards">
                    @foreach($rejectedEvents as $event)
                        <div class="event-card">
                            <div class="event-card-header">
                                <span class="event-card-ticket">EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</span>
                                <span class="badge bg-danger">Rejected</span>
                            </div>
                            <div class="event-card-body">
                                <div class="event-card-field">
                                    <span class="event-card-label">Requestor:</span>
                                    <span class="event-card-value">{{ $event->user->name ?? 'N/A' }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Date of Use:</span>
                                    <span class="event-card-value">{{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Time:</span>
                                    <span class="event-card-value">{{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Location:</span>
                                    <span class="event-card-value">{{ $event->location }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Reason:</span>
                                    <span class="event-card-value text-danger">{{ $event->notes ? \Illuminate\Support\Str::limit($event->notes, 40) : '-' }}</span>
                                </div>
                            </div>
                            <div class="event-card-actions">
                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#rejectedViewModal{{ $event->id }}">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button type="button" class="btn btn-sm btn-secondary" onclick="showArchiveEventModal({{ $event->id }})">
                                    <i class="fas fa-archive"></i> Archive
                                </button>
                                <button type="button" class="btn btn-sm btn-danger" onclick="showDeleteEventModal({{ $event->id }})">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                    @endforeach
                </div>

            @else
                <div class="text-center py-5">
                    <i class="fas fa-times-circle fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No rejected facility requests</h5>
                    <p class="text-muted">Rejected facility requests will appear here.</p>
                </div>
            @endif
        </div>
    </div>
    @endif

    @if(($viewType ?? '') == 'archives')
    <!-- Archived Facility Requests Section -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-archive"></i> Archived Facility Requests</h5>
                </div>
                <div class="card-body">
                    @if(isset($archivedEvents) && $archivedEvents->count() > 0)
                        <div class="table-responsive" style="display: block !important; visibility: visible !important; opacity: 1 !important;">
                            <table class="table table-hover" style="display: table !important;">
                                <thead>
                                    <tr>
                                        <th>Request Ticket</th>
                                        <th>Requestor</th>                                        <th>Date of Use</th>
                                        <th>Time</th>
                                        <th>Location</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($archivedEvents as $event)
                                        <tr>
                                            <td>EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</td>
                                            <td>{{ $event->user->name ?? 'N/A' }}</td>                                            <td>{{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</td>
                                            <td>{{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</td>
                                            <td>{{ $event->location }}</td>
                                            <td>
                                                <span class="badge bg-{{
                                                    $event->status == 'Approved' ? 'success' :
                                                    ($event->status == 'Pending' ? 'warning' :
                                                    ($event->status == 'Rejected' ? 'danger' : 'secondary'))
                                                }}">
                                                    {{ $event->status }}
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <button type="button" class="btn btn-sm btn-primary bg-transparent" data-bs-toggle="modal"
                                                        data-bs-target="#viewModal{{ $event->id }}">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    <form method="POST" action="{{ route('admin.archive.restore') }}" class="d-inline">
                                                        @csrf
                                                        <input type="hidden" name="type" value="event">
                                                        <input type="hidden" name="id" value="{{ $event->id }}">
                                                        <button type="submit" class="btn btn-sm btn-success bg-transparent" title="Restore">
                                                            <i class="fas fa-trash-restore"></i>
                                                        </button>
                                                    </form>
                                                    <form method="POST" action="{{ route('admin.events.softDelete', $event->id) }}" class="d-inline" onsubmit="return confirm('Move this archived event to Deleted?')">
                                                        @csrf
                                                        <button type="submit" class="btn btn-sm btn-danger bg-transparent" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <!-- View Modal -->
                                        <div class="modal fade" id="viewModal{{ $event->id }}" tabindex="-1">
                                            <div class="modal-dialog modal-lg modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Facility Request Details</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <p><strong>Ticket Number:</strong> EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</p>                                                                <p><strong>Status:</strong>
                                                                    <span class="badge bg-{{
                                                                        $event->status == 'Approved' ? 'success' :
                                                                        ($event->status == 'Pending' ? 'warning' :
                                                                        ($event->status == 'Rejected' ? 'danger' : 'secondary'))
                                                                    }}">
                                                                        {{ $event->status }}
                                                                    </span>
                                                                </p>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <p><strong>Requestor:</strong> {{ $event->user->name ?? 'N/A' }}</p>
                                                                <p><strong>Date of Use:</strong> {{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</p>
                                                                <p><strong>Time:</strong> {{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</p>
                                                                <p><strong>Location:</strong> {{ $event->location }}</p>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                        <p><strong>Description:</strong></p>
                                                        <p style="white-space:pre-wrap">{{ $event->description }}</p>
                                                        @if($event->notes)
                                                            <hr>
                                                            <p><strong>Notes:</strong></p>
                                                            <p>{{ $event->notes }}</p>
                                                        @endif
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <!-- Mobile Card Layout for Archived Facility Requests -->
                        <div class="mobile-event-cards">
                            @foreach($archivedEvents as $event)
                                <div class="event-card">
                                    <div class="event-card-header">
                                        <span class="event-card-ticket">EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</span>
                                        <span class="badge bg-{{
                                            $event->status == 'Approved' ? 'success' :
                                            ($event->status == 'Pending' ? 'warning' :
                                            ($event->status == 'Rejected' ? 'danger' : 'secondary'))
                                        }}">
                                            {{ $event->status }}
                                        </span>
                                    </div>
                                    <div class="event-card-body">
                                        <div class="event-card-field">
                                            <span class="event-card-label">Requestor:</span>
                                            <span class="event-card-value">{{ $event->user->name ?? 'N/A' }}</span>
                                        </div>
                                        <div class="event-card-field">
                                            <span class="event-card-label">Date of Use:</span>
                                            <span class="event-card-value">{{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</span>
                                        </div>
                                        <div class="event-card-field">
                                            <span class="event-card-label">Time:</span>
                                            <span class="event-card-value">{{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</span>
                                        </div>
                                        <div class="event-card-field">
                                            <span class="event-card-label">Location:</span>
                                            <span class="event-card-value">{{ $event->location }}</span>
                                        </div>
                                    </div>
                                    <div class="event-card-actions">
                                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#viewModal{{ $event->id }}">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        <form method="POST" action="{{ route('admin.archive.restore') }}" style="flex: 1;">
                                            @csrf
                                            <input type="hidden" name="type" value="event">
                                            <input type="hidden" name="id" value="{{ $event->id }}">
                                            <button type="submit" class="btn btn-sm btn-success w-100">
                                                <i class="fas fa-trash-restore"></i> Restore
                                            </button>
                                        </form>
                                        <form method="POST" action="{{ route('admin.events.softDelete', $event->id) }}" style="flex: 1;" onsubmit="return confirm('Move this archived event to Deleted?')">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-danger w-100">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                    @else
                        <div class="alert alert-info mb-0">
                            <i class="fas fa-archive"></i> No archived facility requests found.
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    @endif

    <!-- Deleted Facility Requests View -->
    @if(($viewType ?? '') == 'deleted')
    <!-- Context Menu (Right-Click) -->
    <div id="deletedEventsContextMenu" class="context-menu" style="display: none;">
        <ul>
            <li><a href="#" onclick="deletedEventsContextView()"><i class="fas fa-eye"></i> View</a></li>
            <li><a href="#" onclick="deletedEventsContextRestore()"><i class="fas fa-trash-restore"></i> Restore</a></li>
            <li><a href="#" onclick="deletedEventsContextPermanentDelete()"><i class="fas fa-times-circle"></i> Permanently Delete</a></li>
        </ul>
    </div>

    <div class="row mb-4">
        <div class="col-md-12">
            <h2><i class="fas fa-trash-alt"></i> Deleted Facility Requests</h2>
            <p class="text-muted">Facility requests in this folder can be restored or permanently deleted.</p>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    <!-- Info + Auto-filter Card -->
    <div class="card mb-4 border-warning">
        <div class="card-body bg-warning bg-opacity-10 py-2">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <strong><i class="fas fa-info-circle"></i> About Deleted Facility Requests</strong>
                    <p class="mb-0 text-muted small">Facility requests deleted are moved here. Restore or permanently delete them.</p>
                </div>
                <div class="d-flex align-items-center gap-3">
                    <span class="badge bg-warning fs-6">{{ $deletedEvents->count() }} events</span>
                    <select id="retentionDays" class="form-select form-select-sm" style="width:120px;">
                        <option value="0" {{ ($days ?? 15) == 0 ? 'selected' : '' }}>Off</option>`r`n                        <option value="3" {{ ($days ?? 15) == 3 ? 'selected' : '' }}>3 days</option>
                        <option value="7" {{ ($days ?? 15) == 7 ? 'selected' : '' }}>7 days</option>
                        <option value="15" {{ ($days ?? 15) == 15 ? 'selected' : '' }}>15 days</option>
                        <option value="30" {{ ($days ?? 15) == 30 ? 'selected' : '' }}>30 days</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Bulk Actions -->
    @if($deletedEvents->count() > 0)
    <div class="card mb-3">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <form id="deletedEventsBulkRestoreForm" method="POST" action="{{ route('admin.deletedEvents.restoreSelected') }}">
                        @csrf
                        <input type="hidden" name="event_ids" id="selectedDeletedEventIds">
                        <button type="button" class="btn btn-success" onclick="deletedEventsBulkRestore()">
                            <i class="fas fa-trash-restore"></i> Restore Selected
                        </button>
                    </form>
                </div>
                <div class="col-md-6 text-end">
                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deletedEventsPermanentDeleteAllModal">
                        <i class="fas fa-times-circle"></i> Permanently Delete All
                    </button>
                    <span id="deletedEventsSelectedCount" class="text-muted ms-3">0 facility requests selected</span>
                </div>
            </div>
        </div>
    </div>
    @endif

    <!-- Deleted Facility Requests Table -->
    <div class="card">
        <div class="card-body">
            @if(isset($deletedEvents) && $deletedEvents->count() > 0)
                <div class="table-responsive" style="display: block !important; visibility: visible !important; opacity: 1 !important;">
                    <table class="table table-hover" style="display: table !important;" id="deletedEventsTable">
                        <thead>
                            <tr>
                                <th style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" id="deletedEventsSelectAll" onchange="deletedEventsToggleSelectAll()"></th>
                                <th>Request Ticket</th>                                <th>Date of Use</th>
                                <th>Location</th>
                                <th>Department</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Requested By</th>
                                <th>Deleted Date</th>
                                <th>Deleted By</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($deletedEvents as $event)
                                <tr data-id="{{ $event->id }}">
                                    <td style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" class="deleted-event-checkbox" value="{{ $event->id }}" onchange="deletedEventsUpdateSelectedCount()"></td>
                                    <td>EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</td>
                                    <td>
                                        <span class="badge bg-info">
                                            {{ $event->getCategoryLabel() }}
                                        </span>
                                    </td>
                                    <td>{{ $event->event_date->format('m/d/Y') }}</td>
                                    <td>{{ $event->location }}</td>
                                    <td>{{ $event->department }}</td>
                                    <td>
                                        @php
                                            $priorityColors = [
                                                'low' => 'success',
                                                'medium' => 'warning',
                                                'high' => 'danger',
                                                'urgent' => 'dark'
                                            ];
                                            $priorityClass = $priorityColors[$event->priority] ?? 'secondary';
                                        @endphp
                                        <span class="badge bg-{{ $priorityClass }}">
                                            {{ ucfirst($event->priority) }}
                                        </span>
                                    </td>
                                    <td>
                                        @php
                                            $statusClass = match($event->status) {
                                                'Pending' => 'warning',
                                                'Approved' => 'success',
                                                'Rejected' => 'danger',
                                                'Cancelled' => 'secondary',
                                                default => 'secondary'
                                            };
                                        @endphp
                                        <span class="badge bg-{{ $statusClass }}">
                                            {{ $event->status }}
                                        </span>
                                    </td>
                                    <td>{{ $event->user ? $event->user->name : 'Unknown' }}</td>
                                    <td>{{ $event->updated_at->format('M d, Y h:i A') }}</td>
                                    <td>{{ $event->deletedBy ? $event->deletedBy->name : 'System' }}</td>
                                    <td>
                                        <div class="action-icons">
                                            <button type="button" class="btn btn-sm btn-info bg-transparent" data-bs-toggle="modal" data-bs-target="#deletedEventsViewModal{{ $event->id }}" title="View">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <form action="{{ route('admin.deletedEvents.restore', $event->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('POST')
                                                <button type="submit" class="btn btn-sm btn-success bg-transparent" title="Restore">
                                                    <i class="fas fa-trash-restore"></i>
                                                </button>
                                            </form>
                                            <form action="{{ route('admin.deletedEvents.permanentDelete', $event->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-danger bg-transparent" title="Permanently Delete"
                                                    data-confirm="Are you sure you want to permanently delete this facility request?"
                                                    data-confirm-title="Permanent Delete"
                                                    data-confirm-ok="Yes, Delete Forever"
                                                    data-confirm-color="#dc3545">
                                                    <i class="fas fa-times-circle"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Permanent Delete Confirmation Modal -->
                                <div class="modal fade" id="deletedEventsPermanentDeleteModal{{ $event->id }}" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header bg-danger text-white">
                                                <h5 class="modal-title">Permanently Delete Facility Request</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Are you sure you want to permanently delete <strong>EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</strong>?</p>
                                                <p class="text-danger"><i class="fas fa-exclamation-triangle"></i> This action cannot be undone. The facility request will be permanently removed from the system.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <form action="{{ route('admin.deletedEvents.permanentDelete', $event->id) }}" method="POST" class="d-inline">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger">Permanently Delete</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- View Event Modal -->
                                <div class="modal fade" id="deletedEventsViewModal{{ $event->id }}" tabindex="-1">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Facility Request Details</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <p><strong>Ticket Number:</strong> EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</p>                                                        <p><strong>Status:</strong>
                                                            <span class="badge bg-{{
                                                                $event->status == 'Approved' ? 'success' :
                                                                ($event->status == 'Pending' ? 'warning' :
                                                                ($event->status == 'Rejected' ? 'danger' : 'secondary'))
                                                            }}">
                                                                {{ $event->status }}
                                                            </span>
                                                        </p>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <p><strong>Requestor:</strong> {{ $event->user->name ?? 'N/A' }}</p>
                                                        <p><strong>Date of Use:</strong> {{ \Carbon\Carbon::parse($event->event_date)->format('m/d/Y') }}</p>
                                                        <p><strong>Time:</strong> {{ \Carbon\Carbon::parse($event->start_time)->format('g:i A') }} - {{ \Carbon\Carbon::parse($event->end_time)->format('g:i A') }}</p>
                                                        <p><strong>Location:</strong> {{ $event->location }}</p>
                                                    </div>
                                                </div>
                                                <hr>
                                                <p><strong>Description:</strong></p>
                                                <p style="white-space:pre-wrap">{{ $event->description }}</p>
                                                @if($event->notes)
                                                    <hr>
                                                    <p><strong>Notes:</strong></p>
                                                    <p>{{ $event->notes }}</p>
                                                @endif
                                                @if($event->deletedBy)
                                                    <hr>
                                                    <p><strong>Deleted By:</strong> {{ $event->deletedBy->name }}</p>
                                                    <p><strong>Deleted Date:</strong> {{ $event->updated_at->format('M d, Y h:i A') }}</p>
                                                @endif
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <tr>
                                    <td colspan="13" class="text-center p-4">
                                        <div class="alert alert-info mb-0">
                                            <i class="fas fa-check-circle fa-2x d-block mb-3"></i>
                                            <h5>No Deleted Facility Requests</h5>
                                            <p class="mb-0">Deleted facility requests will appear here. You can delete facility requests from the Facilities page.</p>
                                            <a href="{{ route($eventsIndexRoute) }}" class="btn btn-primary mt-3">
                                                <i class="fas fa-calendar-alt"></i> Go to Facilities
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <!-- Mobile Card Layout for Deleted Facility Requests -->
                <div class="mobile-event-cards">
                    @forelse($deletedEvents as $event)
                        <div class="event-card" data-id="{{ $event->id }}">
                            <div class="event-card-header">
                                <div>
                                    <input type="checkbox" class="event-card-checkbox deleted-event-checkbox" value="{{ $event->id }}" onchange="deletedEventsUpdateSelectedCount()">
                                    <span class="event-card-ticket">EVT-{{ str_pad($event->id, 5, '0', STR_PAD_LEFT) }}</span>
                                </div>
                                <span class="badge bg-{{ 
                                    $event->status == 'Approved' ? 'success' : 
                                    ($event->status == 'Pending' ? 'warning' : 
                                    ($event->status == 'Rejected' ? 'danger' : 'secondary'))
                                }}">
                                    {{ $event->status }}
                                </span>
                            </div>
                            <div class="event-card-body">
                                <div class="event-card-field">
                                    <span class="event-card-label">Category:</span>
                                    <span class="event-card-value">
                                        <span class="badge bg-info">{{ $event->getCategoryLabel() }}</span>
                                    </span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Date of Use:</span>
                                    <span class="event-card-value">{{ $event->event_date->format('m/d/Y') }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Location:</span>
                                    <span class="event-card-value">{{ $event->location }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Department:</span>
                                    <span class="event-card-value">{{ $event->department }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Requested By:</span>
                                    <span class="event-card-value">{{ $event->user->name ?? 'N/A' }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Deleted By:</span>
                                    <span class="event-card-value">{{ $event->deletedBy ? $event->deletedBy->name : 'System' }}</span>
                                </div>
                                <div class="event-card-field">
                                    <span class="event-card-label">Deleted Date:</span>
                                    <span class="event-card-value">{{ $event->updated_at->format('M d, Y h:i A') }}</span>
                                </div>
                            </div>
                            <div class="event-card-actions">
                                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#deletedEventsViewModal{{ $event->id }}">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <form action="{{ route('admin.deletedEvents.restore', $event->id) }}" method="POST" style="flex: 1;">
                                    @csrf
                                    @method('POST')
                                    <button type="submit" class="btn btn-sm btn-success w-100">
                                        <i class="fas fa-trash-restore"></i> Restore
                                    </button>
                                </form>
                                <form action="{{ route('admin.deletedEvents.permanentDelete', $event->id) }}" method="POST" style="flex: 1;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger w-100" 
                                        data-confirm="Are you sure you want to permanently delete this facility request?"
                                        data-confirm-title="Permanent Delete"
                                        data-confirm-ok="Yes, Delete Forever"
                                        data-confirm-color="#dc3545">
                                        <i class="fas fa-times-circle"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                    @empty
                        <div class="text-center py-5">
                            <div class="alert alert-info mb-0">
                                <i class="fas fa-check-circle fa-2x d-block mb-3"></i>
                                <h5>No Deleted Facility Requests</h5>
                                <p class="mb-0">Deleted facility requests will appear here. You can delete facility requests from the Facilities page.</p>
                                <a href="{{ route($eventsIndexRoute) }}" class="btn btn-primary mt-3">
                                    <i class="fas fa-calendar-alt"></i> Go to Facilities
                                </a>
                            </div>
                        </div>
                    @endforelse
                </div>

            @else
                <div class="card">
                    <div class="card-body text-center py-5">
                        <i class="fas fa-check-circle fa-2x d-block mb-3 text-success"></i>
                        <h5>No Deleted Facility Requests</h5>
                        <p class="mb-0 text-muted">Deleted facility requests will appear here. You can delete facility requests from the Facilities page.</p>
                        <a href="{{ route($eventsIndexRoute) }}" class="btn btn-primary mt-3">
                            <i class="fas fa-calendar-alt"></i> Go to Facilities
                        </a>
                    </div>
                </div>
            @endif
        </div>
    </div>
    @endif
</div>

<script>
// Archive Facility Request Function
function showArchiveEventModal(eventId) {
    confirmArchive({
        title: 'Archive Facility Request?',
        text: 'This event will be archived and hidden from your active list.',
        confirmButtonText: '<i class="fas fa-archive me-1"></i> Archive'
    }).then(result => {
        if (result.isConfirmed) {
            // Show loading
            getSwal().fire({
                title: 'Archiving...',
                html: '<div class="spinner-border text-primary"></div>',
                showConfirmButton: false,
                allowOutsideClick: false
            });
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '/events/' + eventId + '/archive';
            
            const csrfToken = document.createElement('input');
            csrfToken.type = 'hidden';
            csrfToken.name = '_token';
            csrfToken.value = '{{ csrf_token() }}';
            form.appendChild(csrfToken);
            
            document.body.appendChild(form);
            form.submit();
        }
    });
}

// Delete Facility Request Function
function showDeleteEventModal(eventId) {
    confirmDelete({
        title: 'Delete Facility Request?',
        text: 'This event will be moved to deleted. You can restore it later from the Deleted tab.',
        confirmButtonText: '<i class="fas fa-trash me-1"></i> Delete'
    }).then(result => {
        if (result.isConfirmed) {
            // Show loading
            getSwal().fire({
                title: 'Deleting...',
                html: '<div class="spinner-border text-danger"></div>',
                showConfirmButton: false,
                allowOutsideClick: false
            });
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '/events/' + eventId + '/delete';
            
            const csrfToken = document.createElement('input');
            csrfToken.type = 'hidden';
            csrfToken.name = '_token';
            csrfToken.value = '{{ csrf_token() }}';
            form.appendChild(csrfToken);
            
            document.body.appendChild(form);
            form.submit();
        }
    });
}

// Approve Facility Request Function
function approveEvent(eventId) {
    confirmApprove({
        title: 'Approve Facility Request?',
        text: 'This facility request will be approved and the requestor will be notified.',
        confirmButtonText: '<i class="fas fa-check me-1"></i> Approve'
    }).then(result => {
        if (result.isConfirmed) {
            // Show loading
            getSwal().fire({
                title: 'Approving...',
                html: '<div class="spinner-border text-success"></div>',
                showConfirmButton: false,
                allowOutsideClick: false
            });
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '/events/' + eventId + '/approve';
            
            const csrfToken = document.createElement('input');
            csrfToken.type = 'hidden';
            csrfToken.name = '_token';
            csrfToken.value = '{{ csrf_token() }}';
            form.appendChild(csrfToken);
            
            document.body.appendChild(form);
            form.submit();
        }
    });
}

// Reject Facility Request Function
function rejectEvent(eventId) {
    confirmReject({
        title: 'Reject Facility Request?',
        text: 'This facility request will be rejected and the requestor will be notified.',
        confirmButtonText: '<i class="fas fa-times me-1"></i> Reject'
    }).then(result => {
        if (result.isConfirmed) {
            // Show loading
            getSwal().fire({
                title: 'Rejecting...',
                html: '<div class="spinner-border text-danger"></div>',
                showConfirmButton: false,
                allowOutsideClick: false
            });
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '/events/' + eventId + '/reject';
            
            const csrfToken = document.createElement('input');
            csrfToken.type = 'hidden';
            csrfToken.name = '_token';
            csrfToken.value = '{{ csrf_token() }}';
            form.appendChild(csrfToken);
            
            document.body.appendChild(form);
            form.submit();
        }
    });
}

// Event Action Modal Functions
let eventActionType = null;
let eventActionId = null;

function showEventActionModal(type, id, name) {
    eventActionType = type;
    eventActionId = id;

    const modal = new bootstrap.Modal(document.getElementById('eventActionModal'));
    const modalHeader = document.getElementById('eventActionModalHeader');
    const modalMessage = document.getElementById('eventActionMessage');
    const modalAlert = document.getElementById('eventActionAlert');
    const confirmBtn = document.getElementById('eventActionConfirmBtn');

    modalAlert.classList.remove('alert-info', 'alert-warning', 'alert-danger', 'd-none');

    if (type === 'archive') {
        modalHeader.className = 'modal-header bg-secondary text-white';
        document.getElementById('eventActionModalLabel').innerHTML = '<i class="fas fa-archive"></i> Archive Facility Request';
        modalMessage.innerHTML = 'Are you sure you want to archive <strong>' + name + '</strong>?';
        modalAlert.classList.add('alert-info');
        modalAlert.innerHTML = '<i class="fas fa-info-circle"></i> You can restore this facility request later from the Archive tab.';
        confirmBtn.className = 'btn btn-secondary';
        confirmBtn.innerHTML = '<i class="fas fa-archive"></i> Archive';
    } else if (type === 'delete') {
        modalHeader.className = 'modal-header bg-danger text-white';
        document.getElementById('eventActionModalLabel').innerHTML = '<i class="fas fa-exclamation-triangle"></i> Delete Facility Request';
        modalMessage.innerHTML = 'Are you sure you want to delete <strong>' + name + '</strong>?';
        modalAlert.classList.add('alert-warning');
        modalAlert.innerHTML = '<i class="fas fa-warning"></i> This action will move the facility request to deleted. You can restore it later from the Deleted tab.';
        confirmBtn.className = 'btn btn-danger';
        confirmBtn.innerHTML = '<i class="fas fa-trash"></i> Delete';
    }

    // Set up confirm button click
    confirmBtn.onclick = function() {
        executeEventAction(type, id);
    };

    modal.show();
}

function executeEventAction(type, id) {
    let url = '';
    let method = 'POST';

    if (type === 'archive') {
        url = '/events/' + id + '/archive';
    } else if (type === 'delete') {
        url = '/events/' + id + '/delete';
    }

    fetch(url, {
        method: method,
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            swalToast(type.charAt(0).toUpperCase() + type.slice(1) + ' successful!', 'success');
            setTimeout(() => location.reload(), 1500);
        } else if (data.error) {
            swalAlert(data.error, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        swalAlert('Error performing action', 'error');
    });

    // Close modal
    const modalEl = document.getElementById('eventActionModal');
    const modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) {
        modal.hide();
    }
}
</script>

@if(($viewType ?? '') == 'deleted')
<!-- Permanent Delete All Confirmation Modal for Deleted Facility Requests -->
<div class="modal fade" id="deletedEventsPermanentDeleteAllModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Permanently Delete All Facility Requests</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to permanently delete all <strong>{{ $deletedEvents->count() }}</strong> facility requests?</p>
                <p class="text-danger"><i class="fas fa-exclamation-triangle"></i> This action cannot be undone. All facility requests will be permanently removed from the system.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form action="{{ route('admin.deletedEvents.permanentDeleteAll') }}" method="POST" class="d-inline">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Permanently Delete All</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Context menu variables for deleted facility requests
    let deletedEventsContextMenu = document.getElementById('deletedEventsContextMenu');
    let currentDeletedEventId = null;

    // Toggle select all checkboxes for deleted facility requests
    function deletedEventsToggleSelectAll() {
        const selectAll = document.getElementById('deletedEventsSelectAll');
        const checkboxes = document.querySelectorAll('.deleted-event-checkbox');
        
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAll.checked;
        });
        
        deletedEventsUpdateSelectedCount();
    }

    // Update selected count for deleted facility requests
    function deletedEventsUpdateSelectedCount() {
        const countEl = document.getElementById('deletedEventsSelectedCount');
        const eventIdsEl = document.getElementById('selectedDeletedEventIds');
        
        // Return early if elements don't exist (no facility requests)
        if (!countEl || !eventIdsEl) {
            return;
        }
        
        const checkboxes = document.querySelectorAll('.deleted-event-checkbox:checked');
        const count = checkboxes.length;
        countEl.textContent = count + ' event' + (count !== 1 ? 's' : '') + ' selected';
        
        // Update hidden input for bulk form
        const selectedIds = Array.from(checkboxes).map(cb => cb.value);
        eventIdsEl.value = JSON.stringify(selectedIds);
    }

    // Bulk restore function for deleted facility requests
    function deletedEventsBulkRestore() {
        const checkboxes = document.querySelectorAll('.deleted-event-checkbox:checked');
        if (checkboxes.length === 0) {
            swalAlert('Please select at least one event to restore.', 'warning');
            return;
        }
        
        if (confirm('Are you sure you want to restore ' + checkboxes.length + ' event(s)?')) {
            document.getElementById('deletedEventsBulkRestoreForm').submit();
        }
    }

    // Context menu functions for deleted facility requests
    function showDeletedEventsContextMenu(e, eventId) {
        e.preventDefault();
        currentDeletedEventId = eventId;
        
        deletedEventsContextMenu.style.display = 'block';
        deletedEventsContextMenu.style.left = e.pageX + 'px';
        deletedEventsContextMenu.style.top = e.pageY + 'px';
    }

    function hideDeletedEventsContextMenu() {
        deletedEventsContextMenu.style.display = 'none';
    }

    function deletedEventsContextView() {
        hideDeletedEventsContextMenu();
        const modalId = 'deletedEventsViewModal' + currentDeletedEventId;
        const modal = new bootstrap.Modal(document.getElementById(modalId));
        modal.show();
    }

    function deletedEventsContextRestore() {
        hideDeletedEventsContextMenu();
        if (confirm('Are you sure you want to restore this facility request?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '/admin/deleted-events/' + currentDeletedEventId + '/restore';
            
            const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
            const csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = '_token';
            csrfInput.value = csrfToken;
            
            form.appendChild(csrfInput);
            document.body.appendChild(form);
            form.submit();
        }
    }

    function deletedEventsContextPermanentDelete() {
        hideDeletedEventsContextMenu();
        const modalId = 'deletedEventsPermanentDeleteModal' + currentDeletedEventId;
        const modal = new bootstrap.Modal(document.getElementById(modalId));
        modal.show();
    }

    // Add right-click listeners to deleted facility requests table rows
    document.querySelectorAll('#deletedEventsTable tbody tr').forEach(row => {
        row.addEventListener('contextmenu', (e) => {
            const eventId = row.getAttribute('data-id');
            if (eventId) {
                showDeletedEventsContextMenu(e, eventId);
            }
        });
    });

    // Hide context menu on click outside
    document.addEventListener('click', (e) => {
        if (deletedEventsContextMenu && !deletedEventsContextMenu.contains(e.target)) {
            hideDeletedEventsContextMenu();
        }
    });

    // Handle retention days dropdown change (only if element exists) and page load
    document.addEventListener('DOMContentLoaded', function() {
        // Update selected count on page load
        deletedEventsUpdateSelectedCount();

        // Handle retention days dropdown change
        const retentionDaysElement = document.getElementById('retentionDays');
        if (retentionDaysElement) {
            retentionDaysElement.addEventListener('change', function() {
                const days = this.value;
                if (confirm(`Set auto-filter to show events deleted more than ${days} days ago?`)) {
                    // Show loading indicator
                    this.disabled = true;

                    // Make AJAX request to save preference
                    fetch('{{ route("saveAutoDeletePreference") }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                        },
                        body: JSON.stringify({ days: parseInt(days), module: 'event_requests' })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Reload the page to show filtered results
                            window.location.href = '{{ route($eventsIndexRoute, ["view" => "deleted"]) }}&days=' + days;
                        } else {
                            swalAlert('Error saving preference.', 'error');
                        }
                    })
                    .catch(error => {
                        swalAlert('An error occurred while saving your preference.', 'error');
                        console.error(error);
                    })
                    .finally(() => {
                        // Restore dropdown
                        this.disabled = false;
                    });
                } else {
                    // Reset to previous value
                    this.value = '{{ $days ?? 15 }}';
                }
            });
        }
    });
</script>
@endif

@endsection
