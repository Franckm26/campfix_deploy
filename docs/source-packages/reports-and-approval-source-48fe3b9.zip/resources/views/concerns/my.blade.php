@extends('layouts.app')

@section('scripts')
<script src="{{ asset('js/image-upload-feedback.js') }}"></script>
@endsection

@section('styles')
<link href="{{ asset('css/admin.css') }}" rel="stylesheet">
<style>
/* Ticket column styling - minimal width, centered - OVERRIDE admin.css */
.ticket-col {
    width: 60px !important;
    max-width: 60px !important;
    min-width: 60px !important;
    white-space: nowrap !important;
    text-align: center !important;
    padding-left: 4px !important;
    padding-right: 4px !important;
    font-size: 0.9em !important;
    overflow: hidden !important;
}

/* Override the nth-child rules from admin.css for ticket column */
.table th.ticket-col,
.table td.ticket-col {
    width: 60px !important;
    min-width: 60px !important;
    max-width: 60px !important;
}

/* Dark mode support for SweetAlert modals */
[data-theme="dark"] .swal2-popup {
    background-color: #1e1e2e !important;
    color: #e0e0e0 !important;
}

[data-theme="dark"] .swal2-title {
    color: #ffffff !important;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
}

[data-theme="dark"] .swal2-html-container {
    color: #e0e0e0 !important;
}

[data-theme="dark"] .swal2-html-container h5,
[data-theme="dark"] .swal2-html-container h6,
[data-theme="dark"] .swal2-html-container p,
[data-theme="dark"] .swal2-html-container strong {
    color: #e0e0e0 !important;
}

[data-theme="dark"] .swal2-html-container hr {
    border-color: #3a3a4a !important;
}

[data-theme="dark"] .swal2-close {
    color: white !important;
}

/* ==================== MOBILE RESPONSIVE CARD LAYOUT ==================== */
/* Desktop: Hide mobile cards */
.mobile-concern-cards {
    display: none;
}

/* Mobile Card Layout for Concerns */
@media screen and (max-width: 768px) {
    /* Hide table on mobile */
    .card-body .table-responsive {
        display: none !important;
    }
    
    /* Show mobile card layout */
    .mobile-concern-cards {
        display: block !important;
    }
    
    /* Concern card styling */
    .concern-card {
        background: #fff;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 12px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .dark-mode .concern-card,
    [data-theme="dark"] .concern-card {
        background: #1a1d20;
        border-color: #404347;
    }
    
    .concern-card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #dee2e6;
    }
    
    .dark-mode .concern-card-header,
    [data-theme="dark"] .concern-card-header {
        border-bottom-color: #404347;
    }
    
    .concern-card-id {
        font-weight: 600;
        font-size: 14px;
        color: #212529;
    }
    
    .dark-mode .concern-card-id,
    [data-theme="dark"] .concern-card-id {
        color: #e9ecef;
    }
    
    .concern-card-body {
        margin-bottom: 12px;
    }
    
    .concern-card-field {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 0;
        font-size: 14px;
    }
    
    .concern-card-label {
        font-weight: 500;
        color: #6c757d;
        margin-right: 12px;
    }
    
    .dark-mode .concern-card-label,
    [data-theme="dark"] .concern-card-label {
        color: #adb5bd;
    }
    
    .concern-card-value {
        text-align: right;
        color: #212529;
    }
    
    .dark-mode .concern-card-value,
    [data-theme="dark"] .concern-card-value {
        color: #e9ecef;
    }
    
    .concern-card-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        padding-top: 12px;
        border-top: 1px solid #dee2e6;
    }
    
    .dark-mode .concern-card-actions,
    [data-theme="dark"] .concern-card-actions {
        border-top-color: #404347;
    }
    
    .concern-card-actions .btn {
        flex: 1;
        min-width: fit-content;
    }
    
    /* Checkbox for mobile cards */
    .concern-card-checkbox {
        margin-right: 8px;
    }
}
</style>
@endsection

@section('page_title')
<h2>My Concerns</h2>
@endsection

@section('content')
<div class="container-fluid px-3">
    
    <!-- Context Menu -->
    <div id="contextMenu" class="context-menu">
        <ul>
            <li><a href="#" id="ctxView" onclick="contextView()"><i class="fas fa-eye"></i> View</a></li>
            <li><a href="#" id="ctxEdit" onclick="contextEdit()"><i class="fas fa-edit"></i> Edit</a></li>
            <li><a href="#" id="ctxArchive" onclick="contextArchive()"><i class="fas fa-archive"></i> Archive</a></li>
            <li><a href="#" id="ctxDelete" onclick="contextDelete()"><i class="fas fa-trash"></i> Delete</a></li>
        </ul>
    </div>

    <!-- Context Menu for Archives -->
    <div id="contextMenuArchive" class="context-menu">
        <ul>
            <li><a href="#" id="ctxViewArchive" onclick="contextView()"><i class="fas fa-eye"></i> View</a></li>
            <li><a href="#" id="ctxRestore" onclick="contextRestore()"><i class="fas fa-trash-restore"></i> Restore</a></li>
            <li><a href="#" id="ctxDeleteArchive" onclick="contextDeleteFromArchive()"><i class="fas fa-trash"></i> Delete</a></li>
        </ul>
    </div>

    <!-- Context Menu for Deleted -->
    <div id="contextMenuDeleted" class="context-menu">
        <ul>
            <li><a href="#" id="ctxViewDeleted" onclick="contextView()"><i class="fas fa-eye"></i> View</a></li>
            <li><a href="#" id="ctxRestoreDeleted" onclick="contextRestoreDeleted()"><i class="fas fa-trash-restore"></i> Restore</a></li>
            <li><a href="#" id="ctxPermanentDelete" onclick="contextPermanentDelete()"><i class="fas fa-ban"></i> Permanent Delete</a></li>
        </ul>
    </div>


    <!-- Tabs Navigation -->
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <ul class="nav nav-tabs border-0 mb-0" id="concernTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link {{ ($viewType ?? 'active') === 'active' ? 'active' : '' }}" 
                    id="active-tab" data-bs-toggle="tab" data-bs-target="#active-concerns" 
                    type="button" role="tab" aria-controls="active-concerns" 
                    aria-selected="{{ ($viewType ?? 'active') === 'active' ? 'true' : 'false' }}">
                <i class="fas fa-list"></i> Active
                @if(isset($concerns) && $concerns->count() > 0)
                    <span class="badge bg-primary ms-1">{{ $concerns->count() }}</span>
                @endif
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link {{ ($viewType ?? '') === 'resolved' ? 'active' : '' }}" 
                    id="resolved-tab" data-bs-toggle="tab" data-bs-target="#resolved-concerns" 
                    type="button" role="tab" aria-controls="resolved-concerns" 
                    aria-selected="{{ ($viewType ?? '') === 'resolved' ? 'true' : 'false' }}">
                <i class="fas fa-check-circle"></i> Resolved
                @if(isset($resolvedConcerns) && $resolvedConcerns->count() > 0)
                    <span class="badge bg-success ms-1">{{ $resolvedConcerns->count() }}</span>
                @endif
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link {{ ($viewType ?? '') === 'archives' ? 'active' : '' }}" 
                    id="archives-tab" data-bs-toggle="tab" data-bs-target="#archived-concerns" 
                    type="button" role="tab" aria-controls="archived-concerns" 
                    aria-selected="{{ ($viewType ?? '') === 'archives' ? 'true' : 'false' }}">
                <i class="fas fa-archive"></i> Archives
                @if(isset($archivedConcerns) && $archivedConcerns->count() > 0)
                    <span class="badge bg-warning ms-1">{{ $archivedConcerns->count() }}</span>
                @endif
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link {{ ($viewType ?? '') === 'deleted' ? 'active' : '' }}" 
                    id="deleted-tab" data-bs-toggle="tab" data-bs-target="#deleted-concerns" 
                    type="button" role="tab" aria-controls="deleted-concerns" 
                    aria-selected="{{ ($viewType ?? '') === 'deleted' ? 'true' : 'false' }}">
                <i class="fas fa-trash"></i> Deleted
                @if(isset($deletedConcerns) && $deletedConcerns->count() > 0)
                    <span class="badge bg-danger ms-1">{{ $deletedConcerns->count() }}</span>
                @endif
            </button>
        </li>
        </ul>
        @if(auth()->user()->role !== 'maintenance')
            <button type="button" class="btn btn-primary btn-sm" onclick="openNewConcernModal()">
                <i class="fas fa-plus"></i> New Concern
            </button>
        @endif
    </div>

    <!-- Tab Content -->
    <div class="tab-content show" id="concernTabContent">
        
        <!-- Active Concerns Tab -->
        <div class="tab-pane fade {{ ($viewType ?? 'active') === 'active' ? 'show active' : '' }}" 
             id="active-concerns" role="tabpanel" aria-labelledby="active-tab">
            
            <!-- Filters for Active -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="{{ route('concerns.my') }}" class="row g-2 align-items-center" id="filterForm">
                        <input type="hidden" name="view" value="active">
                        <div class="col-6 col-md">
                            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search..." 
                                value="{{ request('search') }}" enterkeyhint="search" inputmode="search" onkeypress="if(event.key==='Enter'){this.form.submit();}">
                        </div>
                        <div class="col-6 col-md">
                            <select name="category" class="form-select form-select-sm">
                                <option value="">All Categories</option>
                                @foreach($categories as $category)
                                    <option value="{{ $category->id }}" {{ request('category') == $category->id ? 'selected' : '' }}>
                                        {{ $category->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-6 col-md">
                            <select name="status" class="form-select form-select-sm">
                                <option value="">All Status</option>
                                <option value="Pending" {{ request('status') == 'Pending' ? 'selected' : '' }}>Pending</option>
                                <option value="Assigned" {{ request('status') == 'Assigned' ? 'selected' : '' }}>Assigned</option>
                                <option value="In Progress" {{ request('status') == 'In Progress' ? 'selected' : '' }}>In Progress</option>
                                <option value="Resolved" {{ request('status') == 'Resolved' ? 'selected' : '' }}>Resolved</option>
                            </select>
                        </div>
                        <div class="col-6 col-md">
                            <select name="priority" class="form-select form-select-sm">
                                <option value="">All Priority</option>
                                <option value="low" {{ request('priority') == 'low' ? 'selected' : '' }}>Low</option>
                                <option value="medium" {{ request('priority') == 'medium' ? 'selected' : '' }}>Medium</option>
                                <option value="high" {{ request('priority') == 'high' ? 'selected' : '' }}>High</option>
                                <option value="urgent" {{ request('priority') == 'urgent' ? 'selected' : '' }}>Urgent</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                        </div>
                        <div class="col-auto">
                            <a href="{{ route('concerns.my', ['view' => 'active']) }}" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i></a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Active Concerns List -->
            <div class="card">
                <div class="card-body">
                    <!-- Bulk Actions for Active -->
                    <div class="bulk-actions mb-3" id="activeBulkActions" style="display: none;">
                        <div class="btn-group">
                            <button type="button" class="btn btn-warning btn-sm" onclick="batchArchiveSelected()">
                                <i class="fas fa-archive"></i> Archive Selected
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" onclick="batchSoftDeleteSelected()">
                                <i class="fas fa-trash"></i> Delete Selected
                            </button>
                        </div>
                        <span class="ms-2 text-muted" id="activeSelectedCount">0 selected</span>
                    </div>

                    @if($concerns->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" id="selectAllActive" onchange="toggleSelectAll('active')"></th>
                                        <th class="ticket-col" style="width: 60px; max-width: 60px; min-width: 60px; white-space: nowrap; text-align: center;">Ticket</th>
                                        <th style="width:100px;white-space:nowrap;">Issue</th>
                                        <th>Category</th>
                                        <th>Location</th>
                                        <th>Priority</th>
                                        <th>Status</th>
                                        @if(auth()->user()->role === 'mis')
                                        <th>Reported By</th>
                                        @endif
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($concerns as $concern)
                                        <tr data-id="{{ $concern->id }}" data-view="active">
                                            <td style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" class="active-checkbox" value="{{ $concern->id }}" onchange="updateActiveBulkActions()"></td>
                                            <td class="ticket-col" style="width: 60px; max-width: 60px; min-width: 60px; white-space: nowrap; text-align: center; padding: 4px;">#{{ str_pad($concern->id, 4, '0', STR_PAD_LEFT) }}</td>
                                            <td style="width:100px;max-width:100px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                                <a href="#" onclick="event.preventDefault(); viewConcern({{ $concern->id }});">
                                                    {{ $concern->title ?? \Illuminate\Support\Str::limit($concern->description, 40) }}
                                                </a>
                                                @if($concern->image_path)
                                                    <i class="fas fa-image text-muted" title="Has photo"></i>
                                                @endif
                                            </td>
                                            <td>{{ $concern->categoryRelation->name ?? 'N/A' }}</td>
                                            <td>{{ $concern->location }}</td>
                                            <td>
                                                <span class="badge bg-{{ 
                                                    $concern->priority == 'urgent' ? 'danger' : 
                                                    ($concern->priority == 'high' ? 'warning' : 
                                                    ($concern->priority == 'medium' ? 'info' : 'secondary'))
                                                }}">
                                                    {{ ($concern->priority ? ucfirst($concern->priority) : 'Not Set') }}
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-{{ 
                                                    $concern->status == 'Resolved' ? 'success' : 
                                                    ($concern->status == 'In Progress' ? 'warning' : 
                                                    ($concern->status == 'Assigned' ? 'primary' : 'secondary'))
                                                }}">
                                                    {{ $concern->status }}
                                                </span>
                                            </td>
                                            @if(auth()->user()->role === 'mis')
                                            <td>
                                                @if($concern->is_anonymous)
                                                    Anonymous
                                                @else
                                                    {{ $concern->reporter_display_name }}
                                                    @if($concern->user)
                                                        <small class="text-muted">({{ $concern->user->role }})</small>
                                                    @endif
                                                @endif
                                            </td>
                                            @endif
                                            <td>{{ $concern->created_at->format('m/d/Y') }}</td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <button type="button" class="btn btn-sm btn-info bg-transparent border-0" onclick="viewConcern({{ $concern->id }})" title="View">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    @if(($concern->user_id == auth()->id() || $concern->hasLinkedReporter(auth()->id())) && $concern->status == 'Pending')
                                                    <button type="button" class="btn btn-sm btn-warning bg-transparent border-0" onclick="editConcern({{ $concern->id }})" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    @endif
                                                    @if($concern->status == 'Pending' && !$concern->assigned_to && $concern->created_at->diffInDays(now()) >= 1)
                                                    <button type="button" class="btn btn-sm btn-primary bg-transparent border-0" onclick="sendFollowUp({{ $concern->id }})" title="Send Follow-up">
                                                        <i class="fas fa-bell"></i>
                                                    </button>
                                                    @endif
                                                    <button type="button" class="btn btn-sm btn-secondary bg-transparent border-0" onclick="showArchiveModal({{ $concern->id }})" title="Archive">
                                                        <i class="fas fa-archive"></i>
                                                    </button>
                                                    @if(!$concern->assigned_to || $concern->status === 'Resolved')
                                                    <button type="button" class="btn btn-sm btn-danger bg-transparent border-0" onclick="softDeleteConcern({{ $concern->id }})" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    @else
                                                    <button type="button" class="btn btn-sm btn-secondary bg-transparent border-0" disabled title="Cannot delete assigned concerns until resolved">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    @endif
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <!-- Mobile Card Layout -->
                        <div class="mobile-concern-cards">
                            @foreach($concerns as $concern)
                                <div class="concern-card" data-id="{{ $concern->id }}" data-view="active">
                                    <div class="concern-card-header">
                                        <div>
                                            <input type="checkbox" class="concern-card-checkbox active-checkbox" value="{{ $concern->id }}" onchange="updateActiveBulkActions()">
                                            <span class="concern-card-id">#{{ str_pad($concern->id, 4, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                        <span class="badge bg-{{ 
                                            $concern->status == 'Resolved' ? 'success' : 
                                            ($concern->status == 'In Progress' ? 'warning' : 
                                            ($concern->status == 'Assigned' ? 'primary' : 'secondary'))
                                        }}">
                                            {{ $concern->status }}
                                        </span>
                                    </div>
                                    <div class="concern-card-body">
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Issue:</span>
                                            <span class="concern-card-value">
                                                <a href="#" onclick="event.preventDefault(); viewConcern({{ $concern->id }});">
                                                    {{ $concern->title ?? \Illuminate\Support\Str::limit($concern->description, 30) }}
                                                </a>
                                                @if($concern->image_path)
                                                    <i class="fas fa-image text-muted" title="Has photo"></i>
                                                @endif
                                            </span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Category:</span>
                                            <span class="concern-card-value">{{ $concern->categoryRelation->name ?? 'N/A' }}</span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Location:</span>
                                            <span class="concern-card-value">{{ $concern->location }}</span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Priority:</span>
                                            <span class="concern-card-value">
                                                <span class="badge bg-{{ 
                                                    $concern->priority == 'urgent' ? 'danger' : 
                                                    ($concern->priority == 'high' ? 'warning' : 
                                                    ($concern->priority == 'medium' ? 'info' : 'secondary'))
                                                }}">
                                                    {{ ($concern->priority ? ucfirst($concern->priority) : 'Not Set') }}
                                                </span>
                                            </span>
                                        </div>
                                        @if(auth()->user()->role === 'mis')
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Reported By:</span>
                                            <span class="concern-card-value">
                                                @if($concern->is_anonymous)
                                                    Anonymous
                                                @else
                                                    {{ $concern->reporter_display_name }}
                                                @endif
                                            </span>
                                        </div>
                                        @endif
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Date:</span>
                                            <span class="concern-card-value">{{ $concern->created_at->format('m/d/Y') }}</span>
                                        </div>
                                    </div>
                                    <div class="concern-card-actions">
                                        <button type="button" class="btn btn-sm btn-info" onclick="viewConcern({{ $concern->id }})">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        @if(($concern->user_id == auth()->id() || $concern->hasLinkedReporter(auth()->id())) && $concern->status == 'Pending')
                                        <button type="button" class="btn btn-sm btn-warning" onclick="editConcern({{ $concern->id }})">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        @endif
                                        @if($concern->status == 'Pending' && !$concern->assigned_to && $concern->created_at->diffInDays(now()) >= 1)
                                        <button type="button" class="btn btn-sm btn-primary" onclick="sendFollowUp({{ $concern->id }})">
                                            <i class="fas fa-bell"></i> Follow-up
                                        </button>
                                        @endif
                                        <button type="button" class="btn btn-sm btn-secondary" onclick="showArchiveModal({{ $concern->id }})">
                                            <i class="fas fa-archive"></i> Archive
                                        </button>
                                        @if(!$concern->assigned_to || $concern->status === 'Resolved')
                                        <button type="button" class="btn btn-sm btn-danger" onclick="softDeleteConcern({{ $concern->id }})">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>

                    @else
                        <div class="text-center py-5">
                            <h4 class="text-muted">No active concerns found</h4>
                        </div>
                    @endif

                    <!-- Pagination -->
                    @if(method_exists($concerns, 'hasPages') && $concerns->hasPages())
                    <div class="d-flex justify-content-center mt-3">
                        {{ $concerns->appends(request()->query())->links('pagination::bootstrap-4') }}
                    </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Resolved Concerns Tab -->
        <div class="tab-pane fade {{ ($viewType ?? '') === 'resolved' ? 'show active' : '' }}" 
             id="resolved-concerns" role="tabpanel" aria-labelledby="resolved-tab">
            
            <!-- Filters for Resolved -->
            @if(($viewType ?? '') === 'resolved' || isset($resolvedConcerns))
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="{{ route('concerns.my') }}" class="row g-2 align-items-center" id="resolvedFilterForm">
                        <input type="hidden" name="view" value="resolved">
                        <div class="col-6 col-md">
                            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search..." 
                                value="{{ request('search') }}" enterkeyhint="search" inputmode="search" onkeypress="if(event.key==='Enter'){this.form.submit();}">
                        </div>
                        <div class="col-6 col-md">
                            <select name="category" class="form-select form-select-sm">
                                <option value="">All Categories</option>
                                @foreach($categories ?? [] as $category)
                                    <option value="{{ $category->id }}" {{ request('category') == $category->id ? 'selected' : '' }}>
                                        {{ $category->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-6 col-md">
                            <select name="priority" class="form-select form-select-sm">
                                <option value="">All Priority</option>
                                <option value="low" {{ request('priority') == 'low' ? 'selected' : '' }}>Low</option>
                                <option value="medium" {{ request('priority') == 'medium' ? 'selected' : '' }}>Medium</option>
                                <option value="high" {{ request('priority') == 'high' ? 'selected' : '' }}>High</option>
                                <option value="urgent" {{ request('priority') == 'urgent' ? 'selected' : '' }}>Urgent</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                        </div>
                        <div class="col-auto">
                            <a href="{{ route('concerns.my', ['view' => 'resolved']) }}" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i></a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Resolved Concerns List -->
            <div class="card">
                <div class="card-body">
                    <!-- Bulk Actions for Resolved -->
                    <div class="bulk-actions mb-3" id="resolvedBulkActions" style="display: none;">
                        <div class="btn-group">
                            <button type="button" class="btn btn-warning btn-sm" onclick="batchArchiveResolved()">
                                <i class="fas fa-archive"></i> Archive Selected
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" onclick="batchSoftDeleteResolved()">
                                <i class="fas fa-trash"></i> Delete Selected
                            </button>
                        </div>
                        <span class="ms-2 text-muted" id="resolvedSelectedCount">0 selected</span>
                    </div>

                    @if(isset($resolvedConcerns) && $resolvedConcerns->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" id="selectAllResolved" onchange="toggleSelectAll('resolved')"></th>
                                        <th class="ticket-col" style="width: 60px; max-width: 60px; min-width: 60px; white-space: nowrap; text-align: center;">Ticket</th>
                                        <th style="width:100px;white-space:nowrap;">Issue</th>
                                        <th>Category</th>
                                        <th>Location</th>
                                        <th>Priority</th>
                                        @if(auth()->user()->role === 'mis')
                                        <th>Reported By</th>
                                        @endif
                                        <th>Resolved Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($resolvedConcerns as $concern)
                                        <tr data-id="{{ $concern->id }}" data-view="resolved">
                                            <td style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" class="resolved-checkbox" value="{{ $concern->id }}" onchange="updateResolvedBulkActions()"></td>
                                            <td class="ticket-col" style="width: 60px; max-width: 60px; min-width: 60px; white-space: nowrap; text-align: center; padding: 4px;">#{{ str_pad($concern->id, 4, '0', STR_PAD_LEFT) }}</td>
                                            <td style="width:100px;max-width:100px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                                <a href="#" onclick="event.preventDefault(); viewConcern({{ $concern->id }});">
                                                    {{ $concern->title ?? \Illuminate\Support\Str::limit($concern->description, 40) }}
                                                </a>
                                                @if($concern->image_path)
                                                    <i class="fas fa-image text-muted" title="Has photo"></i>
                                                @endif
                                            </td>
                                            <td>{{ $concern->categoryRelation->name ?? 'N/A' }}</td>
                                            <td>{{ $concern->location }}</td>
                                            <td>
                                                <span class="badge bg-{{ 
                                                    $concern->priority == 'urgent' ? 'danger' : 
                                                    ($concern->priority == 'high' ? 'warning' : 
                                                    ($concern->priority == 'medium' ? 'info' : 'secondary'))
                                                }}">
                                                    {{ ($concern->priority ? ucfirst($concern->priority) : 'Not Set') }}
                                                </span>
                                            </td>
                                            @if(auth()->user()->role === 'mis')
                                            <td>
                                                @if($concern->is_anonymous)
                                                    Anonymous
                                                @else
                                                    {{ $concern->reporter_display_name }}
                                                    @if($concern->user)
                                                        <small class="text-muted">({{ $concern->user->role }})</small>
                                                    @endif
                                                @endif
                                            </td>
                                            @endif
                                            <td>{{ $concern->updated_at->format('m/d/Y') }}</td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <button type="button" class="btn btn-sm btn-info bg-transparent border-0" onclick="viewConcern({{ $concern->id }})" title="View">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-secondary bg-transparent border-0" onclick="showArchiveModal({{ $concern->id }})" title="Archive">
                                                        <i class="fas fa-archive"></i>
                                                    </button>
                                                    @if(!$concern->assigned_to || $concern->status === 'Resolved')
                                                    <button type="button" class="btn btn-sm btn-danger bg-transparent border-0" onclick="softDeleteConcern({{ $concern->id }})" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    @else
                                                    <button type="button" class="btn btn-sm btn-secondary bg-transparent border-0" disabled title="Cannot delete assigned concerns until resolved">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    @endif
                                                </div>
                                                @include('partials.reopen-ticket', ['ticket' => $concern, 'context' => 'table'])
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <!-- Mobile Card Layout for Resolved -->
                        <div class="mobile-concern-cards">
                            @foreach($resolvedConcerns as $concern)
                                <div class="concern-card" data-id="{{ $concern->id }}" data-view="resolved">
                                    <div class="concern-card-header">
                                        <div>
                                            <input type="checkbox" class="concern-card-checkbox resolved-checkbox" value="{{ $concern->id }}" onchange="updateResolvedBulkActions()">
                                            <span class="concern-card-id">#{{ str_pad($concern->id, 4, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                        <span class="badge bg-success">Resolved</span>
                                    </div>
                                    <div class="concern-card-body">
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Issue:</span>
                                            <span class="concern-card-value">
                                                <a href="#" onclick="event.preventDefault(); viewConcern({{ $concern->id }});">
                                                    {{ $concern->title ?? \Illuminate\Support\Str::limit($concern->description, 30) }}
                                                </a>
                                                @if($concern->image_path)
                                                    <i class="fas fa-image text-muted"></i>
                                                @endif
                                            </span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Category:</span>
                                            <span class="concern-card-value">{{ $concern->categoryRelation->name ?? 'N/A' }}</span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Location:</span>
                                            <span class="concern-card-value">{{ $concern->location }}</span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Priority:</span>
                                            <span class="concern-card-value">
                                                <span class="badge bg-{{ 
                                                    $concern->priority == 'urgent' ? 'danger' : 
                                                    ($concern->priority == 'high' ? 'warning' : 
                                                    ($concern->priority == 'medium' ? 'info' : 'secondary'))
                                                }}">
                                                    {{ ($concern->priority ? ucfirst($concern->priority) : 'Not Set') }}
                                                </span>
                                            </span>
                                        </div>
                                        @if(auth()->user()->role === 'mis')
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Reported By:</span>
                                            <span class="concern-card-value">
                                                @if($concern->is_anonymous)
                                                    Anonymous
                                                @else
                                                    {{ $concern->reporter_display_name }}
                                                @endif
                                            </span>
                                        </div>
                                        @endif
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Resolved:</span>
                                            <span class="concern-card-value">{{ $concern->updated_at->format('m/d/Y') }}</span>
                                        </div>
                                    </div>
                                    <div class="concern-card-actions">
                                        <button type="button" class="btn btn-sm btn-info" onclick="viewConcern({{ $concern->id }})">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        <button type="button" class="btn btn-sm btn-secondary" onclick="showArchiveModal({{ $concern->id }})">
                                            <i class="fas fa-archive"></i> Archive
                                        </button>
                                        @if(!$concern->assigned_to || $concern->status === 'Resolved')
                                        <button type="button" class="btn btn-sm btn-danger" onclick="softDeleteConcern({{ $concern->id }})">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                        @endif
                                    </div>
                                    @include('partials.reopen-ticket', ['ticket' => $concern, 'context' => 'mobile'])
                                </div>
                            @endforeach
                        </div>

                    @else
                        <div class="text-center py-5">
                            <h4 class="text-muted">No resolved concerns found</h4>
                        </div>
                    @endif
                </div>
            </div>
            @endif
        </div>

        <!-- Archived Concerns Tab -->
        <div class="tab-pane fade {{ ($viewType ?? '') === 'archives' ? 'show active' : '' }}" 
             id="archived-concerns" role="tabpanel" aria-labelledby="archives-tab">
            
            <!-- Filters for Archives -->
            @if(($viewType ?? '') === 'archives' || isset($archivedConcerns))
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="{{ route('concerns.my') }}" class="row g-2 align-items-center" id="archiveFilterForm">
                        <input type="hidden" name="view" value="archives">
                        <div class="col-6 col-md">
                            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search..." 
                                value="{{ request('search') }}" enterkeyhint="search" inputmode="search" onkeypress="if(event.key==='Enter'){this.form.submit();}">
                        </div>
                        <div class="col-6 col-md">
                            <select name="category" class="form-select form-select-sm">
                                <option value="">All Categories</option>
                                @foreach($categories ?? [] as $category)
                                    <option value="{{ $category->id }}" {{ request('category') == $category->id ? 'selected' : '' }}>
                                        {{ $category->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-6 col-md">
                            <select name="status" class="form-select form-select-sm">
                                <option value="">All Status</option>
                                <option value="Pending" {{ request('status') == 'Pending' ? 'selected' : '' }}>Pending</option>
                                <option value="Assigned" {{ request('status') == 'Assigned' ? 'selected' : '' }}>Assigned</option>
                                <option value="In Progress" {{ request('status') == 'In Progress' ? 'selected' : '' }}>In Progress</option>
                                <option value="Resolved" {{ request('status') == 'Resolved' ? 'selected' : '' }}>Resolved</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                        </div>
                        <div class="col-auto">
                            <a href="{{ route('concerns.my', ['view' => 'archives']) }}" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i></a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Archived Concerns List -->
            <div class="card">
                <div class="card-body">
                    <!-- Bulk Actions for Archives -->
                    <div class="bulk-actions mb-3" id="archiveBulkActions" style="display: none;">
                        <div class="btn-group">
                            <button type="button" class="btn btn-success btn-sm" onclick="batchRestoreArchived()">
                                <i class="fas fa-trash-restore"></i> Restore Selected
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" onclick="batchSoftDeleteArchived()">
                                <i class="fas fa-trash"></i> Delete Selected
                            </button>
                        </div>
                        <span class="ms-2 text-muted" id="archiveSelectedCount">0 selected</span>
                    </div>

                    @if(isset($archivedConcerns) && $archivedConcerns->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" id="selectAllArchive" onchange="toggleSelectAll('archive')"></th>
                                        <th class="ticket-col" style="width: 60px; max-width: 60px; min-width: 60px; white-space: nowrap; text-align: center;">Ticket</th>
                                        <th style="width:100px;white-space:nowrap;">Issue</th>
                                        <th>Category</th>
                                        <th>Location</th>
                                        <th>Priority</th>
                                        <th>Status</th>
                                        <th>Archived By</th>
                                        <th>Archived At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($archivedConcerns as $concern)
                                        <tr data-id="{{ $concern->id }}" data-view="archive">
                                            <td style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" class="archive-checkbox" value="{{ $concern->id }}" onchange="updateArchiveBulkActions()"></td>
                                            <td class="ticket-col" style="width: 60px; max-width: 60px; min-width: 60px; white-space: nowrap; text-align: center; padding: 4px;">#{{ str_pad($concern->id, 4, '0', STR_PAD_LEFT) }}</td>
                                            <td style="width:100px;max-width:100px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                                <a href="#" onclick="event.preventDefault(); viewConcern({{ $concern->id }});">
                                                    {{ $concern->title ?? \Illuminate\Support\Str::limit($concern->description, 40) }}
                                                </a>
                                            </td>
                                            <td>{{ $concern->categoryRelation->name ?? 'N/A' }}</td>
                                            <td>{{ $concern->location }}</td>
                                            <td>
                                                <span class="badge bg-{{ 
                                                    $concern->priority == 'urgent' ? 'danger' : 
                                                    ($concern->priority == 'high' ? 'warning' : 
                                                    ($concern->priority == 'medium' ? 'info' : 'secondary'))
                                                }}">
                                                    {{ ($concern->priority ? ucfirst($concern->priority) : 'Not Set') }}
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-{{ 
                                                    $concern->status == 'Resolved' ? 'success' : 
                                                    ($concern->status == 'In Progress' ? 'warning' : 
                                                    ($concern->status == 'Assigned' ? 'primary' : 'secondary'))
                                                }}">
                                                    {{ $concern->status }}
                                                </span>
                                            </td>
                                            <td>{{ $concern->archivedByUsers->first()?->name ?? 'Self' }}</td>
                                            <td>{{ $concern->archivedByUsers->first()?->pivot->archived_at ? \Carbon\Carbon::parse($concern->archivedByUsers->first()->pivot->archived_at)->format('M d, Y g:i A') : $concern->updated_at->format('m/d/Y') }}</td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <button type="button" class="btn btn-sm btn-info bg-transparent border-0" onclick="viewConcern({{ $concern->id }})" title="View">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    <form method="POST" action="{{ route('concerns.restore', $concern->id) }}" class="d-inline">
                                                        @csrf
                                                        <button type="submit" class="btn btn-sm btn-success bg-transparent border-0" title="Restore">
                                                            <i class="fas fa-trash-restore"></i>
                                                        </button>
                                                    </form>
                                                    <button type="button" class="btn btn-sm btn-danger bg-transparent border-0" onclick="softDeleteArchivedConcern({{ $concern->id }})" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <!-- Mobile Card Layout for Archives -->
                        <div class="mobile-concern-cards">
                            @foreach($archivedConcerns as $concern)
                                <div class="concern-card" data-id="{{ $concern->id }}" data-view="archive">
                                    <div class="concern-card-header">
                                        <div>
                                            <input type="checkbox" class="concern-card-checkbox archive-checkbox" value="{{ $concern->id }}" onchange="updateArchiveBulkActions()">
                                            <span class="concern-card-id">#{{ str_pad($concern->id, 4, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                        <span class="badge bg-{{ 
                                            $concern->status == 'Resolved' ? 'success' : 
                                            ($concern->status == 'In Progress' ? 'warning' : 
                                            ($concern->status == 'Assigned' ? 'primary' : 'secondary'))
                                        }}">
                                            {{ $concern->status }}
                                        </span>
                                    </div>
                                    <div class="concern-card-body">
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Issue:</span>
                                            <span class="concern-card-value">
                                                <a href="#" onclick="event.preventDefault(); viewConcern({{ $concern->id }});">
                                                    {{ $concern->title ?? \Illuminate\Support\Str::limit($concern->description, 30) }}
                                                </a>
                                            </span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Category:</span>
                                            <span class="concern-card-value">{{ $concern->categoryRelation->name ?? 'N/A' }}</span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Location:</span>
                                            <span class="concern-card-value">{{ $concern->location }}</span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Priority:</span>
                                            <span class="concern-card-value">
                                                <span class="badge bg-{{ 
                                                    $concern->priority == 'urgent' ? 'danger' : 
                                                    ($concern->priority == 'high' ? 'warning' : 
                                                    ($concern->priority == 'medium' ? 'info' : 'secondary'))
                                                }}">
                                                    {{ ($concern->priority ? ucfirst($concern->priority) : 'Not Set') }}
                                                </span>
                                            </span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Archived By:</span>
                                            <span class="concern-card-value">{{ $concern->archived_by_user->name ?? 'System' }}</span>
                                        </div>
                                    </div>
                                    <div class="concern-card-actions">
                                        <button type="button" class="btn btn-sm btn-info" onclick="viewConcern({{ $concern->id }})">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        <form method="POST" action="{{ route('concerns.restore', $concern->id) }}" style="flex: 1;">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-success w-100">
                                                <i class="fas fa-trash-restore"></i> Restore
                                            </button>
                                        </form>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="softDeleteArchivedConcern({{ $concern->id }})">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                    @else
                        <div class="text-center py-5">
                            <h4 class="text-muted">No archived concerns found</h4>
                        </div>
                    @endif
                </div>
            </div>
            @endif
        </div>

        <!-- Deleted Concerns Tab -->
        <div class="tab-pane fade {{ ($viewType ?? '') === 'deleted' ? 'show active' : '' }}"
             id="deleted-concerns" role="tabpanel" aria-labelledby="deleted-tab">

            <!-- Auto-delete Settings -->
            <div class="card mb-4 border-info">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h5 class="mb-1"><i class="fas fa-clock"></i> Auto-delete Settings</h5>
                            <p class="mb-0 text-muted">Automatically delete concerns that have been in the deleted folder for the selected period.</p>
                        </div>
                        <div class="col-md-4">
                            <select id="autoDeleteDays" class="form-select" onchange="
                                const days = this.value;
                                fetch('{{ route('saveAutoDeletePreference') }}', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'X-CSRF-TOKEN': document.querySelector('meta[name=\'csrf-token\']').content
                                    },
                                    body: JSON.stringify({ days: parseInt(days), module: 'concerns' })
                                })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        // Reload page to show updated filter
                                        location.reload();
                                    } else {
                                        alert('Error saving preference: ' + (data.error || 'Unknown error'));
                                    }
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                    alert('Error saving preference');
                                });
                            ">
                                <option value="0" {{ ($days ?? 15) == 0 ? 'selected' : '' }}>Off — keep deleted concerns</option>
                                <option value="3" {{ ($days ?? 15) == 3 ? 'selected' : '' }}>3 days</option>
                                <option value="7" {{ ($days ?? 15) == 7 ? 'selected' : '' }}>7 days</option>
                                <option value="15" {{ ($days ?? 15) == 15 ? 'selected' : '' }}>15 days</option>
                                <option value="30" {{ ($days ?? 15) == 30 ? 'selected' : '' }}>30 days</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filters for Deleted -->
            @if(($viewType ?? '') === 'deleted' || isset($deletedConcerns))
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="{{ route('concerns.my') }}" class="row g-2 align-items-center" id="deletedFilterForm">
                        <input type="hidden" name="view" value="deleted">
                        <div class="col-6 col-md">
                            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search..." 
                                value="{{ request('search') }}" enterkeyhint="search" inputmode="search" onkeypress="if(event.key==='Enter'){this.form.submit();}">
                        </div>
                        <div class="col-6 col-md">
                            <select name="category" class="form-select form-select-sm">
                                <option value="">All Categories</option>
                                @foreach($categories ?? [] as $category)
                                    <option value="{{ $category->id }}" {{ request('category') == $category->id ? 'selected' : '' }}>
                                        {{ $category->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-6 col-md">
                            <select name="status" class="form-select form-select-sm">
                                <option value="">All Status</option>
                                <option value="Pending" {{ request('status') == 'Pending' ? 'selected' : '' }}>Pending</option>
                                <option value="Assigned" {{ request('status') == 'Assigned' ? 'selected' : '' }}>Assigned</option>
                                <option value="In Progress" {{ request('status') == 'In Progress' ? 'selected' : '' }}>In Progress</option>
                                <option value="Resolved" {{ request('status') == 'Resolved' ? 'selected' : '' }}>Resolved</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                        </div>
                        <div class="col-auto">
                            <a href="{{ route('concerns.my', ['view' => 'deleted']) }}" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i></a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Deleted Concerns List -->
            <div class="card">
                <div class="card-body">
                    <!-- Bulk Actions for Deleted -->
                    <div class="bulk-actions mb-3" id="deletedBulkActions" style="display: none;">
                        <div class="btn-group">
                            <button type="button" class="btn btn-success btn-sm" onclick="batchRestoreDeleted()">
                                <i class="fas fa-trash-restore"></i> Restore Selected
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" onclick="batchPermanentDeleteSelected()">
                                <i class="fas fa-ban"></i> Permanent Delete Selected
                            </button>
                        </div>
                        <span class="ms-2 text-muted" id="deletedSelectedCount">0 selected</span>
                    </div>

                    @if(isset($deletedConcerns) && $deletedConcerns->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" id="selectAllDeleted" onchange="toggleSelectAll('deleted')"></th>
                                        <th class="ticket-col" style="width: 60px; max-width: 60px; min-width: 60px; white-space: nowrap; text-align: center;">Ticket</th>
                                        <th style="width:100px;white-space:nowrap;">Issue</th>
                                        <th>Category</th>
                                        <th>Location</th>
                                        <th>Priority</th>
                                        <th>Status</th>
                                        <th>Deleted By</th>
                                        <th>Deleted At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($deletedConcerns as $concern)
                                        <tr data-id="{{ $concern->id }}" data-view="deleted">
                                            <td style="width:1%;white-space:nowrap;text-align:center"><input type="checkbox" class="deleted-checkbox" value="{{ $concern->id }}" onchange="updateDeletedBulkActions()"></td>
                                            <td class="ticket-col" style="width: 60px; max-width: 60px; min-width: 60px; white-space: nowrap; text-align: center; padding: 4px;">#{{ str_pad($concern->id, 4, '0', STR_PAD_LEFT) }}</td>
                                            <td style="width:100px;max-width:100px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                                <a href="#" onclick="event.preventDefault(); viewConcern({{ $concern->id }});">
                                                    {{ $concern->title ?? \Illuminate\Support\Str::limit($concern->description, 40) }}
                                                </a>
                                            </td>
                                            <td>{{ $concern->categoryRelation->name ?? 'N/A' }}</td>
                                            <td>{{ $concern->location }}</td>
                                            <td>
                                                <span class="badge bg-{{ 
                                                    $concern->priority == 'urgent' ? 'danger' : 
                                                    ($concern->priority == 'high' ? 'warning' : 
                                                    ($concern->priority == 'medium' ? 'info' : 'secondary'))
                                                }}">
                                                    {{ ($concern->priority ? ucfirst($concern->priority) : 'Not Set') }}
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-{{ 
                                                    $concern->status == 'Resolved' ? 'success' : 
                                                    ($concern->status == 'In Progress' ? 'warning' : 
                                                    ($concern->status == 'Assigned' ? 'primary' : 'secondary'))
                                                }}">
                                                    {{ $concern->status }}
                                                </span>
                                            </td>
                                            <td>{{ $concern->deletedBy ? $concern->deletedBy->name : 'System' }}</td>
                                            <td>{{ $concern->deleted_at ? $concern->deleted_at->format('M d, Y g:i A') : 'N/A' }}</td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <button type="button" class="btn btn-sm btn-info bg-transparent border-0" onclick="viewConcern({{ $concern->id }})" title="View">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    <form method="POST" action="{{ route('concerns.restore-deleted', $concern->id) }}" class="d-inline">
                                                        @csrf
                                                        <button type="submit" class="btn btn-sm btn-success bg-transparent border-0" title="Restore">
                                                            <i class="fas fa-trash-restore"></i>
                                                        </button>
                                                    </form>
                                                    <button type="button" class="btn btn-sm btn-danger bg-transparent border-0" onclick="permanentDeleteConcern({{ $concern->id }})" title="Permanent Delete">
                                                        <i class="fas fa-ban"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <!-- Mobile Card Layout for Deleted -->
                        <div class="mobile-concern-cards">
                            @foreach($deletedConcerns as $concern)
                                <div class="concern-card" data-id="{{ $concern->id }}" data-view="deleted">
                                    <div class="concern-card-header">
                                        <div>
                                            <input type="checkbox" class="concern-card-checkbox deleted-checkbox" value="{{ $concern->id }}" onchange="updateDeletedBulkActions()">
                                            <span class="concern-card-id">#{{ str_pad($concern->id, 4, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                        <span class="badge bg-{{ 
                                            $concern->status == 'Resolved' ? 'success' : 
                                            ($concern->status == 'In Progress' ? 'warning' : 
                                            ($concern->status == 'Assigned' ? 'primary' : 'secondary'))
                                        }}">
                                            {{ $concern->status }}
                                        </span>
                                    </div>
                                    <div class="concern-card-body">
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Issue:</span>
                                            <span class="concern-card-value">
                                                <a href="#" onclick="event.preventDefault(); viewConcern({{ $concern->id }});">
                                                    {{ $concern->title ?? \Illuminate\Support\Str::limit($concern->description, 30) }}
                                                </a>
                                            </span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Category:</span>
                                            <span class="concern-card-value">{{ $concern->categoryRelation->name ?? 'N/A' }}</span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Location:</span>
                                            <span class="concern-card-value">{{ $concern->location }}</span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Priority:</span>
                                            <span class="concern-card-value">
                                                <span class="badge bg-{{ 
                                                    $concern->priority == 'urgent' ? 'danger' : 
                                                    ($concern->priority == 'high' ? 'warning' : 
                                                    ($concern->priority == 'medium' ? 'info' : 'secondary'))
                                                }}">
                                                    {{ ($concern->priority ? ucfirst($concern->priority) : 'Not Set') }}
                                                </span>
                                            </span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Deleted By:</span>
                                            <span class="concern-card-value">{{ $concern->deletedBy ? $concern->deletedBy->name : 'System' }}</span>
                                        </div>
                                        <div class="concern-card-field">
                                            <span class="concern-card-label">Deleted At:</span>
                                            <span class="concern-card-value">{{ $concern->deleted_at ? $concern->deleted_at->format('M d, Y g:i A') : 'N/A' }}</span>
                                        </div>
                                    </div>
                                    <div class="concern-card-actions">
                                        <button type="button" class="btn btn-sm btn-info" onclick="viewConcern({{ $concern->id }})">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        <form method="POST" action="{{ route('concerns.restore-deleted', $concern->id) }}" style="flex: 1;">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-success w-100">
                                                <i class="fas fa-trash-restore"></i> Restore
                                            </button>
                                        </form>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="permanentDeleteConcern({{ $concern->id }})">
                                            <i class="fas fa-ban"></i> Permanent Delete
                                        </button>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                    @else
                        <div class="text-center py-5">
                            <h4 class="text-muted">No deleted concerns found</h4>
                        </div>
                    @endif
                </div>
            </div>
            @endif
        </div>
    </div>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewConcernModal" tabindex="-1" aria-labelledby="viewConcernModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewConcernModalLabel">Concern Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewConcernContent">
                <div class="text-center">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editConcernModal" tabindex="-1" aria-labelledby="editConcernModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editConcernModalLabel">Edit Concern</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editConcernForm" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="modal-body" id="editConcernContent">
                    <div class="text-center">
                        <div class="spinner-border" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="showEditReviewModal()">Review</button>
                </div>
            </form>
        </div>
</div>
</div>

<!-- Edit Review Modal -->
<div class="modal fade" id="editReviewModal" tabindex="-1" aria-labelledby="editReviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editReviewModalLabel">Review Your Changes</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold">Category:</label>
                    <p id="edit_review_category" class="mb-0"></p>
                </div>
                <div class="mb-3" id="edit_review_issue_container" style="display: none;">
                    <label class="form-label fw-bold">Issue:</label>
                    <p id="edit_review_issue" class="mb-0"></p>
                </div>
                <div class="mb-3" id="edit_review_location_container" style="display: none;">
                    <label class="form-label fw-bold">Location:</label>
                    <p id="edit_review_location" class="mb-0"></p>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Problem Type:</label>
                    <p id="edit_review_description" class="mb-0" style="white-space: pre-wrap;"></p>
                </div>
                <div class="mb-3" id="edit_review_current_image_container" style="display: none;">
                    <label class="form-label fw-bold">Current Photo:</label>
                    <div>
                        <img id="edit_review_current_image" src="" alt="Current" class="img-fluid" style="max-height: 200px; border-radius: 8px;">
                    </div>
                </div>
                <div class="mb-3" id="edit_review_new_image_container" style="display: none;">
                    <label class="form-label fw-bold">New Photo:</label>
                    <div>
                        <img id="edit_review_new_image" src="" alt="New Preview" class="img-fluid" style="max-height: 200px; border-radius: 8px;">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="backToEditForm()">Back to Edit</button>
                <button type="button" class="btn btn-primary" onclick="confirmEditSubmit()">Update Concern</button>
            </div>
        </div>
    </div>
</div>

<!-- Assign Modal -->
<div class="modal fade" id="assignConcernModal" tabindex="-1" aria-labelledby="assignConcernModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="assignConcernModalLabel">Assign Concern</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="assignConcernForm" method="POST">
                @csrf
                <div class="modal-body">
                    <input type="hidden" id="assignConcernId" name="concern_id" value="">
                    <div class="mb-3">
                        <label for="assigned_to" class="form-label">Assign to Maintenance Staff</label>
                        <select class="form-select" id="assigned_to" name="assigned_to" required>
                            <option value="">Select maintenance staff</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-user-plus"></i> Assign</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Archive Modal -->
<div class="modal fade" id="archiveModal" tabindex="-1" aria-labelledby="archiveModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="archiveModalLabel">Archive Concern</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="archiveConcernForm" method="POST">
                @csrf
                <div class="modal-body">
                    <input type="hidden" id="archiveConcernId" name="concern_id" value="">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> This concern will be archived and hidden from your active list.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning"><i class="fas fa-archive"></i> Archive</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Soft Delete Modal -->
<div class="modal fade" id="softDeleteModal" tabindex="-1" aria-labelledby="softDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="softDeleteModalLabel">Delete Concern</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="softDeleteConcernForm" method="POST">
                @csrf
                <div class="modal-body">
                    <input type="hidden" id="softDeleteConcernId" name="concern_id" value="">
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> This concern will be moved to deleted. You can restore it later from the Deleted tab.
                    </div>
                    <p class="mb-0">Are you sure you want to delete this concern?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Permanent Delete Modal -->
<div class="modal fade" id="permanentDeleteModal" tabindex="-1" aria-labelledby="permanentDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="permanentDeleteModalLabel"><i class="fas fa-exclamation-triangle"></i> Permanently Delete Concern</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="permanentDeleteConcernId" value="">
                <div class="alert alert-danger">
                    <i class="fas fa-ban"></i> <strong>Warning:</strong> This action cannot be undone! The concern will be permanently removed.
                </div>
                <p class="mb-0">Are you sure you want to permanently delete this concern?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmPermanentDeleteBtn"><i class="fas fa-ban"></i> Permanent Delete</button>
            </div>
        </div>
    </div>
</div>

<!-- Duplicate Concern Warning Modal -->
@if(session('warning'))
<div class="modal fade" id="duplicateConcernWarningModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Concern Already Reported</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <div class="mb-3">
                    <i class="fas fa-tools fa-3x text-warning"></i>
                </div>
                <p class="mb-0">{{ session('warning') }}</p>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Got it</button>
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var warningModal = new bootstrap.Modal(document.getElementById('duplicateConcernWarningModal'));
        warningModal.show();
    });
</script>
@endif

<!-- New Concern Modal -->
<div class="modal fade" id="newConcernModal" tabindex="-1" aria-labelledby="newConcernModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newConcernModalLabel">Submit New Concern</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="newConcernForm" action="{{ route('concerns.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                {{-- hidden title populated from Issue dropdown --}}
                <input type="hidden" id="new_title" name="title">
                <div class="modal-body">

                    <div class="mb-3">
                        <label for="new_category_id" class="form-label">Category *</label>
                        <select class="form-select" id="new_category_id" name="category_id" required onchange="handleNewCategoryChange()">
                            <option value="" disabled selected>Select a category</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}" data-name="{{ strtolower(trim($category->name)) }}" data-issues='@json($category->issues ?? [])'>{{ $category->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Issue dropdown -->
                    <div class="mb-3" id="new_issue_container" style="display: none;">
                        <label for="new_issue" class="form-label">Issue *</label>
                        <select class="form-select" id="new_issue" name="_issue">
                            <option value="" disabled selected>Select an issue</option>
                        </select>
                    </div>

                    <!-- Location (single flat dropdown for all categories) -->
                    <div class="mb-3" id="new_location_container" style="display: none;">
                        <label for="new_location" class="form-label">Location *</label>
                        <select class="form-select" id="new_location" name="location">
                            <option value="" disabled selected>Select a location</option>
                            @foreach($facilities->groupBy('type') as $type => $group)
                                <optgroup label="{{ ucfirst($type) }}">
                                    @foreach($group as $facility)
                                        <option value="{{ $facility->name }}">{{ $facility->name }}</option>
                                    @endforeach
                                </optgroup>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-3" id="new_problem_type_container">
                        <label for="new_description" class="form-label">Problem Type *</label>
                        <select class="form-select" id="new_description" name="description" disabled>
                            <option value="" disabled selected>Select an issue first</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="new_details" class="form-label">Additional description <span class="text-muted">(Optional)</span></label>
                        <textarea class="form-control" id="new_details" name="details" rows="3" maxlength="2000" placeholder="Add useful details about the issue, if any."></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="new_image" class="form-label">Upload Photo (Optional)</label>
                        <input type="file" class="form-control" id="new_image" name="image" 
                            accept="image/*">
                        <small class="text-muted d-block" style="font-size: 12px;">Supported formats: JPEG, PNG, JPG (Max 2MB)</small>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="showReviewModal()">Review</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Review Concern Modal -->
<div class="modal fade" id="reviewConcernModal" tabindex="-1" aria-labelledby="reviewConcernModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="reviewConcernModalLabel">Review Your Concern</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold">Category:</label>
                    <p id="review_category" class="mb-0"></p>
                </div>
                <div class="mb-3" id="review_issue_container" style="display: none;">
                    <label class="form-label fw-bold">Issue:</label>
                    <p id="review_issue" class="mb-0"></p>
                </div>
                <div class="mb-3" id="review_location_container" style="display: none;">
                    <label class="form-label fw-bold">Location:</label>
                    <p id="review_location" class="mb-0"></p>
                </div>
                <div class="mb-3" id="review_problem_type_container">
                    <label class="form-label fw-bold">Problem Type:</label>
                    <p id="review_description" class="mb-0" style="white-space: pre-wrap;"></p>
                </div>
                <div class="mb-3" id="review_details_container">
                    <label class="form-label fw-bold">Additional Description:</label>
                    <p id="review_details" class="mb-0" style="white-space: pre-wrap;"></p>
                </div>
                <div class="mb-3" id="review_image_container" style="display: none;">
                    <label class="form-label fw-bold">Photo:</label>
                    <div>
                        <img id="review_image" src="" alt="Preview" class="img-fluid" style="max-height: 200px; border-radius: 8px;">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="backToEdit()">Back to Edit</button>
                <button type="button" class="btn btn-primary" onclick="confirmSubmit()">Submit Concern</button>
            </div>
        </div>
    </div>
</div>

<script>
const concernProblemTypes = {
    aircon: ['Not working', 'Weak cooling', 'Leaking', 'Noisy', 'Bad smell', 'Remote/control issue'],
    'air conditioner': ['Not working', 'Weak cooling', 'Leaking', 'Noisy', 'Bad smell', 'Remote/control issue'],
    cleaning: ['Needs cleaning', 'Trash removal', 'Spill cleanup', 'Bad odor', 'Dusty area'],
    door: ['Broken lock', 'Damaged handle', 'Hard to open/close', 'Loose hinge', 'Misaligned door'],
    window: ['Broken glass', 'Stuck window', 'Loose frame', 'Leaking', 'Lock issue'],
    'electric outlet': ['No power', 'Loose socket', 'Sparking', 'Damaged cover', 'Burnt smell'],
    outlet: ['No power', 'Loose socket', 'Sparking', 'Damaged cover', 'Burnt smell'],
    lights: ['Not working', 'Flickering', 'Dim light', 'Broken switch', 'Exposed wiring'],
    light: ['Not working', 'Flickering', 'Dim light', 'Broken switch', 'Exposed wiring'],
    projector: ['Not working', 'No display', 'Blurry display', 'No sound', 'Remote/control issue'],
    internet: ['No connection', 'Slow connection', 'Intermittent connection', 'Router/access point issue'],
    wifi: ['No connection', 'Slow connection', 'Intermittent connection', 'Router/access point issue'],
    toilet: ['Clogged', 'Leaking', 'No water', 'Broken flush', 'Bad odor'],
    faucet: ['Leaking', 'No water', 'Low pressure', 'Broken handle', 'Loose fixture'],
    chair: ['Broken leg', 'Loose part', 'Damaged seat', 'Missing chair'],
    table: ['Broken leg', 'Loose part', 'Damaged surface', 'Unstable table'],
};

const defaultProblemTypes = ['Not working', 'Damaged', 'Leaking', 'Noisy', 'Missing part', 'Needs repair', 'Needs cleaning'];

function normalizeProblemKey(value) {
    return String(value || '').toLowerCase().trim();
}

function getProblemTypesForIssue(issue) {
    const key = normalizeProblemKey(issue);

    if (concernProblemTypes[key]) {
        return concernProblemTypes[key];
    }

    const partialMatch = Object.keys(concernProblemTypes).find(problemKey => key.includes(problemKey) || problemKey.includes(key));
    return partialMatch ? concernProblemTypes[partialMatch] : defaultProblemTypes;
}

function getIssueName(issue) {
    return typeof issue === 'string' ? issue : (issue && issue.name ? issue.name : '');
}

function getIssueProblemTypes(issue) {
    return typeof issue === 'object' && Array.isArray(issue.problem_types) ? issue.problem_types : [];
}

function populateProblemTypeSelect(selectElement, issue, selectedValue = '', explicitProblemTypes = null) {
    if (!selectElement) return;

    const problemTypeContainer = document.getElementById(selectElement.id + '_container')
        || (selectElement.id === 'new_description' ? document.getElementById('new_problem_type_container') : null);
    const hasExplicitProblemTypes = Array.isArray(explicitProblemTypes);
    const problemTypes = issue ? (hasExplicitProblemTypes ? explicitProblemTypes : getProblemTypesForIssue(issue)) : [];
    selectElement.innerHTML = '<option value="" disabled selected>' + (issue ? 'Select a problem type' : 'Select an issue first') + '</option>';
    selectElement.value = '';

    problemTypes.forEach(function(problemType) {
        const option = document.createElement('option');
        option.value = problemType;
        option.textContent = problemType;
        if (problemType === selectedValue) {
            option.selected = true;
        }
        selectElement.appendChild(option);
    });

    if (issue && problemTypes.length > 0) {
        if (problemTypeContainer) problemTypeContainer.style.display = 'block';
        selectElement.removeAttribute('disabled');
        selectElement.setAttribute('required', 'required');
    } else {
        if (problemTypeContainer) problemTypeContainer.style.display = 'none';
        selectElement.setAttribute('disabled', 'disabled');
        selectElement.removeAttribute('required');
    }
}

function showReviewModal() {
    // Validate form first
    const form = document.getElementById('newConcernForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    // Get form values
    const categorySelect = document.getElementById('new_category_id');
    const categoryText = categorySelect.options[categorySelect.selectedIndex]?.text || '';
    
    const issueSelect = document.getElementById('new_issue');
    const issueText = issueSelect.options[issueSelect.selectedIndex]?.text || '';
    
    const locationSelect = document.getElementById('new_location');
    const locationText = locationSelect.options[locationSelect.selectedIndex]?.text || '';
    
    const problemTypeSelect = document.getElementById('new_description');
    const description = problemTypeSelect && !problemTypeSelect.disabled
        ? (problemTypeSelect.options[problemTypeSelect.selectedIndex]?.text || '')
        : '';
    const details = document.getElementById('new_details')?.value.trim() || '';
    
    const imageInput = document.getElementById('new_image');
    const imageFile = imageInput.files[0];

    // Populate review modal
    document.getElementById('review_category').textContent = categoryText;
    
    if (issueText && issueText !== 'Select an issue') {
        document.getElementById('review_issue').textContent = issueText;
        document.getElementById('review_issue_container').style.display = 'block';
    } else {
        document.getElementById('review_issue_container').style.display = 'none';
    }
    
    if (locationText && locationText !== 'Select a location') {
        document.getElementById('review_location').textContent = locationText;
        document.getElementById('review_location_container').style.display = 'block';
    } else {
        document.getElementById('review_location_container').style.display = 'none';
    }
    
    const reviewProblemTypeContainer = document.getElementById('review_problem_type_container');
    if (description) {
        document.getElementById('review_description').textContent = description;
        if (reviewProblemTypeContainer) reviewProblemTypeContainer.style.display = 'block';
    } else {
        document.getElementById('review_description').textContent = '';
        if (reviewProblemTypeContainer) reviewProblemTypeContainer.style.display = 'none';
    }

    // Show the optional free-form description in the submission preview too.
    document.getElementById('review_details').textContent = details || 'No additional description provided.';
    
    // Handle image preview
    if (imageFile) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('review_image').src = e.target.result;
            document.getElementById('review_image_container').style.display = 'block';
        };
        reader.readAsDataURL(imageFile);
    } else {
        document.getElementById('review_image_container').style.display = 'none';
    }

    // Hide new concern modal and show review modal
    const newConcernModal = bootstrap.Modal.getInstance(document.getElementById('newConcernModal'));
    newConcernModal.hide();
    
    const reviewModal = new bootstrap.Modal(document.getElementById('reviewConcernModal'));
    reviewModal.show();
}

function backToEdit() {
    // Hide review modal and show new concern modal
    const reviewModal = bootstrap.Modal.getInstance(document.getElementById('reviewConcernModal'));
    reviewModal.hide();
    
    const newConcernModal = new bootstrap.Modal(document.getElementById('newConcernModal'));
    newConcernModal.show();
}

function confirmSubmit() {
    Swal.fire({
        title: 'Are you sure?',
        text: 'Do you want to submit this concern?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, Submit',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            // Trigger form submission event (not direct submit)
            const form = document.getElementById('newConcernForm');
            const event = new Event('submit', { cancelable: true, bubbles: true });
            form.dispatchEvent(event);
        }
    });
}

function showEditReviewModal() {
    // Validate form first
    const form = document.getElementById('editConcernForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    // Get form values from edit modal
    const categorySelect = document.querySelector('#editConcernModal select[name="category_id"]');
    const categoryText = categorySelect?.options[categorySelect.selectedIndex]?.text || '';
    
    const issueSelect = document.querySelector('#editConcernModal select[name="_issue"]');
    const issueText = issueSelect?.options[issueSelect.selectedIndex]?.text || '';
    
    const locationSelect = document.querySelector('#editConcernModal select[name="location"]');
    const locationText = locationSelect?.options[locationSelect.selectedIndex]?.text || '';
    
    const descriptionSelect = document.querySelector('#editConcernModal select[name="description"]');
    const description = descriptionSelect?.options[descriptionSelect.selectedIndex]?.text || '';
    
    const imageInput = document.querySelector('#editConcernModal input[name="image"]');
    const imageFile = imageInput?.files[0];
    
    const currentImageElement = document.querySelector('#editConcernModal img[id*="current_image"]');
    const currentImageSrc = currentImageElement?.src || '';

    // Populate edit review modal
    document.getElementById('edit_review_category').textContent = categoryText;
    
    if (issueText && issueText !== 'Select an issue' && issueText !== '') {
        document.getElementById('edit_review_issue').textContent = issueText;
        document.getElementById('edit_review_issue_container').style.display = 'block';
    } else {
        document.getElementById('edit_review_issue_container').style.display = 'none';
    }
    
    if (locationText && locationText !== 'Select a location' && locationText !== '') {
        document.getElementById('edit_review_location').textContent = locationText;
        document.getElementById('edit_review_location_container').style.display = 'block';
    } else {
        document.getElementById('edit_review_location_container').style.display = 'none';
    }
    
    document.getElementById('edit_review_description').textContent = description;
    
    // Handle current image
    if (currentImageSrc && !currentImageSrc.includes('placeholder')) {
        document.getElementById('edit_review_current_image').src = currentImageSrc;
        document.getElementById('edit_review_current_image_container').style.display = 'block';
    } else {
        document.getElementById('edit_review_current_image_container').style.display = 'none';
    }
    
    // Handle new image preview
    if (imageFile) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('edit_review_new_image').src = e.target.result;
            document.getElementById('edit_review_new_image_container').style.display = 'block';
        };
        reader.readAsDataURL(imageFile);
    } else {
        document.getElementById('edit_review_new_image_container').style.display = 'none';
    }

    // Hide edit concern modal and show edit review modal
    const editConcernModal = bootstrap.Modal.getInstance(document.getElementById('editConcernModal'));
    editConcernModal.hide();
    
    const editReviewModal = new bootstrap.Modal(document.getElementById('editReviewModal'));
    editReviewModal.show();
}

function backToEditForm() {
    // Hide edit review modal and show edit concern modal
    const editReviewModal = bootstrap.Modal.getInstance(document.getElementById('editReviewModal'));
    editReviewModal.hide();
    
    const editConcernModal = new bootstrap.Modal(document.getElementById('editConcernModal'));
    editConcernModal.show();
}

function confirmEditSubmit() {
    Swal.fire({
        title: 'Are you sure?',
        text: 'Do you want to update this concern?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, Update',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            // Submit the edit form
            document.getElementById('editConcernForm').submit();
        }
    });
}

function handleEditCategoryChange() {
    const categorySelect = document.getElementById('edit_category_id');
    const issueContainer = document.getElementById('edit_issue_container');
    const issueSelect = document.getElementById('edit_issue');
    const problemTypeSelect = document.getElementById('edit_description');
    const locationContainer = document.getElementById('edit_location_container');
    const locationSelect = document.getElementById('edit_location');
    
    if (!categorySelect) return;
    
    const selectedOption = categorySelect.options[categorySelect.selectedIndex];
    
    // Get issues from the data-issues attribute
    let issues = [];
    try {
        const issuesData = selectedOption ? selectedOption.getAttribute('data-issues') : null;
        issues = issuesData ? JSON.parse(issuesData) : [];
    } catch (e) {
        console.error('Error parsing issues:', e);
        issues = [];
    }
    
    if (issues.length === 0) {
        // No issues for this category
        if (issueContainer) issueContainer.style.display = 'none';
        if (issueSelect) {
            issueSelect.removeAttribute('required');
            issueSelect.innerHTML = '<option value="" disabled selected>Select an issue</option>';
        }
        populateProblemTypeSelect(problemTypeSelect, '');
    } else {
        // Has issues — show the dropdown and populate it
        if (issueContainer) issueContainer.style.display = 'block';
        if (issueSelect) {
            issueSelect.setAttribute('required', 'required');
            issueSelect.innerHTML = '<option value="" disabled selected>Select an issue</option>';
            issues.forEach(function(issue) {
                const issueName = getIssueName(issue);
                const opt = document.createElement('option');
                opt.value = issueName;
                opt.textContent = issueName;
                opt.dataset.problemTypes = JSON.stringify(getIssueProblemTypes(issue));
                issueSelect.appendChild(opt);
            });
            
            // Add change listener to update hidden title field
            issueSelect.addEventListener('change', function() {
                // Create or update hidden title field
                let titleInput = document.querySelector('#editConcernForm input[name="title"]');
                if (!titleInput) {
                    titleInput = document.createElement('input');
                    titleInput.type = 'hidden';
                    titleInput.name = 'title';
                    document.getElementById('editConcernForm').appendChild(titleInput);
                }
                titleInput.value = this.value;
                const selectedIssue = this.options[this.selectedIndex];
                const problemTypes = selectedIssue?.dataset.problemTypes ? JSON.parse(selectedIssue.dataset.problemTypes) : [];
                populateProblemTypeSelect(problemTypeSelect, this.value, '', problemTypes);
            });
        }
        populateProblemTypeSelect(problemTypeSelect, '');
    }
    
    // Show location dropdown for all categories
    if (locationContainer) locationContainer.style.display = 'block';
    if (locationSelect) locationSelect.setAttribute('required', 'required');
}

function handleNewCategoryChange() {
    const categorySelect = document.getElementById('new_category_id');
    const issueContainer = document.getElementById('new_issue_container');
    const issueSelect = document.getElementById('new_issue');
    const locationContainer = document.getElementById('new_location_container');
    const locationSelect = document.getElementById('new_location');
    const titleInput = document.getElementById('new_title');
    const problemTypeSelect = document.getElementById('new_description');
    
    if (!categorySelect) return;
    
    const selectedOption = categorySelect.options[categorySelect.selectedIndex];
    
    // Get issues from the data-issues attribute
    let issues = [];
    try {
        const issuesData = selectedOption ? selectedOption.getAttribute('data-issues') : null;
        issues = issuesData ? JSON.parse(issuesData) : [];
    } catch (e) {
        console.error('Error parsing issues:', e);
        issues = [];
    }
    
    if (issues.length === 0) {
        // No issues for this category - set title to category name
        if (issueContainer) issueContainer.style.display = 'none';
        if (issueSelect) {
            issueSelect.removeAttribute('required');
            issueSelect.innerHTML = '<option value="" disabled selected>Select an issue</option>';
        }
        // Set title to category name when no issues
        if (titleInput) {
            const categoryName = selectedOption ? selectedOption.text : '';
            titleInput.value = categoryName;
        }
        // For categories without issues (like Cleaning), set a default problem type
        if (problemTypeSelect) {
            problemTypeSelect.removeAttribute('required');
            problemTypeSelect.disabled = false;
            problemTypeSelect.innerHTML = '<option value="General" selected>General</option>';
        }
    } else {
        // Has issues — show the dropdown and populate it
        if (issueContainer) issueContainer.style.display = 'block';
        if (issueSelect) {
            issueSelect.setAttribute('required', 'required');
            issueSelect.innerHTML = '<option value="" disabled selected>Select an issue</option>';
            issues.forEach(function(issue) {
                const issueName = getIssueName(issue);
                const opt = document.createElement('option');
                opt.value = issueName;
                opt.textContent = issueName;
                opt.dataset.problemTypes = JSON.stringify(getIssueProblemTypes(issue));
                issueSelect.appendChild(opt);
            });
        }
        // Clear title when issues are available (will be set when issue is selected)
        if (titleInput) titleInput.value = '';
        populateProblemTypeSelect(problemTypeSelect, '');
    }
    
    // Show location dropdown for all categories
    if (locationContainer) locationContainer.style.display = 'block';
    if (locationSelect) locationSelect.setAttribute('required', 'required');
}

// Handle issue change in new concern form to update title
document.addEventListener('DOMContentLoaded', function() {
    const newIssueSelect = document.getElementById('new_issue');
    if (newIssueSelect) {
        newIssueSelect.addEventListener('change', function() {
            const titleInput = document.getElementById('new_title');
            if (titleInput) {
                titleInput.value = this.value;
            }
            const selectedIssue = this.options[this.selectedIndex];
            const problemTypes = selectedIssue?.dataset.problemTypes ? JSON.parse(selectedIssue.dataset.problemTypes) : [];
            populateProblemTypeSelect(document.getElementById('new_description'), this.value, '', problemTypes);
        });
    }
});

function updateAutoDeletePeriod(days) {
    if (confirm('Set auto-delete period to ' + days + ' days? Concerns deleted longer than this will be automatically removed.')) {
        fetch('{{ route('saveAutoDeletePreference') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({ days: parseInt(days), module: 'concerns' })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Auto-delete period updated to ' + days + ' days');
                location.reload(); // Reload to show updated list
            } else {
                alert('Error saving preference: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error saving preference');
        });
    } else {
        // Reset the dropdown to current value
        document.getElementById('autoDeleteDays').value = '{{ $days ?? 15 }}';
    }
}
</script>
<style>
.context-menu {
    position: fixed;
    z-index: 1000;
    display: none;
    background: white;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-shadow: 2px 2px 10px rgba(0,0,0,0.2);
    min-width: 180px;
}
.context-menu ul {
    list-style: none;
    padding: 0;
    margin: 0;
}
.context-menu ul li {
    border-bottom: 1px solid #eee;
}
.context-menu ul li:last-child {
    border-bottom: none;
}
.context-menu ul li a {
    display: block;
    padding: 10px 15px;
    text-decoration: none;
    color: #333;
}
.context-menu ul li a:hover {
    background: #f5f5f5;
}
.context-menu ul li a i {
    margin-right: 8px;
    width: 20px;
}
/* Dropdown fix for table */
.table .dropdown {
    position: static;
}
.table .dropdown-menu {
    position: absolute;
    z-index: 1000;
}
/* Bulk actions styling */
.bulk-actions {
    padding: 10px;
    background-color: #f8f9fa;
    border-radius: 4px;
    border: 1px solid #dee2e6;
}
.bulk-actions .btn-group {
    gap: 5px;
}
</style>

<script>
// Global variable for selected concern ID
window.selectedConcernId = null;
window.selectedConcernView = 'active';
// User role for conditional display
window.userRole = '{{ auth()->user()->role }}';

// Open New Concern Modal
function openNewConcernModal() {
    // Close any open modals to prevent conflicts
    const modalsToClose = ['viewConcernModal', 'editConcernModal', 'assignConcernModal', 'archiveModal', 'softDeleteModal', 'permanentDeleteModal', 'eventRequestModal', 'eventPreviewModal'];
    modalsToClose.forEach(id => {
        const modalElement = document.getElementById(id);
        if (modalElement) {
            const modalInstance = bootstrap.Modal.getInstance(modalElement);
            if (modalInstance) {
                modalInstance.hide();
            }
        }
    });

    // Reset form fields
    const catSel = document.getElementById('new_category_id');
    if (catSel) catSel.value = '';
    const issueCont = document.getElementById('new_issue_container');
    const issueEl = document.getElementById('new_issue');
    if (issueEl) { issueEl.value = ''; }
    const titleEl = document.getElementById('new_title');
    if (titleEl) titleEl.value = '';
    const locCont = document.getElementById('new_location_container');
    const locEl = document.getElementById('new_location');
    if (locCont) locCont.style.display = 'none';
    if (locEl) { locEl.value = ''; locEl.removeAttribute('required'); }
    const locTypeCont = document.getElementById('new_location_type_container');
    const locTypeEl = document.getElementById('new_location_type');
    if (locTypeCont) locTypeCont.style.display = 'none';
    if (locTypeEl) { locTypeEl.value = ''; locTypeEl.removeAttribute('required'); }
    const roomCont = document.getElementById('new_room_number_container');
    const roomEl = document.getElementById('new_room_number');
    if (roomCont) roomCont.style.display = 'none';
    if (roomEl) { roomEl.value = ''; roomEl.removeAttribute('required'); }
    const descEl = document.getElementById('new_description');
    populateProblemTypeSelect(descEl, '');

    const modal = new bootstrap.Modal(document.getElementById('newConcernModal'));
    modal.show();
}

// Handle form submission with duplicate detection
document.addEventListener('DOMContentLoaded', function() {
    const concernForm = document.querySelector('#newConcernModal form');
    if (concernForm) {
        concernForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            console.log('[DEBUG] Form submit event triggered');
            
            const formData = new FormData(this);
            
            // Log form data for debugging
            console.log('[DEBUG] Form data:');
            for (let pair of formData.entries()) {
                console.log(pair[0] + ': ' + pair[1]);
            }
            
            // Show loading in review modal button
            const reviewModal = document.getElementById('reviewConcernModal');
            const submitBtn = reviewModal?.querySelector('button.btn-primary');
            let originalButtonText = '';
            if (submitBtn) {
                originalButtonText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Submitting...';
            }
            
            fetch('{{ route("concerns.store") }}', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'same-origin'
            })
            .then(response => {
                console.log('[DEBUG] Response status:', response.status);
                if (response.status === 409) {
                    // Duplicate concern detected
                    return response.json().then(data => {
                        throw { duplicate: true, data: data };
                    });
                }
                if (!response.ok) {
                    return ImageUploadFeedback.readResponse(response);
                }
                return response.json();
            })
            .then(data => {
                console.log('[DEBUG] Success response:', data);
                // Success - close modal and reload
                const newConcernModalEl = document.getElementById('newConcernModal');
                const reviewModalEl = document.getElementById('reviewConcernModal');
                
                if (newConcernModalEl) {
                    const instance = bootstrap.Modal.getInstance(newConcernModalEl);
                    if (instance) instance.hide();
                }
                if (reviewModalEl) {
                    const instance = bootstrap.Modal.getInstance(reviewModalEl);
                    if (instance) instance.hide();
                }
                
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: data.message || 'Your concern has been submitted successfully.',
                    confirmButtonColor: '#3085d6'
                }).then(() => {
                    window.location.reload();
                });
            })
            .catch(error => {
                console.error('[DEBUG] Error:', error);
                // Re-enable submit button
                if (submitBtn && originalButtonText) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalButtonText;
                }
                
                if (error.duplicate) {
                    // Show duplicate concern alert with options
                    const concernData = error.data;
                    const reviewModalEl = document.getElementById('reviewConcernModal');
                    if (reviewModalEl) {
                        const instance = bootstrap.Modal.getInstance(reviewModalEl);
                        if (instance) instance.hide();
                    }
                    
                    // Store form data for potential override
                    window.pendingFormData = formData;
                    window.pendingSubmitButton = submitBtn;
                    window.pendingOriginalButtonText = originalButtonText;
                    
                    showDuplicateAlert(concernData);
                } else {
                    // Other error
                    ImageUploadFeedback.show(error.message || 'Failed to submit concern. Please try again.', 'Unable to submit concern');
                }
            });
        });
        
        // Listen for override submission event
        document.addEventListener('submitWithOverride', function() {
            if (window.pendingFormData && window.duplicateOverrideData) {
                const formData = window.pendingFormData;
                const submitButton = window.pendingSubmitButton;
                const originalButtonText = window.pendingOriginalButtonText;
                
                formData.append('override_duplicate', '1');
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Submitting...';
                
                fetch('{{ route("concerns.store") }}', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: data.message || 'Your concern has been submitted successfully.',
                        confirmButtonColor: '#3085d6'
                    }).then(() => {
                        window.location.reload();
                    });
                })
                .catch(err => {
                    submitButton.disabled = false;
                    submitButton.innerHTML = originalButtonText;
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to submit concern. Please try again.',
                        confirmButtonColor: '#d33'
                    });
                });
                
                // Clean up
                window.pendingFormData = null;
                window.pendingSubmitButton = null;
                window.pendingOriginalButtonText = null;
                window.duplicateOverrideData = null;
            }
        });
    }
});

// Function to view existing concern from duplicate alert
function viewExistingConcern(concernId) {
    Swal.close();
    viewConcernWithBack(concernId);
}

// Modified viewConcern function that supports a back button
function viewConcernWithBack(id, duplicateData = null) {
    // Store current concern ID for assign functionality
    window.currentConcernId = id;
    
    // Show loading state
    Swal.fire({
        title: '<i class="fas fa-ticket-alt me-2"></i>Loading Ticket Details...',
        html: '<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>',
        showConfirmButton: false,
        allowOutsideClick: false,
        width: '900px'
    });
    
    fetch('/concerns/' + id + '/modal-data', {
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    })
    .then(response => {
        console.log('Response status:', response.status);
        if (!response.ok) {
            return response.json().then(err => {
                throw new Error(err.error || 'Request failed with status ' + response.status);
            });
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.error
            });
            return;
        }
        
        const concern = data.concern;
        const categoryName = concern.categoryRelation ? concern.categoryRelation.name : 'N/A';
        const userName = concern.user ? concern.user.name : 'Unknown';
        const userRole = concern.user ? concern.user.role : '';
        const issueName = concern.issue || concern.title || 'N/A';
        
        const priorityClass = concern.priority === 'urgent' ? 'danger' : 
            (concern.priority === 'high' ? 'warning' : 
            (concern.priority === 'medium' ? 'info' : 'secondary'));
        
        const statusClass = concern.status === 'Resolved' ? 'success' : 
            (concern.status === 'In Progress' ? 'warning' : 
            (concern.status === 'Assigned' ? 'primary' : 'secondary'));
        
        let imageHtml = '';
        if (concern.image_path) {
            imageHtml = `
                <div class="mb-3 text-center">
                    <p class="text-start"><strong>Photo:</strong></p>
                    <img src="${concern.image_path}" alt="Concern photo" class="img-fluid rounded" style="max-width: 100%; max-height: 400px;">
                </div>
            `;
        }
        
        let resolutionHtml = '';
        if (concern.resolution_notes) {
            resolutionHtml = `
                <div class="alert alert-success mt-3 text-start">
                    <h6><strong>Resolution Notes:</strong></h6>
                    <p class="mb-1">${concern.resolution_notes}</p>
                    ${concern.resolved_at ? '<small class="text-muted">Resolved on: ' + concern.resolved_at + '</small>' : ''}
                </div>
            `;
        }
        
        const htmlContent = `
            <div style="text-align: left; max-height: 70vh; overflow-y: auto; padding: 10px;">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">${concern.title || (concern.description ? concern.description.substring(0, 40) + '...' : 'No Title')}</h5>
                    <div>
                        <span class="badge bg-${priorityClass} me-2">${concern.priority ? (concern.priority.charAt(0).toUpperCase() + concern.priority.slice(1)) : 'Not Set'} Priority</span>
                        <span class="badge bg-${statusClass}">${concern.status}</span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Ticket #:</strong> #${String(concern.id).padStart(4, '0')}</p>
                        <p><strong>Report Count:</strong> ${concern.report_count || 1}</p>
                        <p><strong>Category:</strong> ${categoryName}</p>
                        <p><strong>Location:</strong> ${concern.location || 'N/A'}</p>
                        <p><strong>Issue:</strong> ${issueName}</p>
                        <p><strong>Damaged Part:</strong> ${concern.damaged_part || 'N/A'}</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Priority:</strong> <span class="badge bg-${priorityClass}">${concern.priority || 'Not Set'}</span></p>
                        ${window.userRole === 'admin' || window.userRole === 'mis' || window.userRole === 'building_admin' ? '<p><strong>Reported by:</strong> ' + userName + '</p>' : ''}
                        <p><strong>Date Submitted:</strong> ${concern.created_at || 'N/A'}</p>
                        ${concern.assigned_at ? '<p><strong>Date Assigned:</strong> ' + concern.assigned_at + '</p>' : ''}
                        ${concern.in_progress_at ? '<p><strong>Date In Progress:</strong> ' + concern.in_progress_at + '</p>' : ''}
                        ${concern.resolved_at ? '<p><strong>Date Resolved:</strong> ' + concern.resolved_at + '</p>' : ''}
                        ${concern.cost ? '<p><strong>Cost:</strong> ₱' + parseFloat(concern.cost).toLocaleString('en-PH', {minimumFractionDigits: 2}) + '</p>' : ''}
                    </div>
                </div>
                <hr>
                <div class="row mt-3">
                    <div class="col-12">
                        <p><strong>Problem Type:</strong></p>
                        <p style="white-space: pre-wrap;">${concern.description || 'No description provided'}</p>
                        <p><strong>Additional Description:</strong></p>
                        <p style="white-space: pre-wrap;">${concern.details || 'No additional description provided.'}</p>
                        ${imageHtml}
                        ${resolutionHtml}
                    </div>
                </div>
            </div>
        `;
        
        // Configure buttons based on whether we came from duplicate alert
        const buttons = {
            showCloseButton: true,
            showConfirmButton: true,
            confirmButtonText: 'Close',
            confirmButtonColor: '#6c757d'
        };
        
        // Add back button if we came from duplicate alert
        if (duplicateData) {
            buttons.showDenyButton = true;
            buttons.denyButtonText = '<i class="fas fa-arrow-left me-1"></i> Back';
            buttons.denyButtonColor = '#6c757d';
        }
        
        Swal.fire({
            title: '<i class="fas fa-ticket-alt me-2"></i>Ticket #' + String(concern.id).padStart(4, '0') + ' Details',
            html: htmlContent,
            width: '900px',
            ...buttons,
            customClass: {
                popup: 'swal-wide-popup',
                htmlContainer: 'swal2-html-container'
            }
        }).then((result) => {
            // If user clicked the Back button, show the duplicate alert again
            if (result.isDenied && duplicateData) {
                showDuplicateAlert(duplicateData);
            }
        });
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Error loading concern details: ' + error.message
        });
    });
}

// Function to show duplicate alert (extracted for reuse)
function showDuplicateAlert(concernData) {
    Swal.fire({
        icon: 'warning',
        title: 'Ticket Already Exists',
        html: `
            <p>This same issue is already active as ticket <strong>#${concernData.concern_id}</strong>.</p>
            <p><strong>${concernData.issue}</strong> - <strong>${concernData.problem_type || 'Not specified'}</strong><br><strong>${concernData.location}</strong> · <strong>${concernData.status}</strong></p>
            <p>If this is your issue too, you will be linked to the existing ticket and notified when it is updated or resolved. Current report count: <strong>${concernData.report_count || 1}</strong>.</p>
            <p><a href="#" onclick="event.preventDefault(); viewConcernFromDuplicate(${concernData.concern_id}, ${JSON.stringify(concernData).replace(/"/g, '&quot;')});" style="color: #3085d6; text-decoration: underline; cursor: pointer;">Click here to view the ticket</a></p>
        `,
        showCancelButton: true,
        confirmButtonText: 'Link Me to Ticket',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#6c757d',
        customClass: {
            confirmButton: 'btn btn-primary',
            cancelButton: 'btn btn-secondary'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // User confirms it is the same issue, so link them to the existing ticket.
            window.duplicateOverrideData = concernData;
            const event = new CustomEvent('submitWithOverride');
            document.dispatchEvent(event);
        }
    });
}

// Function to view concern from duplicate alert with back button
function viewConcernFromDuplicate(concernId, concernData) {
    Swal.close();
    viewConcernWithBack(concernId, concernData);
}

// Handle category change for concerns modal
document.addEventListener('DOMContentLoaded', function() {

    const categorySelect = document.getElementById('new_category_id');
    const issueSelect = document.getElementById('new_issue');
    const titleHidden = document.getElementById('new_title');
    const problemTypeSelect = document.getElementById('new_description');
    const locationContainer = document.getElementById('new_location_container');
    const locationSelect = document.getElementById('new_location');

    // Per-category issue options (from database)
    const categoryIssues = {
        @foreach($categories as $cat)
        @if($cat->issues && count($cat->issues) > 0)
        '{{ strtolower($cat->name) }}': {!! json_encode($cat->issues) !!},
        @endif
        @endforeach
    };

    function populateIssues(categoryName) {
        const key = categoryName.toLowerCase().trim();
        const issues = categoryIssues[key] || [];
        const issueContainer = document.getElementById('new_issue_container');

        if (issues.length === 0) {
            // No issues for this category — hide the dropdown and clear it
            if (issueContainer) issueContainer.style.display = 'none';
            if (issueSelect) issueSelect.removeAttribute('required');
            issueSelect.innerHTML = '<option value="" disabled selected>Select an issue</option>';
            if (titleHidden) titleHidden.value = '';
            populateProblemTypeSelect(problemTypeSelect, '');
            return;
        }

        // Has issues — show the dropdown and populate it
        if (issueContainer) issueContainer.style.display = 'block';
        if (issueSelect) issueSelect.setAttribute('required', 'required');
        issueSelect.innerHTML = '<option value="" disabled selected>Select an issue</option>';
        issues.forEach(function(issue) {
            const issueName = getIssueName(issue);
            const opt = document.createElement('option');
            opt.value = issueName;
            opt.textContent = issueName;
            opt.dataset.problemTypes = JSON.stringify(getIssueProblemTypes(issue));
            issueSelect.appendChild(opt);
        });
        issueSelect.value = '';
        if (titleHidden) titleHidden.value = '';
        populateProblemTypeSelect(problemTypeSelect, '');
    }

    if (issueSelect) {
        issueSelect.addEventListener('change', function() {
            if (titleHidden) titleHidden.value = this.value;
            const selectedIssue = this.options[this.selectedIndex];
            const problemTypes = selectedIssue?.dataset.problemTypes ? JSON.parse(selectedIssue.dataset.problemTypes) : [];
            populateProblemTypeSelect(problemTypeSelect, this.value, '', problemTypes);
        });
    }

    if (categorySelect) {
        categorySelect.addEventListener('change', function() {
            const selectedOption = categorySelect.options[categorySelect.selectedIndex];
            const categoryName = selectedOption ? selectedOption.getAttribute('data-name') : '';

            populateIssues(categoryName);

            // Show location dropdown for all categories
            locationContainer.style.display = 'block';
            if (locationSelect) locationSelect.setAttribute('required', 'required');
        });
    }

});

// Auto-submit filter form on change
document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.getElementById('filterForm');
    if (filterForm) {
        const filterInputs = filterForm.querySelectorAll('select, input');
        
        filterInputs.forEach(input => {
            input.addEventListener('change', function() {
                filterForm.submit();
            });
            if (input.type === 'text') {
                input.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        filterForm.submit();
                    }
                });
            }
        });
    }
    
    // Same for archive and deleted filter forms
    ['archiveFilterForm', 'deletedFilterForm'].forEach(formId => {
        const form = document.getElementById(formId);
        if (form) {
            const inputs = form.querySelectorAll('select, input');
            inputs.forEach(input => {
                input.addEventListener('change', function() {
                    form.submit();
                });
                if (input.type === 'text') {
                    input.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') {
                            form.submit();
                        }
                    });
                }
            });
        }
    });
});

// Right-click handler
document.addEventListener('contextmenu', function(e) {
    const row = e.target.closest('tr[data-id]');
    if (row) {
        e.preventDefault();
        window.selectedConcernId = row.getAttribute('data-id');
        window.selectedConcernView = row.getAttribute('data-view') || 'active';
        
        // Hide all context menus first
        document.getElementById('contextMenu').style.display = 'none';
        document.getElementById('contextMenuArchive').style.display = 'none';
        document.getElementById('contextMenuDeleted').style.display = 'none';
        
        // Show appropriate context menu
        if (window.selectedConcernView === 'archive') {
            showContextMenu(e.pageX, e.pageY, 'contextMenuArchive');
        } else if (window.selectedConcernView === 'deleted') {
            showContextMenu(e.pageX, e.pageY, 'contextMenuDeleted');
        } else {
            showContextMenu(e.pageX, e.pageY, 'contextMenu');
        }
    }
});

// Long-press handler for mobile
let longPressTimer;
document.addEventListener('touchstart', function(e) {
    const row = e.target.closest('tr[data-id]');
    if (row) {
        longPressTimer = setTimeout(function() {
            window.selectedConcernId = row.getAttribute('data-id');
            window.selectedConcernView = row.getAttribute('data-view') || 'active';
            const touch = e.touches[0];
            
            // Hide all context menus first
            document.getElementById('contextMenu').style.display = 'none';
            document.getElementById('contextMenuArchive').style.display = 'none';
            document.getElementById('contextMenuDeleted').style.display = 'none';
            
            if (window.selectedConcernView === 'archive') {
                showContextMenu(touch.pageX, touch.pageY, 'contextMenuArchive');
            } else if (window.selectedConcernView === 'deleted') {
                showContextMenu(touch.pageX, touch.pageY, 'contextMenuDeleted');
            } else {
                showContextMenu(touch.pageX, touch.pageY, 'contextMenu');
            }
        }, 500);
    }
});

document.addEventListener('touchend', function() {
    clearTimeout(longPressTimer);
});

document.addEventListener('touchmove', function() {
    clearTimeout(longPressTimer);
});

function showContextMenu(x, y, menuId) {
    const menu = document.getElementById(menuId);
    menu.style.display = 'block';
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';
    
    const menuRect = menu.getBoundingClientRect();
    if (x + menuRect.width > window.innerWidth) {
        menu.style.left = (x - menuRect.width) + 'px';
    }
    if (y + menuRect.height > window.innerHeight) {
        menu.style.top = (y - menuRect.height) + 'px';
    }
}

// Hide context menu when clicking elsewhere
document.addEventListener('click', function() {
    document.getElementById('contextMenu').style.display = 'none';
    document.getElementById('contextMenuArchive').style.display = 'none';
    document.getElementById('contextMenuDeleted').style.display = 'none';
});

// Context menu actions
function contextView() {
    if (window.selectedConcernId) {
        viewConcern(window.selectedConcernId);
    }
}

function contextEdit() {
    if (window.selectedConcernId && window.selectedConcernView === 'active') {
        editConcern(window.selectedConcernId);
    }
}

function contextArchive() {
    if (window.selectedConcernId && window.selectedConcernView === 'active') {
        showArchiveModal(window.selectedConcernId);
    }
}

function contextDelete() {
    if (window.selectedConcernId && window.selectedConcernView === 'active') {
        softDeleteConcern(window.selectedConcernId);
    }
}

function contextRestore() {
    if (window.selectedConcernId && window.selectedConcernView === 'archive') {
        fetch('/concerns/' + window.selectedConcernId + '/restore', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Concern restored successfully!');
                location.reload();
            } else if (data.error) {
                alert(data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error restoring concern');
        });
    }
}

function contextDeleteFromArchive() {
    if (window.selectedConcernId && window.selectedConcernView === 'archive') {
        softDeleteArchivedConcern(window.selectedConcernId);
    }
}

function contextRestoreDeleted() {
    if (window.selectedConcernId && window.selectedConcernView === 'deleted') {
        fetch('/concerns/' + window.selectedConcernId + '/restore-deleted', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Concern restored successfully!');
                location.reload();
            } else if (data.error) {
                alert(data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error restoring concern');
        });
    }
}

function contextPermanentDelete() {
    if (window.selectedConcernId && window.selectedConcernView === 'deleted') {
        permanentDeleteConcern(window.selectedConcernId);
    }
}

// Soft Delete Functions
function softDeleteConcern(id) {
    confirmDelete({
        title: 'Delete Concern?',
        text: 'This concern will be moved to deleted. You can restore it later from the Deleted tab.',
        confirmButtonText: '<i class="fas fa-trash me-1"></i> Delete'
    }).then(result => {
        if (result.isConfirmed) {
            // Show loading
            getSwal().fire({
                title: 'Deleting...',
                html: '<div class="spinner-border text-danger"></div>',
                showConfirmButton: false,
                allowOutsideClick: false
            });
            
            fetch('/concerns/' + id + '/soft-delete', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then(response => response.json())
            .then(data => {
                if (data.success) {
                    swalToast('Concern deleted successfully!', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else if (data.error) {
                    swalAlert(data.error, 'error', 'Error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                swalAlert('Error deleting concern', 'error', 'Error');
            });
        }
    });
}

function softDeleteArchivedConcern(id) {
    confirmDelete({
        title: 'Delete Archived Concern?',
        text: 'This archived concern will be moved to deleted.',
        confirmButtonText: '<i class="fas fa-trash me-1"></i> Delete'
    }).then(result => {
        if (result.isConfirmed) {
            fetch('/concerns/' + id + '/soft-delete', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then(response => response.json())
            .then(data => {
                if (data.success) {
                    swalToast('Concern moved to deleted!', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else if (data.error) {
                    swalAlert(data.error, 'error', 'Error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                swalAlert('Error deleting concern', 'error', 'Error');
            });
        }
    });
}

// Permanent Delete Function
function permanentDeleteConcern(id) {
    confirmPermanentDelete({
        title: 'Permanently Delete?',
        html: '<p class="mb-2"><strong>Warning:</strong> This action cannot be undone!</p><p class="text-muted">The concern will be permanently removed from the database.</p>',
        confirmButtonText: '<i class="fas fa-ban me-1"></i> Delete Forever'
    }).then(result => {
        if (result.isConfirmed) {
            // Show loading
            getSwal().fire({
                title: 'Deleting Permanently...',
                html: '<div class="spinner-border text-danger"></div>',
                showConfirmButton: false,
                allowOutsideClick: false
            });
            
            fetch('/concerns/' + id + '/permanent-delete', {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    swalToast('Concern permanently deleted!', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    swalAlert(data.error || 'Failed to delete concern.', 'error', 'Error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                swalAlert('An error occurred. Please try again.', 'error', 'Error');
            });
        }
    });
}

// Send Follow-up Function
function sendFollowUp(id) {
    confirmAction('approve', {
        title: 'Send Follow-up?',
        text: 'Send a follow-up notification for this concern?',
        icon: 'question',
        confirmButtonText: '<i class="fas fa-bell me-1"></i> Send Follow-up',
        confirmButtonColor: '#0d6efd'
    }).then(result => {
        if (result.isConfirmed) {
            // Show loading state
            const button = event.target.closest('button');
            const originalHtml = button.innerHTML;
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            
            fetch('/concerns/' + id + '/send-follow-up', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    swalToast(data.message || 'Follow-up notification sent successfully!', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else if (data.error) {
                    swalAlert(data.error, 'error', 'Error');
                    button.disabled = false;
                    button.innerHTML = originalHtml;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                swalAlert('Error sending follow-up notification', 'error', 'Error');
                button.disabled = false;
                button.innerHTML = originalHtml;
            });
        }
    });
}

</script>
@include('partials.ticket-bulk-actions', ['bulkResource' => 'concerns'])
<script>
// View Concern Modal
// View Concern Modal using SweetAlert2
function viewConcern(id) {
    // Store current concern ID for assign functionality
    window.currentConcernId = id;
    
    // Show loading state
    Swal.fire({
        title: '<i class="fas fa-ticket-alt me-2"></i>Loading Ticket Details...',
        html: '<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>',
        showConfirmButton: false,
        allowOutsideClick: false,
        width: '900px'
    });
    
    fetch('/concerns/' + id + '/modal-data', {
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    })
    .then(response => {
        console.log('Response status:', response.status);
        if (!response.ok) {
            return response.json().then(err => {
                throw new Error(err.error || 'Request failed with status ' + response.status);
            });
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.error
            });
            return;
        }
        
        const concern = data.concern;
        const categoryName = concern.categoryRelation ? concern.categoryRelation.name : 'N/A';
        const userName = concern.user ? concern.user.name : 'Unknown';
        const userRole = concern.user ? concern.user.role : '';
        const issueName = concern.issue || concern.title || 'N/A';
        
        const priorityClass = concern.priority === 'urgent' ? 'danger' : 
            (concern.priority === 'high' ? 'warning' : 
            (concern.priority === 'medium' ? 'info' : 'secondary'));
        
        const statusClass = concern.status === 'Resolved' ? 'success' : 
            (concern.status === 'In Progress' ? 'warning' : 
            (concern.status === 'Assigned' ? 'primary' : 'secondary'));
        
        let imageHtml = '';
        if (concern.image_path) {
            imageHtml = `
                <div class="mb-3 text-center">
                    <p class="text-start"><strong>Photo:</strong></p>
                    <img src="${concern.image_path}" alt="Concern photo" class="img-fluid rounded" style="max-width: 100%; max-height: 400px;">
                </div>
            `;
        }
        
        let resolutionHtml = '';
        if (concern.resolution_notes) {
            resolutionHtml = `
                <div class="alert alert-success mt-3 text-start">
                    <h6><strong>Resolution Notes:</strong></h6>
                    <p class="mb-1">${concern.resolution_notes}</p>
                    ${concern.resolved_at ? '<small class="text-muted">Resolved on: ' + concern.resolved_at + '</small>' : ''}
                </div>
            `;
        }
        
        const htmlContent = `
            <div style="text-align: left; max-height: 70vh; overflow-y: auto; padding: 10px;">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">${concern.title || (concern.description ? concern.description.substring(0, 40) + '...' : 'No Title')}</h5>
                    <div>
                        <span class="badge bg-${priorityClass} me-2">${concern.priority ? (concern.priority.charAt(0).toUpperCase() + concern.priority.slice(1)) : 'Not Set'} Priority</span>
                        <span class="badge bg-${statusClass}">${concern.status}</span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Ticket #:</strong> #${String(concern.id).padStart(4, '0')}</p>
                        <p><strong>Report Count:</strong> ${concern.report_count || 1}</p>
                        <p><strong>Category:</strong> ${categoryName}</p>
                        <p><strong>Location:</strong> ${concern.location || 'N/A'}</p>
                        <p><strong>Issue:</strong> ${issueName}</p>
                        <p><strong>Damaged Part:</strong> ${concern.damaged_part || 'N/A'}</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Priority:</strong> <span class="badge bg-${priorityClass}">${concern.priority || 'Not Set'}</span></p>
                        ${window.userRole === 'admin' || window.userRole === 'mis' || window.userRole === 'building_admin' ? '<p><strong>Reported by:</strong> ' + userName + '</p>' : ''}
                        <p><strong>Date Submitted:</strong> ${concern.created_at || 'N/A'}</p>
                        ${concern.assigned_at ? '<p><strong>Date Assigned:</strong> ' + concern.assigned_at + '</p>' : ''}
                        ${concern.in_progress_at ? '<p><strong>Date In Progress:</strong> ' + concern.in_progress_at + '</p>' : ''}
                        ${concern.resolved_at ? '<p><strong>Date Resolved:</strong> ' + concern.resolved_at + '</p>' : ''}
                        ${concern.cost ? '<p><strong>Cost:</strong> ₱' + parseFloat(concern.cost).toLocaleString('en-PH', {minimumFractionDigits: 2}) + '</p>' : ''}
                    </div>
                </div>
                <hr>
                <div class="row mt-3">
                    <div class="col-12">
                        <p><strong>Problem Type:</strong></p>
                        <p style="white-space: pre-wrap;">${concern.description || 'No description provided'}</p>
                        <p><strong>Additional Description:</strong></p>
                        <p style="white-space: pre-wrap;">${concern.details || 'No additional description provided.'}</p>
                        ${imageHtml}
                        ${resolutionHtml}
                    </div>
                </div>
            </div>
        `;
        
        const canManageWorkflow = {{ in_array(auth()->user()->role, ['admin', 'building_admin', 'school_admin', 'academic_head', 'mis']) ? 'true' : 'false' }};
        const workflowButton = canManageWorkflow && concern.report_id && concern.status !== 'Resolved' && concern.status !== 'Closed'
            ? (concern.status === 'Pending'
                ? { text: '<i class="fas fa-user-plus me-1"></i> Assign', color: '#0d6efd', action: () => assignTicketReport(concern.report_id, categoryName) }
                : concern.status === 'Assigned'
                    ? { text: '<i class="fas fa-play me-1"></i> Start work', color: '#f0ad4e', action: () => updateTicketReportStatus(concern.report_id, 'In Progress') }
                    : { text: '<i class="fas fa-check me-1"></i> Complete', color: '#198754', action: () => completeTicketReport(concern.report_id) })
            : null;

        Swal.fire({
            title: '<i class="fas fa-ticket-alt me-2"></i>Ticket #' + String(concern.id).padStart(4, '0') + ' Details',
            html: htmlContent,
            width: '900px',
            showCloseButton: true,
            showConfirmButton: !!workflowButton,
            confirmButtonText: workflowButton ? workflowButton.text : 'Close',
            confirmButtonColor: workflowButton ? workflowButton.color : '#6c757d',
            showCancelButton: !!workflowButton,
            cancelButtonText: 'Close',
            customClass: {
                popup: 'swal-wide-popup',
                htmlContainer: 'swal2-html-container'
            }
        }).then((result) => {
            if (result.isConfirmed && workflowButton) {
                workflowButton.action();
            }
        });
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Error loading concern details: ' + error.message
        });
    });
}

function ticketWorkflowRequest(url, payload) {
    return fetch(url, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
    }).then(async response => {
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.success) throw new Error(data.error || data.message || 'Unable to update the ticket.');
        return data;
    });
}

function updateTicketReportStatus(reportId, status) {
    Swal.fire({ title: 'Updating ticket...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    ticketWorkflowRequest('/reports/' + reportId + '/update-status', { status })
        .then(data => Swal.fire({ icon: 'success', title: 'Updated', text: data.message, timer: 1400, showConfirmButton: false }).then(() => location.reload()))
        .catch(error => Swal.fire({ icon: 'error', title: 'Unable to update ticket', text: error.message }));
}

function assignTicketReport(reportId, categoryName) {
    const isTechnologyCategory = String(categoryName || '').trim().toLowerCase() === 'technology/internet';
    const staffLabel = isTechnologyCategory ? 'MIS staff' : 'maintenance staff';
    const staffEndpoint = isTechnologyCategory ? '/admin/mis-users' : '/admin/maintenance-users';

    fetch(staffEndpoint, { headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' } })
        .then(response => response.json())
        .then(data => {
            if (!data.users || !data.users.length) {
                return Swal.fire({
                    icon: 'warning',
                    title: 'No ' + staffLabel + ' available',
                    text: 'Add or activate a staff member before assigning this ticket.',
                    showCancelButton: true,
                    confirmButtonText: isTechnologyCategory ? 'Close' : 'Open staff management'
                }).then(result => {
                    if (result.isConfirmed && !isTechnologyCategory) window.location.href = '/admin/management?tab=staff';
                    return null;
                });
            }
            const inputOptions = Object.fromEntries(data.users.map(user => [user.id, user.name]));
            return Swal.fire({ title: 'Assign ticket', input: 'select', inputOptions, inputPlaceholder: 'Select ' + staffLabel, showCancelButton: true, confirmButtonText: 'Assign', inputValidator: value => !value && 'Select a staff member.' })
                .then(result => result.isConfirmed ? ticketWorkflowRequest('/admin/report/' + reportId + '/assign', { assigned_to: result.value }) : null);
        })
        .then(data => {
            if (!data) return;
            return Swal.fire({ icon: 'success', title: 'Assigned', text: data.message, timer: 1400, showConfirmButton: false }).then(() => location.reload());
        })
        .catch(error => Swal.fire({ icon: 'error', title: 'Unable to assign ticket', text: error.message }));
}

function completeTicketReport(reportId) {
    Swal.fire({
        title: 'Complete ticket',
        html: '<textarea id="ticketResolutionNotes" class="swal2-textarea" placeholder="Resolution notes (optional)"></textarea>' +
            '<input id="ticketCost" type="number" min="0" step="0.01" class="swal2-input" placeholder="Recorded cost (optional)">' +
            '<input id="ticketDamagedPart" class="swal2-input" placeholder="Damaged part (optional)">' +
            '<input id="ticketReplacedPart" class="swal2-input" placeholder="Replaced part (optional)">',
        showCancelButton: true,
        confirmButtonText: 'Mark resolved',
        confirmButtonColor: '#198754',
        preConfirm: () => ({
            status: 'Resolved',
            resolution_notes: document.getElementById('ticketResolutionNotes').value.trim(),
            cost: document.getElementById('ticketCost').value || null,
            damaged_part: document.getElementById('ticketDamagedPart').value.trim(),
            replaced_part: document.getElementById('ticketReplacedPart').value.trim()
        })
    }).then(result => {
        if (!result.isConfirmed) return;
        Swal.fire({ title: 'Completing ticket...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
        ticketWorkflowRequest('/reports/' + reportId + '/update-status', result.value)
            .then(data => Swal.fire({ icon: 'success', title: 'Resolved', text: data.message, timer: 1400, showConfirmButton: false }).then(() => location.reload()))
            .catch(error => Swal.fire({ icon: 'error', title: 'Unable to complete ticket', text: error.message }));
    });
}

// Edit Concern Modal
function editConcern(id) {
    const modal = new bootstrap.Modal(document.getElementById('editConcernModal'));
    const contentDiv = document.getElementById('editConcernContent');
    const form = document.getElementById('editConcernForm');

    contentDiv.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>';

    form.action = '/concerns/' + id;

    modal.show();

    fetch('/concerns/' + id + '/edit-data', {
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        credentials: 'same-origin'
    })
    .then(async response => {
        const contentType = response.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
            const text = await response.text();
            console.error('Non-JSON edit response:', text);
            throw new Error('The edit endpoint returned HTML instead of JSON.');
        }

        const data = await response.json();
        console.log('Edit data response:', data);

        if (!response.ok) {
            throw new Error(data.error || 'Failed to load concern data.');
        }

        return data;
    })
    .then(data => {
        if (data.error) {
            contentDiv.innerHTML = '<div class="alert alert-danger">' + data.error + '</div>';
            return;
        }
        
        const concern = data.concern;
        const categories = data.categories;
        const maintenanceUsers = data.maintenance_users || [];
        const canAssign = data.can_assign || false;
        
        // Store categories globally for handleEditCategoryChange to access
        window.editConcernCategories = categories;
        
        let categoryOptions = '';
        categories.forEach(cat => {
            const selected = cat.id === concern.category_id ? 'selected' : '';
            categoryOptions += `<option value="${cat.id}" data-issues='${JSON.stringify(cat.issues || [])}' ${selected}>${cat.name}</option>`;
        });
        
        const priorities = ['low', 'medium', 'high', 'urgent'];
        let priorityOptions = '';
        priorities.forEach(pri => {
            const selected = pri === concern.priority ? 'selected' : '';
            priorityOptions += `<option value="${pri}" ${selected}>${pri ? (pri.charAt(0).toUpperCase() + pri.slice(1)) : pri}</option>`;
        });
        
        const statuses = ['Pending', 'Assigned', 'In Progress', 'Resolved', 'Closed'];
        let statusOptions = '';
        statuses.forEach(sta => {
            const selected = sta === concern.status ? 'selected' : '';
            statusOptions += `<option value="${sta}" ${selected}>${sta}</option>`;
        });
        
        let maintenanceOptions = '<option value="">-- Select Maintenance --</option>';
        maintenanceUsers.forEach(user => {
            const selected = user.id === concern.assigned_to ? 'selected' : '';
            maintenanceOptions += `<option value="${user.id}" ${selected}>${user.name}</option>`;
        });

        const selectedCategory = categories.find(cat => cat.id === concern.category_id);
        const selectedIssue = (selectedCategory?.issues || []).find(issue => getIssueName(issue) === concern.title);
        const savedProblemTypes = selectedIssue ? getIssueProblemTypes(selectedIssue) : [];
        let problemTypeOptions = '<option value="" disabled>Select a problem type</option>';
        (savedProblemTypes.length ? savedProblemTypes : getProblemTypesForIssue(concern.title || '')).forEach(problemType => {
            const selected = problemType === concern.description ? 'selected' : '';
            problemTypeOptions += `<option value="${problemType}" ${selected}>${problemType}</option>`;
        });
        
        let imageHtml = '';
        if (concern.image_path) {
            imageHtml = `
                <div class="mb-3">
                    <label class="form-label">Current Photo</label>
                    <div>
                        <img src="${concern.image_path}" alt="Current photo" class="img-fluid rounded" style="max-width: 200px;">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Replace Photo</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                </div>
            `;
        } else {
            imageHtml = `
                <div class="mb-3">
                    <label class="form-label">Photo</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                </div>
            `;
        }
        
        // Build form fields based on role - but NOT for my-concerns page
        // Admin fields (status, assign) should only appear in admin concern management, not in my-concerns
        let adminFields = '';
        // Don't show admin fields in my-concerns edit modal
        
        contentDiv.innerHTML = `
            <input type="hidden" name="title" id="edit_title" value="${concern.title || ''}">
            <div class="mb-3">
                <label class="form-label">Category *</label>
                <select name="category_id" class="form-select" id="edit_category_id" required onchange="handleEditCategoryChange()">
                    ${categoryOptions}
                </select>
            </div>
            <div class="mb-3" id="edit_issue_container" style="display: none;">
                <label class="form-label">Issue *</label>
                <select class="form-select" id="edit_issue" name="_issue">
                    <option value="" disabled selected>Select an issue</option>
                </select>
            </div>
            <div class="mb-3" id="edit_location_container" style="display: none;">
                <label class="form-label">Location *</label>
                <select name="location" class="form-select" id="edit_location" required>
                    <option value="" disabled>Select a location</option>
                    @foreach($facilities->groupBy('type') as $type => $group)
                        <optgroup label="{{ ucfirst($type) }}">
                            @foreach($group as $facility)
                                <option value="{{ $facility->name }}" ${concern.location === '{{ $facility->name }}' ? 'selected' : ''}>{{ $facility->name }}</option>
                            @endforeach
                        </optgroup>
                    @endforeach
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Problem Type *</label>
                <select name="description" class="form-select" id="edit_description" required>
                    ${problemTypeOptions}
                </select>
            </div>
            ${imageHtml}
        `;
        
        // Trigger category change to show issue/location fields and set saved values
        setTimeout(() => {
            handleEditCategoryChange();
            
            // Wait a bit more for dropdown to be fully populated, then set values
            setTimeout(() => {
                // Set the selected issue if exists
                const issueSelect = document.getElementById('edit_issue');
                if (issueSelect && concern.title) {
                    // Check if the option exists in the dropdown
                    const optionExists = Array.from(issueSelect.options).some(opt => opt.value === concern.title);
                    if (optionExists) {
                        issueSelect.value = concern.title;
                        // Trigger change to update hidden title field
                        const event = new Event('change');
                        issueSelect.dispatchEvent(event);
                        const selectedIssue = issueSelect.options[issueSelect.selectedIndex];
                        const problemTypes = selectedIssue?.dataset.problemTypes ? JSON.parse(selectedIssue.dataset.problemTypes) : [];
                        populateProblemTypeSelect(document.getElementById('edit_description'), concern.title, concern.description, problemTypes);
                    }
                }
                
                // Set the selected location if exists
                const locationSelect = document.getElementById('edit_location');
                if (locationSelect && concern.location) {
                    locationSelect.value = concern.location;
                }
            }, 50);
        }, 100);
    })
    .catch(error => {
        console.error('Error:', error);
        contentDiv.innerHTML = '<div class="alert alert-danger">' + error.message + '</div>';
    });
}

// Handle edit form submission
const editConcernForm = document.getElementById('editConcernForm');
if (editConcernForm) {
    editConcernForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const form = this;
        const formData = new FormData(form);
        
        formData.append('_method', 'PUT');
        
        const url = form.action;
        
        fetch(url, {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            }
        })
        .then(response => ImageUploadFeedback.readResponse(response, 'The concern could not be updated. Please try again.'))
        .then(data => {
            if (data.success) {
                bootstrap.Modal.getInstance(document.getElementById('editConcernModal')).hide();
                location.reload();
            }
        })
        .catch(error => ImageUploadFeedback.show(error.message, 'Unable to update concern'));
    });
}

// Archive Modal Function
function showArchiveModal(concernId) {
    confirmArchive({
        title: 'Archive Concern?',
        text: 'This concern will be archived and hidden from your active list.',
        confirmButtonText: '<i class="fas fa-archive me-1"></i> Archive'
    }).then(result => {
        if (result.isConfirmed) {
            // Show loading
            getSwal().fire({
                title: 'Archiving...',
                html: '<div class="spinner-border text-primary"></div>',
                showConfirmButton: false,
                allowOutsideClick: false
            });
            
            fetch('/concerns/' + concernId + '/archive', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then(response => response.json())
            .then(data => {
                if (data.success) {
                    swalToast('Concern archived successfully!', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else if (data.error) {
                    swalAlert(data.error, 'error', 'Error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                swalAlert('Error archiving concern', 'error', 'Error');
            });
        }
    });
}

function archiveConcern(id) {
    confirmArchive({
        title: 'Archive Concern?',
        text: 'This concern will be archived and hidden from your active list.'
    }).then(result => {
        if (result.isConfirmed) {
            fetch('/concerns/' + id + '/archive', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then(response => response.json())
            .then(data => {
                if (data.success) {
                    swalToast('Concern archived successfully!', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else if (data.error) {
                    swalAlert(data.error, 'error', 'Error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                swalAlert('Error archiving concern', 'error', 'Error');
            });
        }
    });
}

// Store current concern ID for assignment
let currentConcernId = null;

// Show Assign Modal
function showAssignModal() {
    const concernId = window.currentConcernId;
    if (!concernId) {
        alert('No concern selected');
        return;
    }
    
    const modal = new bootstrap.Modal(document.getElementById('assignConcernModal'));
    const select = document.getElementById('assigned_to');
    const form = document.getElementById('assignConcernForm');
    
    // Set the concern ID
    document.getElementById('assignConcernId').value = concernId;
    
    // Load maintenance staff list
    select.innerHTML = '<option value="">Loading...</option>';
    
    fetch('/api/maintenance-users', {
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            select.innerHTML = '<option value="">Error loading users</option>';
            return;
        }
        
        select.innerHTML = '<option value="">Select maintenance staff</option>';
        data.users.forEach(user => {
            select.innerHTML += `<option value="${user.id}">${user.name}</option>`;
        });
    })
    .catch(error => {
        console.error('Error:', error);
        select.innerHTML = '<option value="">Error loading users</option>';
    });
    
    modal.show();
}

// Handle assign form submission
const assignConcernForm = document.getElementById('assignConcernForm');
if (assignConcernForm) {
    assignConcernForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const concernId = document.getElementById('assignConcernId').value;
        const assignedTo = document.getElementById('assigned_to').value;
    
    if (!assignedTo) {
        alert('Please select a maintenance staff');
        return;
    }
    
    fetch('/concerns/' + concernId + '/assign', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ assigned_to: assignedTo })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            bootstrap.Modal.getInstance(document.getElementById('assignConcernModal')).hide();
            alert('Concern assigned successfully!');
            location.reload();
        } else {
            alert(data.error || 'Failed to assign concern');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error assigning concern');
    });
    });
}
</script>

<!-- View Concern Modal -->
<div class="modal fade" id="viewConcernModal" tabindex="-1" aria-labelledby="viewConcernModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewConcernModalLabel">View Concern</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewConcernContent">
                <!-- Content will be loaded dynamically -->
            </div>
            <div class="modal-footer">
                <!-- Action buttons will be added dynamically -->
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Assign Concern Modal -->
<div class="modal fade" id="assignConcernModal2" tabindex="-1" aria-labelledby="assignConcernModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="assignConcernModalLabel2">Assign Concern to Maintenance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="assignConcernForm2">
                @csrf
                <input type="hidden" id="assignConcernId2" name="concern_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="assigned_to2" class="form-label">Select Maintenance Staff</label>
                        <select class="form-select" id="assigned_to2" name="assigned_to" required>
                            <option value="">Loading...</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Assign Concern</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Reset all "Select All" checkboxes and counts on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('[INIT] Resetting all select-all checkboxes and counts');
    
    // Reset all "Select All" checkboxes
    ['selectAllActive', 'selectAllResolved', 'selectAllArchive', 'selectAllDeleted'].forEach(id => {
        const checkbox = document.getElementById(id);
        if (checkbox) {
            checkbox.checked = false;
        }
    });
    
    // Update all bulk actions to hide them and reset counts
    updateActiveBulkActions();
    updateResolvedBulkActions();
    updateArchiveBulkActions();
    updateDeletedBulkActions();
});

// Auto-open concern modal if concern_id is in URL
console.log('[Auto-open] Script loaded - concerns page');
document.addEventListener('DOMContentLoaded', function() {
    console.log('[Auto-open] DOMContentLoaded fired');
    const urlParams = new URLSearchParams(window.location.search);
    const concernId = urlParams.get('concern_id');
    
    console.log('[Auto-open] URL params:', window.location.search);
    console.log('[Auto-open] Concern ID:', concernId);
    
    if (concernId) {
        console.log('[Auto-open] Found concern_id:', concernId);
        console.log('[Auto-open] viewConcern function exists?', typeof viewConcern === 'function');
        
        // Function to try opening the modal
        function tryOpenModal(retryCount = 0) {
            if (typeof viewConcern === 'function') {
                console.log('[Auto-open] Opening concern modal for ID:', concernId);
                setTimeout(function() {
                    viewConcern(parseInt(concernId));
                    // Clean URL without reloading page
                    const cleanUrl = window.location.pathname + window.location.hash;
                    window.history.replaceState({}, document.title, cleanUrl);
                    console.log('[Auto-open] Modal opened and URL cleaned');
                }, 300);
            } else {
                console.error('[Auto-open] viewConcern function not found, retry count:', retryCount);
                if (retryCount < 5) {
                    // Retry after a delay
                    setTimeout(function() {
                        tryOpenModal(retryCount + 1);
                    }, 500);
                } else {
                    console.error('[Auto-open] Failed to find viewConcern function after 5 retries');
                }
            }
        }
        
        tryOpenModal();
    } else {
        console.log('[Auto-open] No concern_id in URL');
    }
});
</script>

@endsection
