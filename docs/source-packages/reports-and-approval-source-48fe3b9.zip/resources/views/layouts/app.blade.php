<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
<meta charset="UTF-8">
<title>CampFix</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="description" content="CampFix - Campus Facility Management System for STI College Novaliches">

<!-- Canonical Tag -->
<link rel="canonical" href="{{ url()->current() }}">

<!-- Favicon -->
<link rel="icon" type="image/png" href="{{ asset('Campfix/Images/logo.png') }}">
<link rel="shortcut icon" type="image/png" href="{{ asset('Campfix/Images/logo.png') }}">

<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
<link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
<link rel="preload" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
</noscript>

<link href="{{ asset('css/app.css') }}" rel="stylesheet">

@yield('styles')

<style>
/* Fix table layout and prevent content wrapping issues */
.table {
    table-layout: auto !important;
    width: 100%;
}

/* Prevent headers from wrapping */
.table th {
    white-space: nowrap;
}

/* Prevent ugly word breaking in cells */
.table td {
    word-break: normal !important;
    overflow-wrap: break-word;
}

/* Set min-widths for common columns */
/* Title column (first or second) */
.table th:nth-child(1),
.table td:nth-child(1),
.table th:nth-child(2),
.table td:nth-child(2) {
    min-width: 200px;
}

/* Category (second or third) */
.table th:nth-child(2),
.table td:nth-child(2),
.table th:nth-child(3),
.table td:nth-child(3) {
    min-width: 180px;
}

/* Location (third or fourth) */
.table th:nth-child(3),
.table td:nth-child(3),
.table th:nth-child(4),
.table td:nth-child(4) {
    min-width: 100px;
}

/* Actions (last) */
.table th:last-child,
.table td:last-child {
    min-width: 120px;
    text-align: center;
}

/* Reduce main content padding */
.content > *:not(.top-header) {
    padding: 20px !important;
}

/* Narrow sidebar to fit nav text */
.sidebar {
    width: 200px !important;
}
.content {
    margin-left: 200px !important;
    width: calc(100% - 200px) !important;
}
.sidebar a.active {
    border-radius: 20px !important;
    margin-left: 10px !important;
    margin-right: 10px !important;
}
.sidebar a.active::after,
.sidebar a.active::before {
    display: none !important;
}

/* Nav dropdown */
.nav-dropdown-toggle {
    display: flex !important;
    align-items: center;
    cursor: pointer;
}
.nav-dropdown-arrow {
    font-size: 11px;
    transition: transform 0.2s;
    margin-left: auto;
    margin-right: 10px;
}
.nav-dropdown.open .nav-dropdown-arrow {
    transform: rotate(180deg);
}
.nav-dropdown-menu {
    display: none;
    flex-direction: column;
    background: rgba(0,0,0,0.15);
    border-radius: 8px;
    margin: 2px 8px 4px 8px;
    overflow: hidden;
}
.nav-dropdown.open .nav-dropdown-menu {
    display: flex;
}
.nav-dropdown-menu a {
    color: rgba(255,255,255,0.85) !important;
    border-radius: 6px !important;
    margin: 1px 4px !important;
}
.nav-dropdown-menu a:hover,
.nav-dropdown-menu a.active {
    background: rgba(255,255,255,0.15) !important;
    color: #fff !important;
}

/* Fix modal scrolling - override app.css max-height */
#modalMaterialsTable {
    min-width: 0 !important;
}
.modal-dialog-scrollable .modal-content {
    max-height: 90vh !important;
    overflow: hidden !important;
    display: flex !important;
    flex-direction: column !important;
}
.modal-dialog-scrollable form {
    display: flex !important;
    flex-direction: column !important;
    overflow: hidden !important;
    flex: 1 !important;
    min-height: 0 !important;
}
.modal-dialog-scrollable .modal-body {
    overflow-y: auto !important;
    flex: 1 !important;
    min-height: 0 !important;
}

@media (max-width: 991px) {
    .sidebar {
        transform: translateX(-100%) !important;
        width: 200px !important;
    }
    .sidebar.show {
        transform: translateX(0) !important;
    }
    .content {
        margin-left: 0 !important;
        width: 100% !important;
    }
}

/* Make asterisks red for required fields */
.required-asterisk {
    color: #dc3545 !important;
    font-weight: bold;
}

/* Fallback styling */
.text-danger {
    color: #dc3545 !important;
}
</style>

<style>
/* ── Global Dark Theme ── */
[data-theme="dark"],
[data-theme="dark"] html,
[data-theme="dark"] body {
    background-color: #0f0f1a !important;
    color: #e0e0e0 !important;
}
html[data-theme="dark"],
html[data-theme="dark"] body {
    background-color: #0f0f1a !important;
    color: #e0e0e0 !important;
}
[data-theme="dark"] .sidebar { background: #0a1628 !important; }
[data-theme="dark"] .main-content { background: #0f0f1a !important; }
[data-theme="dark"] .card { background: #1a1a2e !important; border-color: #2a2a45 !important; color: #e0e0e0 !important; }
[data-theme="dark"] .card-header { background: #1e1e38 !important; border-color: #2a2a45 !important; color: #e0e0e0 !important; }
[data-theme="dark"] .table { color: #e0e0e0 !important; }
[data-theme="dark"] .table thead th { background: #1e1e38 !important; color: #aaa !important; border-color: #2a2a45 !important; }
[data-theme="dark"] .table td, [data-theme="dark"] .table th { border-color: #2a2a45 !important; }
[data-theme="dark"] .table-hover tbody tr:hover { background: #22223a !important; }
[data-theme="dark"] .table-light { background: #1e1e38 !important; color: #aaa !important; }
[data-theme="dark"] .form-control, [data-theme="dark"] .form-select { background: #1e1e38 !important; border-color: #2a2a45 !important; color: #e0e0e0 !important; }
[data-theme="dark"] .modal-content { background: #1a1a2e !important; color: #e0e0e0 !important; border-color: #2a2a45 !important; }
[data-theme="dark"] .modal-header { border-color: #2a2a45 !important; }
[data-theme="dark"] .modal-footer { border-color: #2a2a45 !important; }
[data-theme="dark"] .nav-tabs .nav-link { color: #aaa !important; }
[data-theme="dark"] .nav-tabs .nav-link.active { background: #1e1e38 !important; color: #fff !important; border-color: #2a2a45 #2a2a45 #1e1e38 !important; }
[data-theme="dark"] .alert { border-color: #2a2a45 !important; }
[data-theme="dark"] .dropdown-menu { background: #1a1a2e !important; border-color: #2a2a45 !important; }
[data-theme="dark"] .user-dropdown-menu { background: #1a1a2e !important; border-color: #2a2a45 !important; color: #e0e0e0 !important; }
[data-theme="dark"] .dropdown-header { color: #e0e0e0 !important; }
[data-theme="dark"] .dropdown-user-email { color: #aaa !important; }
[data-theme="dark"] .dropdown-item { color: #e0e0e0 !important; }
[data-theme="dark"] .dropdown-item:hover { background: #22223a !important; }
[data-theme="dark"] .text-muted { color: #888 !important; }
[data-theme="dark"] hr, [data-theme="dark"] .dropdown-divider { border-color: #2a2a45 !important; }
[data-theme="dark"] .nav-pills .nav-link { color: #aaa !important; }
[data-theme="dark"] .nav-pills .nav-link.active { background: #4f6ef7 !important; color: #fff !important; }
[data-theme="dark"] .badge.bg-light { background: #2a2a45 !important; color: #e0e0e0 !important; }
[data-theme="dark"] .top-bar { background: #12122a !important; border-color: #2a2a45 !important; }
[data-theme="dark"] input::placeholder, [data-theme="dark"] textarea::placeholder { color: #666 !important; }
[data-theme="dark"] .content { background: #0f0f1a !important; }
[data-theme="dark"] .top-header { background: #12122a !important; border-color: #2a2a45 !important; }
[data-theme="dark"] .header-page-title h2,
[data-theme="dark"] .header-page-title h1 { color: #e0e0e0 !important; }
.header-page-title { display: flex; flex-direction: column; justify-content: center; }
.header-page-title h1,
.header-page-title h2 { margin: 0; font-size: 20px; font-weight: 700; color: #1e293b; line-height: 1.2; }
.header-page-title p { margin: 0; font-size: 12px; color: #6b7280; line-height: 1.2; }
[data-theme="dark"] .notification-bell { color: #e0e0e0 !important; }
[data-theme="dark"] .notification-bell:hover { background: #2a2a45 !important; }
[data-theme="dark"] .notification-bell i { color: #e0e0e0 !important; }
[data-theme="dark"] .user-dropdown-top span { color: #e0e0e0 !important; }
[data-theme="dark"] .notification-dropdown { background: #1a1a2e !important; border-color: #2a2a45 !important; }
[data-theme="dark"] .notification-header { background: #1e1e38 !important; color: #e0e0e0 !important; border-color: #2a2a45 !important; }
[data-theme="dark"] .notification-item { border-color: #2a2a45 !important; }
[data-theme="dark"] .notification-item:hover { background: #22223a !important; }
[data-theme="dark"] .notification-content p { color: #e0e0e0 !important; }
[data-theme="dark"] .notification-content small { color: #888 !important; }
[data-theme="dark"] .notification-empty { color: #888 !important; }
[data-theme="dark"] .mobile-menu-btn { color: #e0e0e0 !important; }
[data-theme="dark"] .bg-white { background: #1a1a2e !important; color: #e0e0e0 !important; }
[data-theme="dark"] .table-card { background: #1a1a2e !important; color: #e0e0e0 !important; }
[data-theme="dark"] .card-header-custom { background: #1e1e38 !important; color: #e0e0e0 !important; }
[data-theme="dark"] h1, [data-theme="dark"] h2, [data-theme="dark"] h3, [data-theme="dark"] h4, [data-theme="dark"] h5, [data-theme="dark"] h6 { color: #e0e0e0 !important; }
[data-theme="dark"] .table tbody tr { background: #1a1a2e !important; }
[data-theme="dark"] .table tbody tr:nth-child(even) { background: #1e1e38 !important; }
[data-theme="dark"] .table-striped tbody tr:nth-of-type(odd) { background: #1a1a2e !important; }
[data-theme="dark"] .table-striped tbody tr:nth-of-type(even) { background: #1e1e38 !important; }
[data-theme="dark"] .badge { border-color: #2a2a45 !important; }
[data-theme="dark"] .badge.bg-success { background: #10b981 !important; color: #fff !important; }
[data-theme="dark"] .badge.bg-primary { background: #3b82f6 !important; color: #fff !important; }
[data-theme="dark"] .badge.bg-warning { background: #f59e0b !important; color: #000 !important; }
[data-theme="dark"] .badge.bg-danger { background: #ef4444 !important; color: #fff !important; }
[data-theme="dark"] .badge.bg-secondary { background: #6b7280 !important; color: #fff !important; }
[data-theme="dark"] .badge.bg-info { background: #06b6d4 !important; color: #fff !important; }
[data-theme="dark"] .table tbody tr td { background: transparent !important; }
[data-theme="dark"] .table-hover tbody tr:hover td { background: #22223a !important; }
[data-theme="dark"] .card { background: #1a1a2e !important; }
[data-theme="dark"] .card-body { background: #1a1a2e !important; }
[data-theme="dark"] .table-responsive { background: #1a1a2e !important; }
[data-theme="dark"] .avatar-sm { border-color: #2a2a45 !important; }
[data-theme="dark"] .role-badge { opacity: 0.9; }
</style>

<script>
// Make all asterisks in labels red
document.addEventListener('DOMContentLoaded', function() {
    function makeAsterisksRed() {
        // Find all labels and form-labels
        const labels = document.querySelectorAll('label, .form-label');
        
        labels.forEach(function(label) {
            // Check if the label contains an asterisk
            if (label.textContent.includes('*')) {
                // Replace asterisk with red-colored span
                label.innerHTML = label.innerHTML.replace(/\*/g, '<span class="required-asterisk">*</span>');
            }
        });
    }
    
    // Run initially
    makeAsterisksRed();
    
    // Run again after any dynamic content is loaded (for modals, AJAX, etc.)
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                // Check if any new labels were added
                mutation.addedNodes.forEach(function(node) {
                    if (node.nodeType === 1) { // Element node
                        const newLabels = node.querySelectorAll ? node.querySelectorAll('label, .form-label') : [];
                        newLabels.forEach(function(label) {
                            if (label.textContent.includes('*')) {
                                label.innerHTML = label.innerHTML.replace(/\*/g, '<span class="required-asterisk">*</span>');
                            }
                        });
                    }
                });
            }
        });
    });
    
    // Start observing
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
});
</script>
</head>
<body data-user-timezone="{{ auth()->check() ? auth()->user()->timezone : config('app.timezone') }}" data-user-locale="{{ app()->getLocale() }}" data-user-date-format="{{ $userDateFormat ?? 'Y-m-d' }}">

<!-- Sidebar Overlay for Mobile -->
<div class="sidebar-overlay" onclick="toggleSidebar()"></div>

<!-- Sidebar/Nav -->
<div class="sidebar">
    <div class="sidebar-header">
        <img src="{{ asset('Campfix/Images/logo.png') }}" alt="CampFix Logo" width="160" height="160" fetchpriority="high">
    </div>

    <div class="sidebar-content">
        @auth

        <a href="/dashboard" class="{{ Request::is('dashboard') || request()->routeIs('superadmin.dashboard') || Request::is('mis') || Request::is('building-admin') || Request::is('school-admin') || Request::is('academic-head') || Request::is('program-head') || Request::is('principal-assistant') || Request::is('system-admin') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
            <i class="fas fa-home"></i> {{ app()->getLocale() === 'tl' ? 'Home' : 'Home' }}
        </a>

        {{-- Only show My Concerns for non-admin and non-maintenance users --}}
        @if(!auth()->user()->isSystemAdministrator() && auth()->user()->role !== 'mis' && auth()->user()->role !== 'maintenance')
            <a href="{{ route('concerns.my') }}" class="{{ Request::is('my-concerns') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-clipboard-list"></i> {{ app()->getLocale() === 'tl' ? 'Aking Mga Concern' : 'My Concerns' }}
            </a>

            {{-- Only show Request for faculty users --}}
            @if(auth()->user()->role === 'faculty' && auth()->user()->canAccess('events'))
                {{-- Events dropdown --}}
                <div class="nav-dropdown {{ Request::is('my-events') || Request::is('events-calendar') ? 'open' : '' }}">
                    <a href="#" class="nav-dropdown-toggle {{ Request::is('my-events') || Request::is('events-calendar') ? 'active' : '' }}"
                       data-nav-toggle style="padding-top:8px;padding-bottom:8px;">
                        <i class="fas fa-calendar-alt"></i> Facilities
                        <i class="fas fa-chevron-down nav-dropdown-arrow ms-auto"></i>
                    </a>
                    <div class="nav-dropdown-menu">
                        <a href="{{ route('events.my') }}" class="{{ Request::is('my-events') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                            <i class="fas fa-calendar me-1"></i> Request
                        </a>
                        <a href="{{ route('events.calendar') }}" class="{{ Request::is('events-calendar') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                            <i class="fas fa-calendar-check me-1"></i> Calendar
                        </a>
                    </div>
                </div>
            @endif
        @elseif(!auth()->user()->isSystemAdministrator() && auth()->user()->role === 'mis')
            <a href="{{ route('concerns.my') }}" class="{{ Request::is('my-concerns') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-clipboard-list"></i> My Concerns
            </a>
        @endif

        {{-- Only show Assigned Tasks for maintenance role --}}

        {{-- MIS navigation --}}
        @if(auth()->user()->role === 'mis' && ! auth()->user()->isSystemAdministrator())

            <a href="/mis/mis-tasks" class="{{ Request::is('mis/mis-tasks') || Request::is('admin/mis-tasks') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-tasks"></i> {{ app()->getLocale() === 'tl' ? 'Gawain' : 'Task' }}
            </a>

            <a href="{{ route('mis.management', ['tab' => 'categories']) }}" class="{{ Request::is('mis/management*') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-tools"></i> Management
            </a>

            <a href="{{ route('role.analytics') }}" class="{{ Request::is('role-analytics') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-chart-line"></i> Analytics
            </a>

            <a href="{{ route('history.index') }}" class="{{ Request::is('history') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-history"></i> History
            </a>

            <a href="/settings" class="{{ Request::is('settings') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-cog"></i> {{ app()->getLocale() === 'tl' ? 'Mga Setting' : 'Settings' }}
            </a>

        @endif

        {{-- System Administrator navigation --}}
        @if(auth()->user()->isSystemAdministrator())
            <a href="{{ route('superadmin.users') }}" class="{{ Request::is('admin/users*') || Request::is('system-admin/users*') ? 'active' : '' }}"><i class="fas fa-users"></i> User Management</a>
            <a href="{{ route('superadmin.reports') }}" class="{{ Request::is('admin/reports*') || Request::is('system-admin/reports*') ? 'active' : '' }}"><i class="fas fa-file-alt"></i> Reports</a>
            <div class="nav-dropdown {{ Request::is('my-events') || Request::is('events-calendar*') || Request::is('admin/events*') || Request::is('system-admin/events*') ? 'open' : '' }}">
                <a href="#" class="nav-dropdown-toggle {{ Request::is('my-events') || Request::is('events-calendar*') || Request::is('admin/events*') || Request::is('system-admin/events*') ? 'active' : '' }}"
                   data-nav-toggle style="padding-top:8px;padding-bottom:8px;">
                    <i class="fas fa-calendar-alt"></i> Facilities
                    <i class="fas fa-chevron-down nav-dropdown-arrow ms-auto"></i>
                </a>
                <div class="nav-dropdown-menu">
                    <a href="{{ route('superadmin.events') }}" class="{{ Request::is('admin/events*') || Request::is('system-admin/events*') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                        <i class="fas fa-calendar-alt me-1"></i> Pending Approval
                    </a>
                    <a href="{{ route('events.my') }}" class="{{ Request::is('my-events') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                        <i class="fas fa-calendar me-1"></i> Request
                    </a>
                    <a href="{{ route('events.calendar') }}" class="{{ Request::is('events-calendar*') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                        <i class="fas fa-calendar-check me-1"></i> Calendar
                    </a>
                </div>
            </div>
            <a href="{{ route('superadmin.management') }}" class="{{ Request::is('admin/management*') || Request::is('system-admin/management*') ? 'active' : '' }}"><i class="fas fa-tools"></i> Management</a>
            <a href="{{ route('superadmin.analytics') }}" class="{{ Request::is('system-admin/analytics*') ? 'active' : '' }}"><i class="fas fa-chart-line"></i> Analytics</a>
            <a href="{{ route('superadmin.activity-logs') }}" class="{{ Request::is('admin/logs*') || Request::is('system-admin/activity-logs*') ? 'active' : '' }}"><i class="fas fa-history"></i> Audit Logs</a>
            <a href="{{ route('superadmin.settings') }}" class="{{ Request::is('settings') || Request::is('system-admin/settings') ? 'active' : '' }}"><i class="fas fa-cog"></i> Settings</a>
        @endif
        @if(auth()->user()->role === 'building_admin')
            {{-- Reports dropdown for building admin --}}
            <div class="nav-dropdown {{ Request::is('building-admin/reports*') || Request::is('building-admin/analytics*') ? 'open' : '' }}">
                <a href="#" class="nav-dropdown-toggle {{ Request::is('building-admin/reports*') || Request::is('building-admin/analytics*') ? 'active' : '' }}"
                   data-nav-toggle style="padding-top:8px;padding-bottom:8px;">
                    <i class="fas fa-chart-bar"></i> {{ app()->getLocale() === 'tl' ? 'Mga Ulat' : 'Reports' }}
                    <i class="fas fa-chevron-down nav-dropdown-arrow ms-auto"></i>
                </a>
                <div class="nav-dropdown-menu">
                    <a href="/building-admin/reports" class="{{ Request::is('building-admin/reports') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                        <i class="fas fa-file-alt me-1"></i> Reports
                    </a>
                    <a href="/building-admin/analytics" class="{{ Request::is('building-admin/analytics*') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                        <i class="fas fa-chart-line me-1"></i> Analytics
                    </a>
                </div>
            </div>

            {{-- Events dropdown for building admin --}}
            <div class="nav-dropdown {{ Request::is('my-events') || Request::is('events-calendar') || Request::is('building-admin/events') ? 'open' : '' }}">
                <a href="#" class="nav-dropdown-toggle {{ Request::is('my-events') || Request::is('events-calendar') || Request::is('building-admin/events') ? 'active' : '' }}"
                   data-nav-toggle style="padding-top:8px;padding-bottom:8px;">
                    <i class="fas fa-calendar-alt"></i> Facilities
                    <i class="fas fa-chevron-down nav-dropdown-arrow ms-auto"></i>
                </a>
                <div class="nav-dropdown-menu">
                    <a href="/building-admin/events" class="{{ Request::is('building-admin/events') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                        <i class="fas fa-calendar-alt me-1"></i> Pending Approval
                    </a>
                    @if(auth()->user()->canAccess('facility requests'))
                        <a href="{{ route('events.my') }}" class="{{ Request::is('my-events') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                            <i class="fas fa-calendar me-1"></i> Request
                        </a>
                        <a href="{{ route('events.calendar') }}" class="{{ Request::is('events-calendar') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                            <i class="fas fa-calendar-check me-1"></i> Calendar
                        </a>
                    @endif
                </div>
            </div>

            <a href="/building-admin/management" class="{{ Request::is('building-admin/management*') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-tools"></i> Management
            </a>

        @endif

        {{-- School Admin, Academic Head, Program Head, Principal Assistant navigation --}}
        @if(in_array(auth()->user()->role, ['school_admin', 'academic_head', 'program_head', 'principal_assistant']))
        @php
            $roleSlug = str_replace('_', '-', auth()->user()->role);
        @endphp
            @if(auth()->user()->role === 'school_admin')
                <a href="{{ route('school-admin.reports') }}" class="{{ Request::is('school-admin/reports*') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;"><i class="fas fa-file-alt"></i> Reports</a>
                <a href="{{ route('school-admin.budget-approvals') }}" class="{{ Request::is('school-admin/budget-approvals*') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                    <i class="fas fa-coins"></i> Budget Approvals
                </a>
            @endif
            <div class="nav-dropdown {{ Request::is('my-events') || Request::is('events-calendar') || Request::is("{$roleSlug}/events") ? 'open' : '' }}">
                <a href="#" class="nav-dropdown-toggle {{ Request::is('my-events') || Request::is('events-calendar') || Request::is("{$roleSlug}/events") ? 'active' : '' }}"
                   data-nav-toggle style="padding-top:8px;padding-bottom:8px;">
                    <i class="fas fa-calendar-alt"></i> Facilities
                    <i class="fas fa-chevron-down nav-dropdown-arrow ms-auto"></i>
                </a>
                <div class="nav-dropdown-menu">
                    <a href="/{{ $roleSlug }}/events" class="{{ Request::is("{$roleSlug}/events") ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                        <i class="fas fa-calendar-alt me-1"></i> Pending Approval
                    </a>
                    @if(auth()->user()->canAccess('facility requests'))
                        <a href="{{ route('events.my') }}" class="{{ Request::is('my-events') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                            <i class="fas fa-calendar me-1"></i> Request
                        </a>
                        <a href="{{ route('events.calendar') }}" class="{{ Request::is('events-calendar') ? 'active' : '' }}" style="padding-left:36px;padding-top:6px;padding-bottom:6px;font-size:13px;">
                            <i class="fas fa-calendar-check me-1"></i> Calendar
                        </a>
                    @endif
                </div>
            </div>

            <a href="{{ route('role.analytics') }}" class="{{ Request::is('role-analytics') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-chart-line"></i> Analytics
            </a>
        @endif

        {{-- Settings — visible to all roles --}}
        @if(auth()->user()->role !== 'mis' && !auth()->user()->isSystemAdministrator())
            <a href="{{ route('history.index') }}" class="{{ Request::is('history') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-history"></i> History
            </a>

            <a href="/settings" class="{{ Request::is('settings') ? 'active' : '' }}" style="padding-top:8px;padding-bottom:8px;">
                <i class="fas fa-cog"></i> {{ app()->getLocale() === 'tl' ? 'Mga Setting' : 'Settings' }}
            </a>
        @endif

        @endauth
    </div>
</div>

<!-- Main content -->
<div class="content">
    
    <!-- Top Header Bar -->
    <div class="top-header">
        <div class="header-left" style="display: flex; align-items: center;">
            <button class="mobile-menu-btn" onclick="toggleSidebar()" style="margin-right: 10px;">
                <i class="fas fa-bars"></i>
            </button>
            @hasSection('page_title')
                <div class="header-page-title">@yield('page_title')</div>
            @endif
        </div>
        <div class="header-right">
            <!-- Notification Bell -->
            <div class="notification-bell" onclick="toggleNotification(event)">
                <i class="fas fa-bell"></i>
            @if(isset($unread_count) && $unread_count > 0)
                <span class="notification-badge">{{ $unread_count }}</span>
            @endif
                <div class="notification-dropdown" id="notificationDropdown">
                    <div class="notification-header">
                        <span>{{ app()->getLocale() === 'tl' ? 'Mga Abiso' : 'Notifications' }}</span>
                        <span class="notification-count">{{ $unread_count ?? 0 }}</span>
                    </div>
                    <div class="notification-list">
                        @forelse($notifications ?? [] as $notification)
                            <div class="notification-item {{ !$notification->read_at ? 'unread' : '' }}" onclick="openNotificationModal('{{ $notification->id }}', event)">
                                <div class="notification-avatar">
                                    @php
                                        $sender = null;
                                        if (isset($notification->data['sender_id'])) {
                                            $sender = \App\Models\User::find($notification->data['sender_id']);
                                        }
                                    @endphp
                                    @if($sender && $sender->profile_picture_url)
                                        <img src="{{ $sender->profile_picture_url }}" alt="{{ $sender->name }}">
                                    @elseif($sender)
                                        <div class="notification-avatar-initial">{{ substr($sender->name, 0, 1) }}</div>
                                    @else
                                        <div class="notification-avatar-initial"><i class="fas fa-bell"></i></div>
                                    @endif
                                </div>
                                <div class="notification-content">
                                    <div class="notification-sender">{{ $sender->name ?? 'System' }}</div>
                                    <p class="notification-message">{{ $notification->data['message'] ?? 'Notification' }}</p>
                                    <small class="notification-time">{{ $notification->created_at->copy()->timezone('Asia/Manila')->format('M j, g:i a') }}</small>
                                </div>
                                @if(!$notification->read_at)
                                    <div class="notification-status-dot"></div>
                                @endif
                                <button onclick="deleteNotification('{{ $notification->id }}', event)" class="notification-delete-btn" title="Delete notification">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        @empty
                            <div class="notification-empty">
                                <i class="fas fa-bell-slash"></i>
                                <p>{{ app()->getLocale() === 'tl' ? 'Walang abiso' : 'No notifications' }}</p>
                            </div>
                        @endforelse
                    </div>
                    @if(count($notifications ?? []) > 0)
                        <div class="notification-footer">
                            <a href="#" onclick="openAllNotifications(event)">View all notifications</a>
                        </div>
                    @endif
                </div>
            </div>
            
            <!-- User Dropdown -->
            @auth
            <div class="user-dropdown-top" onclick="toggleDropdown(event)" style="display:flex;align-items:center;gap:10px;cursor:pointer;">
                <span title="{{ auth()->user()->name }} ({{ auth()->user()->role_display_name }})" style="font-weight:700;font-size:14px;color:var(--header-text,#1e293b);white-space:nowrap;max-width:210px;overflow:hidden;text-overflow:ellipsis;">{{ auth()->user()->name }} ({{ auth()->user()->role_display_name }})</span>
                <div class="user-icon" style="pointer-events:none;">
                    @if(auth()->user()->profile_picture_url)
                        <img src="{{ auth()->user()->profile_picture_url }}" alt="Profile" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
                    @else
                        {{ substr(auth()->user()->name, 0, 1) }}
                    @endif
                </div>
                <div class="user-dropdown-menu" id="userDropdownMenu">
                    <div class="dropdown-header">
                        <div class="dropdown-user-name">{{ auth()->user()->name }} ({{ auth()->user()->role_display_name }})</div>
                        <div class="dropdown-user-email">{{ auth()->user()->email }}</div>
                    </div>
                    <hr class="dropdown-divider">

                    {{-- Profile Management --}}
                    <a href="{{ route('profile.index') }}" class="dropdown-item" style="display:flex;align-items:center;gap:8px;padding:8px 16px;text-decoration:none;color:inherit;font-size:14px;">
                        <i class="fas fa-user-circle" style="width:16px;text-align:center;"></i> Profile Management
                    </a>

                    {{-- Theme Toggle --}}
                    <div class="dropdown-item" style="display:flex;align-items:center;justify-content:space-between;padding:8px 16px;font-size:14px;">
                        <span><i class="fas fa-palette" style="width:16px;text-align:center;margin-right:8px;"></i> Theme</span>
                        <div style="display:flex;gap:4px;">
                            <button id="theme-light-btn" onclick="setTheme('light')" title="Light"
                                style="border:2px solid #dee2e6;background:#fff;color:#333;border-radius:6px;padding:3px 8px;font-size:11px;cursor:pointer;font-weight:600;transition:all .2s;">
                                <i class="fas fa-sun"></i>
                            </button>
                            <button id="theme-dark-btn" onclick="setTheme('dark')" title="Dark"
                                style="border:2px solid #dee2e6;background:#1a1a2e;color:#e0e0e0;border-radius:6px;padding:3px 8px;font-size:11px;cursor:pointer;font-weight:600;transition:all .2s;">
                                <i class="fas fa-moon"></i>
                            </button>
                        </div>
                    </div>

                    <hr class="dropdown-divider">
                    <form method="POST" action="/logout" style="margin: 0;">
                        @csrf
                        <button type="submit" class="dropdown-item logout" style="width: 100%; border: none; background: none; text-align: left; cursor: pointer;">
                            <i class="fas fa-sign-out-alt"></i> {{ app()->getLocale() === 'tl' ? 'Mag-sign Out' : 'Sign Out' }}
                        </button>
                    </form>
                </div>
            </div>
            @endauth
        </div>
    </div>

    @if(request()->routeIs('superadmin.*'))
        <div class="sa-content">
            @foreach(['success', 'error', 'info'] as $messageType)
                @if(session($messageType))
                    <div class="sa-alert sa-alert-{{ $messageType }}">{{ session($messageType) }}</div>
                @endif
            @endforeach
            @yield('content')
        </div>
    @else
        @yield('content')
    @endif

    @auth

    @endauth

</div>

@if($showEventRequestModal ?? false)
<!-- Facility Request Modal for Faculty -->
<div class="modal fade" id="eventRequestModal" tabindex="-1" aria-labelledby="eventRequestModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="eventRequestModalLabel"><i class="fas fa-calendar-plus"></i> {{ app()->getLocale() === 'tl' ? 'Magsumite ng Facility Request' : 'Submit Facility Request' }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="eventRequestForm" action="{{ route('events.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <input type="hidden" id="modal_location" name="location" value="">
                <div class="modal-body">
                    <!-- Date and Time Selection First -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="modal_event_date" class="form-label">Date *</label>
                            <input type="date" class="form-control @error('event_date') is-invalid @enderror" id="modal_event_date" name="event_date"
                                min="{{ date('Y-m-d') }}" required value="{{ old('event_date') }}">
                            @error('event_date')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-3">
                            <label for="modal_start_time" class="form-label">Start Time *</label>
                            <input type="time" class="form-control @error('start_time') is-invalid @enderror" id="modal_start_time" name="start_time" required value="{{ old('start_time') }}">
                            @error('start_time')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-3">
                            <label for="modal_end_time" class="form-label">End Time *</label>
                            <input type="time" class="form-control @error('end_time') is-invalid @enderror" id="modal_end_time" name="end_time" required value="{{ old('end_time') }}">
                            @error('end_time')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="modal_request_type" class="form-label">Request Type *</label>
                        @php
                            $eventSetupAvailable = \Illuminate\Support\Facades\Schema::hasTable('event_request_types');
                            $eventTypes = $eventSetupAvailable ? \App\Models\EventRequestType::where('is_active', true)->orderBy('name')->get() : collect([['name' => 'Academic'], ['name' => 'Non-Academic']]);
                            $eventUsers = $eventSetupAvailable ? \App\Models\EventIntendedUser::where('is_active', true)->orderBy('name')->get() : collect([['name' => 'Faculty', 'code' => 'faculty'], ['name' => 'Tertiary', 'code' => 'tertiary'], ['name' => 'Senior High School', 'code' => 'shs'], ['name' => 'Staff', 'code' => 'staff'], ['name' => 'Maintenance', 'code' => 'maintenance']]);
                            $eventDepartments = $eventSetupAvailable ? \App\Models\EventDepartment::where('is_active', true)->orderBy('name')->get() : collect([['name' => 'GE'], ['name' => 'ICT'], ['name' => 'Business Management'], ['name' => 'THM']]);
                            $approvalSetupAvailable = $eventSetupAvailable && \Illuminate\Support\Facades\Schema::hasColumns('event_approval_chains', ['event_intended_user_id', 'event_request_type_id']);
                            $eventApprovalChains = $approvalSetupAvailable ? \App\Models\EventApprovalChain::with(['intendedUser', 'requestType'])->get() : collect();
                        @endphp
                        <select class="form-select @error('request_type') is-invalid @enderror" id="modal_request_type" name="request_type" required>
                                <option value="">Select type</option>
                                @foreach($eventTypes as $type)<option value="{{ is_array($type) ? $type['name'] : $type->name }}" data-requires-department="{{ (is_array($type) ? $type['name'] === 'Academic' : $type->requires_department) ? '1' : '0' }}">{{ is_array($type) ? $type['name'] : $type->name }}</option>@endforeach
                            </select>
                        </div>
                        <div class="col-md-8 mb-3">
                            <label for="modal_intended_user" class="form-label">Intended User *</label>
                            <select class="form-select" id="modal_intended_user" name="intended_user" required>
                                @foreach($eventUsers as $userOption)<option value="{{ is_array($userOption) ? $userOption['code'] : $userOption->code }}" {{ (is_array($userOption) ? $userOption['code'] : $userOption->code) === 'faculty' ? 'selected' : '' }}>{{ is_array($userOption) ? $userOption['name'] : $userOption->name }}</option>@endforeach
                            </select>
                        </div>
                        <!-- Hidden field for category - automatically set to Area Use -->
                        <input type="hidden" name="category" value="Area Use">
                        </div>

                        <div class="row">
                        <div class="col-md-6 mb-3" id="modal_area_of_use_container" style="display: none;">
                            <label for="modal_area_of_use" class="form-label">Room / Facility *</label>
                            <select class="form-select @error('area_of_use') is-invalid @enderror" id="modal_area_of_use" name="area_of_use">
                                <option value="">Select a location</option>
                                @if(isset($facilities))
                                    @foreach($facilities->groupBy('type') as $type => $group)
                                        <optgroup label="{{ ucfirst($type) }}">
                                            @foreach($group as $facility)
                                                <option value="{{ $facility->name }}">{{ $facility->name }}</option>
                                            @endforeach
                                        </optgroup>
                                    @endforeach
                                @endif
                            </select>
                            @error('area_of_use')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6 mb-3" id="modal_avr_selection_container" style="display: none;">
                            <label for="modal_avr_selection" class="form-label">AVR Selection *</label>
                            <select class="form-select @error('avr_selection') is-invalid @enderror" id="modal_avr_selection" name="avr_selection">
                                <option value="">Select AVR</option>
                                <option value="AVR 1">AVR 1</option>
                                <option value="AVR 2">AVR 2</option>
                            </select>
                            @error('avr_selection')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    @include('partials.facility-rooms')

                    <!-- Department (only shows when Room is selected in Area of Use) -->
                    <div class="mb-3" id="modal_department_container" style="display: none;">
                        <label for="modal_department" class="form-label">Department *</label>
                        <select class="form-select" id="modal_department" name="department">
                            <option value="">Select department</option>
                            @foreach($eventDepartments as $departmentOption)<option value="{{ is_array($departmentOption) ? $departmentOption['name'] : $departmentOption->name }}">{{ is_array($departmentOption) ? $departmentOption['name'] : $departmentOption->name }}</option>@endforeach
                        </select>
                    </div>


                    <div class="mb-3">
                        <label for="modal_description" class="form-label">Description *</label>
                        <textarea class="form-control @error('description') is-invalid @enderror" id="modal_description" name="description" 
                            rows="4" placeholder="Describe the facility request purpose and details..." required maxlength="500" oninput="updateDescCount()">{{ old('description') }}</textarea>
                        <div class="d-flex justify-content-end">
                            <small id="desc_char_count" class="text-muted">0 / 500</small>
                        </div>
                        @error('description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <!-- Materials/Equipment Needed (Optional) -->
                    <div class="mb-3">
                        <label class="form-label">Materials/Equipment Needed (Optional)</label>
                        <div class="table-responsive">
                        <table class="table table-bordered table-sm" id="modalMaterialsTable" style="min-width:0;">
                            <thead>
                                <tr>
                                    <th style="width: 70px;">Qty</th>
                                    <th>Item</th>
                                    <th style="width: 40px;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><input type="number" class="form-control form-control-sm" name="materials[0][qty]" min="1" placeholder="1"></td>
                                    <td><input type="text" class="form-control form-control-sm" name="materials[0][item]" placeholder="e.g., Projector"></td>
                                    <td><button type="button" class="btn btn-danger btn-sm" onclick="removeModalMaterialRow(this)"><i class="fas fa-times"></i></button></td>
                                </tr>
                            </tbody>
                        </table>
                        </div>
                        <button type="button" class="btn btn-secondary btn-sm" onclick="addModalMaterialRow()">
                            <i class="fas fa-plus"></i> Add Item
                        </button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ app()->getLocale() === 'tl' ? 'Kanselahin' : 'Cancel' }}</button>
                    <button type="button" class="btn btn-primary" id="previewBtn">{{ app()->getLocale() === 'tl' ? 'I-preview' : 'Preview' }}</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="eventPreviewModal" tabindex="-1" aria-labelledby="eventPreviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="eventPreviewModalLabel"><i class="fas fa-eye"></i> {{ app()->getLocale() === 'tl' ? 'Preview ng Facility Request' : 'Facility Request Preview' }}</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h6 class="border-bottom pb-2 mb-3">Facility Request Details</h6>
                <div class="row mb-2">
                    <div class="col-md-4 fw-bold">Category:</div>
                    <div class="col-md-8" id="preview_category"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4 fw-bold">Request Type:</div>
                    <div class="col-md-8" id="preview_request_type"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4 fw-bold">Intended User:</div>
                    <div class="col-md-8" id="preview_intended_user"></div>
                </div>
                <div class="row mb-2" id="preview_area_of_use_row" style="display: none;">
                    <div class="col-md-4 fw-bold">Location:</div>
                    <div class="col-md-8" id="preview_area_of_use"></div>
                </div>
                <div class="row mb-2" id="preview_room_number_row" style="display: none;">
                    <div class="col-md-4 fw-bold">Room Number:</div>
                    <div class="col-md-8" id="preview_room_number"></div>
                </div>
                <div class="row mb-2" id="preview_department_row" style="display: none;">
                    <div class="col-md-4 fw-bold">Department:</div>
                    <div class="col-md-8" id="preview_department"></div>
                </div>
                <div class="row mb-2" id="preview_avr_selection_row" style="display: none;">
                    <div class="col-md-4 fw-bold">AVR Selection:</div>
                    <div class="col-md-8" id="preview_avr_selection"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4 fw-bold">Date:</div>
                    <div class="col-md-8" id="preview_event_date"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4 fw-bold">Time:</div>
                    <div class="col-md-8"><span id="preview_start_time"></span> - <span id="preview_end_time"></span></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4 fw-bold">Location:</div>
                    <div class="col-md-8" id="preview_location"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4 fw-bold">Description:</div>
                    <div class="col-md-8" id="preview_description"></div>
                </div>
                <!-- Approval message removed - not needed in preview -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="editEventBtn">
                    <i class="fas fa-edit"></i> {{ app()->getLocale() === 'tl' ? 'I-edit' : 'Edit' }}
                </button>
                <button type="submit" form="eventRequestForm" class="btn btn-primary" id="submitEventBtn">
                    <i class="fas fa-check"></i> {{ app()->getLocale() === 'tl' ? 'Isumite para sa Pag-apruba' : 'Submit for Approval' }}
                </button>
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('js/facility-rooms.js') }}"></script>
<script>
// Facility Request Form Script v2.0 - Updated 2026-06-01
// Define updateDescCount globally so it's available for inline oninput handlers
window.updateDescCount = function() {
    var ta = document.getElementById('modal_description');
    var counter = document.getElementById('desc_char_count');
    if (ta && counter) {
        var len = ta.value.length;
        counter.textContent = len + ' / 500';
        counter.style.color = len >= 480 ? '#dc3545' : '';
    }
};

document.addEventListener('DOMContentLoaded', function() {
    var approvalChainMap = @json($eventApprovalChains->mapWithKeys(fn ($chain) => [($chain->intendedUser->code ?? '').'|'.($chain->requestType->name ?? '') => $chain->approval_roles]));
    var intendedRouteMap = @json($eventUsers->mapWithKeys(fn ($item) => [(is_array($item) ? $item['code'] : $item->code) => (is_array($item) ? [] : ($item->approval_roles ?: []))]));
    var approvalRoleLabels = { principal_assistant: 'Principal Assistant', program_head: 'Program Head', academic_head: 'Academic Head', building_admin: 'Building Admin', school_admin: 'School Administrator' };
    var availabilitySnapshotProvided = @json(isset($eventAvailabilityBookings));
    var eventAvailabilityBookings = @json($eventAvailabilityBookings ?? []);
    var facilityAvailabilityStatuses = @json(isset($facilities) ? collect($facilities)->mapWithKeys(fn ($facility) => [$facility->name => $facility->status])->all() : []);

    function selectedApprovalRoute(requestTypeValue, intendedUserValue) {
        var intendedUser = document.getElementById('modal_intended_user');
        var intendedRoute = intendedUser ? (intendedRouteMap[intendedUser.value] || []) : [];
        return approvalChainMap[intendedUserValue + '|' + requestTypeValue] || intendedRoute;
    }

    function shouldRequireDepartment(requestTypeValue, intendedUserValue, areaValue) {
        var configuredRoute = selectedApprovalRoute(requestTypeValue, intendedUserValue);
        if (configuredRoute.length) return configuredRoute.includes('program_head') && !!areaValue;
        var selected = document.querySelector('#modal_request_type option[value="' + String(requestTypeValue).replace(/"/g, '\\"') + '"]');
        return !!selected && selected.dataset.requiresDepartment === '1' && !!areaValue;
    }

    function syncDepartmentRequirement() {
        var requestType = document.getElementById('modal_request_type');
        var intendedUser = document.getElementById('modal_intended_user');
        var areaOfUse = document.getElementById('modal_area_of_use');
        var departmentContainer = document.getElementById('modal_department_container');
        var departmentSelect = document.getElementById('modal_department');
        var isRequired = shouldRequireDepartment(
            requestType ? requestType.value : '',
            intendedUser ? intendedUser.value : '',
            areaOfUse ? areaOfUse.value : ''
        );

        if (departmentContainer) {
            departmentContainer.style.display = isRequired ? 'block' : 'none';
        }

        if (departmentSelect) {
            if (isRequired) {
                departmentSelect.setAttribute('required', 'required');
            } else {
                departmentSelect.removeAttribute('required');
                departmentSelect.value = '';
            }
        }
    }

    var modalRequestType = document.getElementById('modal_request_type');
    if (modalRequestType) {
        modalRequestType.addEventListener('change', function() {
            var areaOfUseContainer = document.getElementById('modal_area_of_use_container');
            var areaOfUseSelect = document.getElementById('modal_area_of_use');
            var departmentContainer = document.getElementById('modal_department_container');
            var departmentSelect = document.getElementById('modal_department');

            // Always show area of use when request type is selected (category is always "Area Use")
            if (this.value) {
                areaOfUseContainer.style.display = 'block';
                areaOfUseSelect.required = true;
                
            } else {
                areaOfUseContainer.style.display = 'none';
                areaOfUseSelect.required = false;
                areaOfUseSelect.value = '';
                // Reset all dependent fields
                var avrSelectionContainer = document.getElementById('modal_avr_selection_container');
                if (departmentContainer) departmentContainer.style.display = 'none';
                if (avrSelectionContainer) avrSelectionContainer.style.display = 'none';
            }
            syncDepartmentRequirement();
            updatePreviewButtonState();
        });
    }

    var modalAreaOfUse = document.getElementById('modal_area_of_use');
    if (modalAreaOfUse) {
        modalAreaOfUse.addEventListener('change', function() {
            var departmentContainer = document.getElementById('modal_department_container');
            var avrSelectionContainer = document.getElementById('modal_avr_selection_container');
            var departmentSelect = document.getElementById('modal_department');
            var avrSelectionSelect = document.getElementById('modal_avr_selection');

            // Clear court availability message
            var existingCourtMsg = document.getElementById('modal_court_availability_message');
            if (existingCourtMsg) {
                existingCourtMsg.remove();
            }

            // Clear AVR availability message
            var existingAvrMsg = document.getElementById('modal_avr_availability_message');
            if (existingAvrMsg) {
                existingAvrMsg.remove();
            }

            var selectedLocation = this.value;

            // Check if location contains "Court" or "AVR" keywords
            var isCourt = selectedLocation && (selectedLocation.toLowerCase().includes('court') || selectedLocation === 'Court');
            var isAVR = selectedLocation && (selectedLocation.toLowerCase().includes('avr') || selectedLocation === 'AVR');
            var isRoom = selectedLocation && (selectedLocation.toLowerCase().includes('room') || selectedLocation.toLowerCase().includes('lab') || selectedLocation.match(/^\d{3}$/));

            if (isCourt) {
                if (avrSelectionContainer) avrSelectionContainer.style.display = 'none';
                if (avrSelectionSelect) avrSelectionSelect.removeAttribute('required');
                if (avrSelectionSelect) avrSelectionSelect.value = '';
            } else if (isAVR) {
                if (avrSelectionContainer) avrSelectionContainer.style.display = 'none'; // AVR is now in the main dropdown
            } else if (isRoom) {
                if (avrSelectionContainer) avrSelectionContainer.style.display = 'none';
                if (avrSelectionSelect) avrSelectionSelect.removeAttribute('required');
                if (avrSelectionSelect) avrSelectionSelect.value = '';
            } else {
                if (avrSelectionContainer) avrSelectionContainer.style.display = 'none';
                if (avrSelectionSelect) avrSelectionSelect.removeAttribute('required');
                if (avrSelectionSelect) avrSelectionSelect.value = '';
            }
            syncDepartmentRequirement();
            updatePreviewButtonState();
        });
    }

    // Court availability check
    function checkCourtAvailabilityModal() {
        var eventDate = document.getElementById('modal_event_date') ? document.getElementById('modal_event_date').value : '';
        var startTime = document.getElementById('modal_start_time') ? document.getElementById('modal_start_time').value : '';
        var endTime = document.getElementById('modal_end_time') ? document.getElementById('modal_end_time').value : '';
        var areaOfUse = document.getElementById('modal_area_of_use') ? document.getElementById('modal_area_of_use').value : '';

        // Check if location contains "Court"
        var isCourt = areaOfUse && (areaOfUse.toLowerCase().includes('court') || areaOfUse === 'Court');
        
        if (!eventDate || !startTime || !endTime || !isCourt) {
            return; // Don't check if fields are empty or not checking court
        }

        // Remove previous availability message
        var existingMsg = document.getElementById('modal_court_availability_message');
        if (existingMsg) {
            existingMsg.remove();
        }

        // Show loading message
        var messageDiv = document.createElement('div');
        messageDiv.id = 'modal_court_availability_message';
        messageDiv.className = 'alert alert-info mt-2';
        messageDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking court availability...';

        var areaOfUseContainer = document.getElementById('modal_area_of_use_container');
        if (areaOfUseContainer) {
            areaOfUseContainer.parentNode.insertBefore(messageDiv, areaOfUseContainer.nextSibling);
        }

        fetch('/api/check-court-availability', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            credentials: 'same-origin',
            body: JSON.stringify({
                event_date: eventDate,
                start_time: startTime,
                end_time: endTime
            })
        })
        .then(response => response.json())
        .then(data => {
            var messageDiv = document.getElementById('modal_court_availability_message');
            if (!messageDiv) return;

            if (data.available) {
                messageDiv.className = 'alert alert-success mt-2';
                messageDiv.innerHTML = '<i class="fas fa-check-circle"></i> Court is available for the selected time.';
            } else {
                messageDiv.className = 'alert alert-danger mt-2';
                var conflicts = data.conflicting_events.map(event =>
                    `${event.title} (${event.start_time} - ${event.end_time}) by ${event.user}`
                ).join('<br>');
                messageDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Court is not available. Conflicts:<br>' + conflicts;
            }
        })
        .catch(error => {
            console.error('Error checking court availability:', error);
            var messageDiv = document.getElementById('modal_court_availability_message');
            if (messageDiv) {
                messageDiv.className = 'alert alert-warning mt-2';
                messageDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error checking court availability. Please try again.';
            }
        });
    }

    // AVR availability check
    function checkAvrAvailabilityModal() {
        var avrSelection = document.getElementById('modal_avr_selection') ? document.getElementById('modal_avr_selection').value : '';
        var eventDate = document.getElementById('modal_event_date') ? document.getElementById('modal_event_date').value : '';
        var startTime = document.getElementById('modal_start_time') ? document.getElementById('modal_start_time').value : '';
        var endTime = document.getElementById('modal_end_time') ? document.getElementById('modal_end_time').value : '';
        var areaOfUse = document.getElementById('modal_area_of_use') ? document.getElementById('modal_area_of_use').value : '';

        if (!avrSelection || !eventDate || !startTime || !endTime || areaOfUse !== 'AVR') {
            return; // Don't check if fields are empty or not checking AVR
        }

        // Remove previous availability message
        var existingMsg = document.getElementById('modal_avr_availability_message');
        if (existingMsg) {
            existingMsg.remove();
        }

        // Show loading message
        var messageDiv = document.createElement('div');
        messageDiv.id = 'modal_avr_availability_message';
        messageDiv.className = 'alert alert-info mt-2';
        messageDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking AVR availability...';

        var avrContainer = document.getElementById('modal_avr_request_category_container');
        if (avrContainer) {
            avrContainer.parentNode.insertBefore(messageDiv, avrContainer.nextSibling);
        }

        fetch('/api/check-avr-availability', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            credentials: 'same-origin',
            body: JSON.stringify({
                avr_selection: avrSelection,
                event_date: eventDate,
                start_time: startTime,
                end_time: endTime
            })
        })
        .then(response => response.json())
        .then(data => {
            var messageDiv = document.getElementById('modal_avr_availability_message');

            if (data.available) {
                messageDiv.className = 'alert alert-success mt-2';
                messageDiv.innerHTML = '<i class="fas fa-check-circle"></i> ' + avrSelection + ' is available for the selected time.';
            } else {
                messageDiv.className = 'alert alert-danger mt-2';
                var conflicts = data.conflicting_events.map(event =>
                    `${event.title} (${event.start_time} - ${event.end_time}) by ${event.user}`
                ).join('<br>');
                messageDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i> ' + avrSelection + ' is not available. Conflicts:<br>' + conflicts;
            }
        })
        .catch(error => {
            console.error('Error checking AVR availability:', error);
            var messageDiv = document.getElementById('modal_avr_availability_message');
            if (messageDiv) {
                messageDiv.className = 'alert alert-warning mt-2';
                messageDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error checking AVR availability. Please try again.';
            }
        });
    }

    window.FacilityRooms.init({snapshot: availabilitySnapshotProvided, bookings: eventAvailabilityBookings, statuses: facilityAvailabilityStatuses, oldRooms: @json(array_values((array) old('rooms', [])))});

    // Availability check listeners
    var modalEventDate = document.getElementById('modal_event_date');
    var modalStartTime = document.getElementById('modal_start_time');
    var modalEndTime = document.getElementById('modal_end_time');
    var modalAreaOfUse = document.getElementById('modal_area_of_use');

    [modalEventDate, modalStartTime, modalEndTime, modalAreaOfUse].forEach(function(element) {
        if (element) {
            element.addEventListener('change', checkRoomAvailability);
        }
    });

    function checkRoomAvailability() {
        return window.FacilityRooms.checkAvailability();
    }

    // Function to check if required fields are filled and enable/disable Preview button
    function updatePreviewButtonState() {
        var requestType = document.getElementById('modal_request_type');
        var areaOfUse = document.getElementById('modal_area_of_use');
        var department = document.getElementById('modal_department');
        var intendedUser = document.getElementById('modal_intended_user');
        var avrSelection = document.getElementById('modal_avr_selection');
        var eventDate = document.getElementById('modal_event_date');
        var startTime = document.getElementById('modal_start_time');
        var endTime = document.getElementById('modal_end_time');
        var description = document.getElementById('modal_description');
        var previewBtn = document.getElementById('previewBtn');

        var isValid = true;
        var requestTypeValue = requestType ? requestType.value : '';
        var areaValue = areaOfUse ? areaOfUse.value : '';
        var intendedUserValue = intendedUser ? intendedUser.value : '';

        // Request type is required
        if (!requestTypeValue) isValid = false;
        if (!intendedUser || !intendedUser.value) isValid = false;

        // Area of use is always required (category is always "Area Use")
        if (!areaValue) isValid = false;

        // Check if location is a room, court, or AVR
        var isRoom = areaValue && (areaValue.toLowerCase().includes('room') || areaValue.toLowerCase().includes('lab') || areaValue.match(/^\d{3}$/));
        var isCourt = areaValue && areaValue.toLowerCase().includes('court');
        var isAVR = areaValue && areaValue.toLowerCase().includes('avr');

        if (isRoom || isCourt || isAVR) {
            if (shouldRequireDepartment(requestTypeValue, intendedUserValue, areaValue) && (!department || !department.value)) {
                isValid = false;
            }
        }

        if (!eventDate || !eventDate.value) isValid = false;
        if (!startTime || !startTime.value) isValid = false;
        if (!endTime || !endTime.value) isValid = false;
        if (startTime && endTime && startTime.value && endTime.value && endTime.value <= startTime.value) isValid = false;
        if (!description || !description.value.trim()) isValid = false;

        if (previewBtn) {
            previewBtn.disabled = false;
            previewBtn.classList.toggle('btn-secondary', !isValid);
            previewBtn.classList.toggle('btn-primary', isValid);
        }
    }
    
    // Add event listeners to all required fields to update Preview button state
    var requiredFieldIds = ['modal_request_type', 'modal_area_of_use', 'modal_department', 'modal_intended_user', 'modal_avr_selection', 'modal_event_date', 'modal_start_time', 'modal_end_time', 'modal_description'];
    requiredFieldIds.forEach(function(fieldId) {
        var field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('input', updatePreviewButtonState);
            field.addEventListener('change', updatePreviewButtonState);
        }
    });
    
    // Initial check on page load
    updatePreviewButtonState();

    // Populate preview modal when shown
    var previewModal = document.getElementById('eventPreviewModal');
    if (previewModal) {
        previewModal.addEventListener('show.bs.modal', function() {
            // Get form values
            var requestType = document.getElementById('modal_request_type').value;
            var intendedUser = document.getElementById('modal_intended_user').value;
            var areaOfUse = document.getElementById('modal_area_of_use').value;
            var department = document.getElementById('modal_department').value;
            var avrSelection = document.getElementById('modal_avr_selection').value;
            var eventDate = document.getElementById('modal_event_date').value;
            var startTime = document.getElementById('modal_start_time').value;
            var endTime = document.getElementById('modal_end_time').value;
            var description = document.getElementById('modal_description').value;

            // Build location from selected options
            var location = areaOfUse || '';

            // Populate preview fields
            document.getElementById('preview_category').textContent = 'Area Use';
            document.getElementById('preview_request_type').textContent = requestType || 'Not specified';
            document.getElementById('preview_intended_user').textContent = document.getElementById('modal_intended_user').selectedOptions[0]?.textContent || intendedUser || 'Not specified';
            document.getElementById('preview_area_of_use').textContent = areaOfUse || 'Not specified';
            document.getElementById('preview_department').textContent = department || 'Not specified';
            var avrSelectionEl = document.getElementById('preview_avr_selection');
            if (avrSelectionEl) avrSelectionEl.textContent = avrSelection || 'Not specified';
            document.getElementById('preview_event_date').textContent = eventDate ? new Date(eventDate).toLocaleDateString() : 'Not specified';
            document.getElementById('preview_start_time').textContent = startTime || 'Not specified';
            document.getElementById('preview_end_time').textContent = endTime || 'Not specified';
            document.getElementById('preview_location').textContent = location || 'Not specified';
            document.getElementById('preview_description').textContent = description || 'Not specified';
            window.FacilityRooms.preview();

            // Show/hide area of use row
            var areaOfUseRow = document.getElementById('preview_area_of_use_row');
            if (areaOfUse) {
                areaOfUseRow.style.display = 'block';
            } else {
                areaOfUseRow.style.display = 'none';
            }

            // Hide room number row (no longer used)
            var roomNumberRow = document.getElementById('preview_room_number_row');
            if (roomNumberRow) {
                roomNumberRow.style.display = 'none';
            }

            // Show the department whenever the configured route requires it.
            var departmentRow = document.getElementById('preview_department_row');
            if (departmentRow && department) {
                departmentRow.style.display = 'block';
            } else if (departmentRow) {
                departmentRow.style.display = 'none';
            }

            // Check if location contains "avr" keyword
            var isAVR = areaOfUse && areaOfUse.toLowerCase().includes('avr');

            // Show/hide AVR selection row
            var avrSelectionRow = document.getElementById('preview_avr_selection_row');
            if (isAVR && avrSelection) {
                avrSelectionRow.style.display = 'block';
            } else {
                avrSelectionRow.style.display = 'none';
            }
        });
    }
    
    // Validation function for facility request form
    function validateEventRequestForm() {
        // Clear previous errors
        clearValidationErrors();
        
        var errors = [];
        var isValid = true;
        var firstErrorField = null;
        
        // Get form elements
        var requestType = document.getElementById('modal_request_type');
        var intendedUser = document.getElementById('modal_intended_user');
        var eventDate = document.getElementById('modal_event_date');
        var startTime = document.getElementById('modal_start_time');
        var endTime = document.getElementById('modal_end_time');
        var description = document.getElementById('modal_description');
        
        // Validate Request Type
        if (!requestType.value) {
            showFieldError(requestType, 'Please select a request type');
            errors.push('Request type is required');
            isValid = false;
        }
        if (!intendedUser || !intendedUser.value) {
            showFieldError(intendedUser, 'Please select an intended user');
            errors.push('Intended user is required');
            isValid = false;
        }

        var areaOfUse = document.getElementById('modal_area_of_use');

        // Validate Area of Use (always required since category is always "Area Use")
        if (!areaOfUse || !areaOfUse.value) {
            showFieldError(areaOfUse, 'Please select an area of use');
            errors.push('Area of use is required');
            isValid = false;
        }

        // No need to validate room number separately - it's now part of area_of_use

        // Validate Department (if Academic request type is selected and location is chosen)
        var department = document.getElementById('modal_department');
        var intendedUserValue = intendedUser ? intendedUser.value : '';
        var isRoom = areaOfUse.value && (areaOfUse.value.toLowerCase().includes('room') || areaOfUse.value.toLowerCase().includes('lab') || areaOfUse.value.match(/^\d{3}$/));
        var isCourt = areaOfUse.value && areaOfUse.value.toLowerCase().includes('court');
        var isAVR = areaOfUse.value && areaOfUse.value.toLowerCase().includes('avr');
        
        if ((isRoom || isCourt || isAVR) && shouldRequireDepartment(requestType.value, intendedUserValue, areaOfUse.value) && !department.value) {
            showFieldError(department, 'Please select a department for academic requests');
            errors.push('Department is required for academic requests');
            isValid = false;
        }
        
        // Validate Date of Use
        if (!eventDate.value) {
            showFieldError(eventDate, 'Date of use is required');
            errors.push('Date is required');
            isValid = false;
        } else {
            var selectedDate = new Date(eventDate.value);
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            if (selectedDate < today) {
                showFieldError(eventDate, 'Date of use cannot be in the past');
                errors.push('Date cannot be in the past');
                isValid = false;
            }
        }
        
        // Validate Start Time
        if (!startTime.value) {
            showFieldError(startTime, 'Start time is required');
            errors.push('Start time is required');
            isValid = false;
        }
        
        // Validate End Time
        if (!endTime.value) {
            showFieldError(endTime, 'End time is required');
            errors.push('End time is required');
            isValid = false;
        }
        
        // Validate End Time is after Start Time
        if (startTime.value && endTime.value) {
            if (endTime.value <= startTime.value) {
                showFieldError(endTime, 'End time must be after start time');
                errors.push('End time must be after start time');
                isValid = false;
            }
        }

        var roomError = window.FacilityRooms.validate();
        if (roomError) {
            errors.push(roomError);
            isValid = false;
        }

        // Validate Description
        if (!description.value.trim()) {
            showFieldError(description, 'Description is required');
            errors.push('Description is required');
            isValid = false;
        }

        // Prevent submission when the selected facility is already reserved or unavailable.
        var areaOfUse = document.getElementById('modal_area_of_use');
        var facilityAvailabilityMsg = document.getElementById('modal_facility_availability_message');
        if (areaOfUse && facilityAvailabilityMsg && facilityAvailabilityMsg.classList.contains('alert-danger')) {
            showFieldError(areaOfUse, 'This facility is not available for the chosen time. Please select another facility or time.');
            errors.push('Facility not available');
            isValid = false;
        }
        
        if (!isValid && errors.length) {
            showErrorAlert(errors[0]);
        }

        return isValid;
    }
    
    // Show field error
    function showFieldError(field, message) {
        field.classList.add('is-invalid');
        var feedbackDiv = field.nextElementSibling;
        if (feedbackDiv && feedbackDiv.classList.contains('invalid-feedback')) {
            feedbackDiv.textContent = message;
        } else {
            var div = document.createElement('div');
            div.className = 'invalid-feedback';
            div.textContent = message;
            field.parentNode.insertBefore(div, field.nextSibling);
        }
    }
    
    // Clear all validation errors
    function clearValidationErrors() {
        var form = document.getElementById('eventRequestForm');
        if (form) {
            var invalidFields = form.querySelectorAll('.is-invalid');
            invalidFields.forEach(function(field) {
                field.classList.remove('is-invalid');
            });
        }
        // Remove error alert if exists
        var errorAlert = document.getElementById('eventValidationError');
        if (errorAlert) {
            errorAlert.remove();
        }
    }
    
    // Add form submit handler to prevent submission if validation fails
    var eventRequestForm = document.getElementById('eventRequestForm');
    if (eventRequestForm) {
        eventRequestForm.addEventListener('submit', function(e) {
            if (!validateEventRequestForm()) {
                e.preventDefault();
                return false;
            }
        });
    }
    
    // Show error alert
    function showErrorAlert(message) {
        var modalBody = document.querySelector('#eventRequestModal .modal-body');
        if (modalBody) {
            var existingAlert = document.getElementById('eventValidationError');
            if (existingAlert) {
                existingAlert.remove();
            }
            var alertDiv = document.createElement('div');
            alertDiv.id = 'eventValidationError';
            alertDiv.className = 'alert alert-danger alert-dismissible fade show';
            alertDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> <strong>Validation Error:</strong> ' + message + '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
            modalBody.insertBefore(alertDiv, modalBody.firstChild);
        }
    }
    
    // Preview button click handler
    var previewBtn = document.getElementById('previewBtn');
    if (previewBtn) {
        previewBtn.addEventListener('click', function(e) {
            e.preventDefault();

            // Run validation first
            if (!validateEventRequestForm()) {
                return;
            }

            // Get form values
            var requestType = document.getElementById('modal_request_type').value;
            var areaOfUse = document.getElementById('modal_area_of_use').value;
            var department = document.getElementById('modal_department').value;
            var intendedUser = document.getElementById('modal_intended_user').value;
            var avrSelectionValue = document.getElementById('modal_avr_selection').value;
            var eventDate = document.getElementById('modal_event_date').value;
            var startTime = document.getElementById('modal_start_time').value;
            var endTime = document.getElementById('modal_end_time').value;
            var description = document.getElementById('modal_description').value;
            
            // Location is now just the area of use value (which includes the specific room/facility)
            var location = areaOfUse || '';

            var dateDisplay = eventDate ? new Date(eventDate).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : '';

            var formatTime = function(time) {
                if (!time) return '';
                var parts = time.split(':');
                var hours = parseInt(parts[0], 10);
                var minutes = parts[1];
                var period = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12 || 12;
                return hours + ':' + minutes + ' ' + period;
            };

            // Set the hidden location field
            document.getElementById('modal_location').value = location;

            document.getElementById('preview_category').textContent = 'Area Use';
            document.getElementById('preview_request_type').textContent = requestType || 'Not specified';
            document.getElementById('preview_intended_user').textContent = document.getElementById('modal_intended_user').selectedOptions[0]?.textContent || intendedUser || 'Not specified';
            document.getElementById('preview_area_of_use').textContent = areaOfUse || 'Not specified';
            document.getElementById('preview_department').textContent = department || 'Not specified';
            document.getElementById('preview_avr_selection').textContent = avrSelectionValue || 'Not specified';
            document.getElementById('preview_event_date').textContent = dateDisplay || '-';
            document.getElementById('preview_start_time').textContent = formatTime(startTime);
            document.getElementById('preview_end_time').textContent = formatTime(endTime);
            document.getElementById('preview_location').textContent = location || 'Not specified';
            document.getElementById('preview_description').textContent = description || '-';
            window.FacilityRooms.preview();

            document.getElementById('preview_area_of_use_row').style.display = areaOfUse ? 'flex' : 'none';
            document.getElementById('preview_room_number_row').style.display = 'none'; // Room number row is no longer used
            document.getElementById('preview_department_row').style.display = department ? 'flex' : 'none';
            
            // Check if location contains "avr" keyword
            var isAVR = areaOfUse && areaOfUse.toLowerCase().includes('avr');
            
            document.getElementById('preview_avr_selection_row').style.display = (isAVR && avrSelectionValue) ? 'flex' : 'none';

            // Set approval recipients based on intended user, department, and request type
            var approvalRecipients = 'Chosen Department on the selection, Academic Head, Building Admin, and School Administrator';

            // SHS approval flow: Principal Assistant → Academic Head → School Administrator
            if (intendedUser === 'shs') {
                approvalRecipients = 'Principal Assistant, Academic Head, and School Administrator';
            } else if (requestType === 'Non-Academic') {
                // Non-academic requests (Court or AVR)
                approvalRecipients = 'Building Admin and School Administrator';
            } else if (department && requestType === 'Academic') {
                // Academic requests with department (Room, Court, or AVR)
                var deptHead = '';
                switch(department) {
                    case 'GE':
                        deptHead = 'GE Department Head';
                        break;
                    case 'ICT':
                        deptHead = 'ICT Department Head';
                        break;
                    case 'Business Management':
                        deptHead = 'Business Management Department Head';
                        break;
                    case 'THM':
                        deptHead = 'THM Department Head';
                        break;
                }
                if (deptHead) {
                    approvalRecipients = deptHead + ', Academic Head, Building Admin, and School Administrator';
                }
            }
            var approvalRecipientsEl = document.getElementById('approval_recipients');
            if (approvalRecipientsEl) {
                var previewRoute = selectedApprovalRoute(requestType, intendedUser);
                if (previewRoute.length) approvalRecipients = previewRoute.map(function (role) { return approvalRoleLabels[role] || role; }).join(' → ');
                approvalRecipientsEl.textContent = approvalRecipients;
            }

            var requestModalEl = document.getElementById('eventRequestModal');
            var previewModalEl = document.getElementById('eventPreviewModal');

            if (requestModalEl && previewModalEl) {
                var requestModal = bootstrap.Modal.getOrCreateInstance(requestModalEl);
                requestModalEl.addEventListener('hidden.bs.modal', function showPreviewOnce() {
                    bootstrap.Modal.getOrCreateInstance(previewModalEl).show();
                }, { once: true });
                requestModal.hide();
            }
        });
    }

    // Handle Edit button in preview modal
    var editEventBtn = document.getElementById('editEventBtn');
    if (editEventBtn) {
        editEventBtn.addEventListener('click', function() {
            var previewModalEl = document.getElementById('eventPreviewModal');
            var requestModalEl = document.getElementById('eventRequestModal');
            
            if (previewModalEl && requestModalEl) {
                bootstrap.Modal.getOrCreateInstance(previewModalEl).hide();
                setTimeout(function() {
                    bootstrap.Modal.getOrCreateInstance(requestModalEl).show();
                }, 300);
            }
        });
    }

    // AVR Selection change handler for modal
    var modalAvrSelection = document.getElementById('modal_avr_selection');
    if (modalAvrSelection) {
        modalAvrSelection.addEventListener('change', function() {
            // AVR selection doesn't need to show additional fields anymore
            // Department visibility is controlled by request_type in area_of_use handler
            updatePreviewButtonState();
        });
    }

    // Update approval recipients on department or request type change
    var departmentSelect = document.getElementById('modal_department');
    var requestTypeSelect = document.getElementById('modal_request_type');

    function updateApprovalRecipients() {
        var areaOfUseEl = document.getElementById('modal_area_of_use');
        var intendedUserEl = document.getElementById('modal_intended_user');
        var areaOfUse = areaOfUseEl ? areaOfUseEl.value : '';
        var requestType = requestTypeSelect ? requestTypeSelect.value : '';
        var department = departmentSelect ? departmentSelect.value : '';
        var intendedUser = intendedUserEl ? intendedUserEl.value : '';
        var configuredRoute = selectedApprovalRoute(requestType, intendedUser);
        if (configuredRoute.length) {
            var configuredRecipients = document.getElementById('approval_recipients');
            if (configuredRecipients) configuredRecipients.textContent = configuredRoute.map(function (role) { return approvalRoleLabels[role] || role; }).join(' → ');
            return;
        }
        var approvalRecipients = 'Chosen Department on the selection, Academic Head, Building Admin, and School Administrator';

        if (intendedUser === 'shs') {
            department = '';
        }

        // SHS approval flow: Principal Assistant → Academic Head → School Administrator
        if (intendedUser === 'shs') {
            approvalRecipients = 'Principal Assistant, Academic Head, and School Administrator';
        } else if (requestType === 'Non-Academic') {
            // Non-academic requests (Court or AVR)
            approvalRecipients = 'Building Admin and School Administrator';
        } else if (department && requestType === 'Academic') {
            // Academic requests with department (Room, Court, or AVR)
            var deptHead = '';
            switch(department) {
                case 'GE':
                    deptHead = 'GE Department Head';
                    break;
                case 'ICT':
                    deptHead = 'ICT Department Head';
                    break;
                case 'Business Management':
                    deptHead = 'Business Management Department Head';
                    break;
                case 'THM':
                    deptHead = 'THM Department Head';
                    break;
            }
            if (deptHead) {
                approvalRecipients = deptHead + ', Academic Head, Building Admin, and School Administrator';
            }
        }
        var approvalRecipientsEl = document.getElementById('approval_recipients');
        if (approvalRecipientsEl) {
            approvalRecipientsEl.textContent = approvalRecipients;
        }
    }

    if (departmentSelect) {
        departmentSelect.addEventListener('change', updateApprovalRecipients);
    }
    if (requestTypeSelect) {
        requestTypeSelect.addEventListener('change', updateApprovalRecipients);
    }
    var intendedUserSelect = document.getElementById('modal_intended_user');
    if (intendedUserSelect) {
        intendedUserSelect.addEventListener('change', function() {
            syncDepartmentRequirement();
            updateApprovalRecipients();
        });
    }

    // Materials/Equipment dynamic rows for modal
    let modalMaterialRowCount = 1;

    window.addModalMaterialRow = function() {
        var table = document.getElementById('modalMaterialsTable');
        if (table) {
            var tbody = table.getElementsByTagName('tbody')[0];
            var newRow = tbody.insertRow();
            newRow.innerHTML = `
                <td><input type="number" class="form-control form-control-sm" name="materials[${modalMaterialRowCount}][qty]" min="1" placeholder="1"></td>
                <td><input type="text" class="form-control form-control-sm" name="materials[${modalMaterialRowCount}][item]" placeholder="e.g., Projector"></td>
                <td><button type="button" class="btn btn-danger btn-sm" onclick="removeModalMaterialRow(this)"><i class="fas fa-times"></i></button></td>
            `;
            modalMaterialRowCount++;
        }
    };

    window.removeModalMaterialRow = function(button) {
        var table = document.getElementById('modalMaterialsTable');
        if (table) {
            var tbody = table.getElementsByTagName('tbody')[0];
            if (tbody.rows.length > 1) {
                button.closest('tr').remove();
            }
        }
    };
});
    
    // Auto-open modal if there are validation errors (only on event-related pages)
    @if($errors->any() && !Request::is('admin/users*', 'admin/logs*', 'admin/reports*', 'admin/dashboard*', 'admin/management*', 'settings*', 'profile*', 'my-concerns*', 'reports*'))
    document.addEventListener('DOMContentLoaded', function() {
        var modalEl = document.getElementById('eventRequestModal');
        if (modalEl) {
            var modal = new bootstrap.Modal(modalEl);
            modal.show();
        }
    });
    @endif
    
</script>
@endif

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11" defer></script>

<script>
// Critical JavaScript functions for navigation and dropdowns
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    if (sidebar && overlay) {
        sidebar.classList.toggle('show');
        overlay.classList.toggle('show');
    }
}

function toggleDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('userDropdownMenu');
    const notificationDropdown = document.getElementById('notificationDropdown');
    
    if (notificationDropdown && notificationDropdown.classList.contains('show')) {
        notificationDropdown.classList.remove('show');
    }
    
    if (dropdown) {
        dropdown.classList.toggle('show');
    }
}

function toggleNotification(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('notificationDropdown');
    const userDropdown = document.getElementById('userDropdownMenu');
    
    if (userDropdown && userDropdown.classList.contains('show')) {
        userDropdown.classList.remove('show');
    }
    
    if (dropdown) {
        dropdown.classList.toggle('show');
    }
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    const userDropdown = document.getElementById('userDropdownMenu');
    const notificationDropdown = document.getElementById('notificationDropdown');
    const userIcon = document.querySelector('.user-icon');
    const notificationBell = document.querySelector('.notification-bell');
    
    if (userDropdown && !event.target.closest('.user-dropdown-top')) {
        userDropdown.classList.remove('show');
    }
    
    if (notificationDropdown && !event.target.closest('.notification-bell')) {
        notificationDropdown.classList.remove('show');
    }
});

// Nav dropdown toggle
document.addEventListener('DOMContentLoaded', function() {
    const navToggles = document.querySelectorAll('[data-nav-toggle]');
    navToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const parent = this.closest('.nav-dropdown');
            if (parent) {
                parent.classList.toggle('open');
            }
        });
    });
});

// Make functions globally available
window.toggleSidebar = toggleSidebar;
window.toggleDropdown = toggleDropdown;
window.toggleNotification = toggleNotification;
</script>

<script>
// Pass facilities data to JavaScript
@if(isset($facilities))
window.facilitiesData = @json($facilities);
@endif

// ── SweetAlert2 Global Helpers ────────────────────────────────────────────────

// Themed Swal instance that respects dark mode
function getSwal() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    return Swal.mixin({
        background: isDark ? '#1a1a2e' : '#fff',
        color: isDark ? '#e0e0e0' : '#333',
        confirmButtonColor: '#0d6efd',
        cancelButtonColor: '#6c757d',
    });
}

// Drop-in replacement for confirm() — returns a Promise
window.swalConfirm = function(options) {
    const defaults = {
        title: 'Are you sure?',
        text: '',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'Cancel',
    };
    return getSwal().fire(Object.assign(defaults, options));
};

// Drop-in replacement for alert()
window.swalAlert = function(message, icon = 'info', title = '') {
    return getSwal().fire({ title: title || (icon === 'error' ? 'Error' : icon === 'success' ? 'Success' : 'Notice'), text: message, icon });
};

// Toast notification (top-right, auto-dismiss)
window.swalToast = function(message, icon = 'success') {
    getSwal().mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
    }).fire({ icon, title: message });
};

// ── Global Action Confirmations ──────────────────────────────────────────────

// Delete confirmation
window.confirmDelete = function(options = {}) {
    return getSwal().fire({
        title: options.title || 'Delete this item?',
        text: options.text || 'This action cannot be undone.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: options.confirmText || '<i class="fas fa-trash me-1"></i> Delete',
        cancelButtonText: 'Cancel',
        ...options
    });
};

// Archive confirmation
window.confirmArchive = function(options = {}) {
    return getSwal().fire({
        title: options.title || 'Archive this item?',
        text: options.text || 'You can restore it later from the archive.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#6c757d',
        cancelButtonColor: '#6c757d',
        confirmButtonText: options.confirmText || '<i class="fas fa-archive me-1"></i> Archive',
        cancelButtonText: 'Cancel',
        ...options
    });
};

// Restore confirmation
window.confirmRestore = function(options = {}) {
    return getSwal().fire({
        title: options.title || 'Restore this item?',
        text: options.text || 'This will move the item back to active items.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: options.confirmText || '<i class="fas fa-trash-restore me-1"></i> Restore',
        cancelButtonText: 'Cancel',
        ...options
    });
};

// Permanent delete confirmation
window.confirmPermanentDelete = function(options = {}) {
    return getSwal().fire({
        title: options.title || 'Permanently Delete?',
        html: options.html || '<p class="mb-2">This action <strong>cannot be undone</strong>!</p><p class="text-muted">The item will be permanently removed from the database.</p>',
        icon: 'error',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: options.confirmText || '<i class="fas fa-exclamation-triangle me-1"></i> Yes, Delete Forever',
        cancelButtonText: 'Cancel',
        ...options
    });
};

// Assign confirmation
window.confirmAssign = function(options = {}) {
    return getSwal().fire({
        title: options.title || 'Assign this item?',
        text: options.text || 'This will assign the item to the selected user.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#0d6efd',
        cancelButtonColor: '#6c757d',
        confirmButtonText: options.confirmText || '<i class="fas fa-user-check me-1"></i> Assign',
        cancelButtonText: 'Cancel',
        ...options
    });
};

// Approve confirmation
window.confirmApprove = function(options = {}) {
    return getSwal().fire({
        title: options.title || 'Approve this request?',
        text: options.text || 'This will mark the request as approved.',
        icon: 'success',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: options.confirmText || '<i class="fas fa-check me-1"></i> Approve',
        cancelButtonText: 'Cancel',
        ...options
    });
};

// Reject confirmation
window.confirmReject = function(options = {}) {
    return getSwal().fire({
        title: options.title || 'Reject this request?',
        text: options.text || 'This will mark the request as rejected.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: options.confirmText || '<i class="fas fa-times me-1"></i> Reject',
        cancelButtonText: 'Cancel',
        ...options
    });
};

// Cancel confirmation
window.confirmCancel = function(options = {}) {
    return getSwal().fire({
        title: options.title || 'Cancel this item?',
        text: options.text || 'This action will cancel the item.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ffc107',
        cancelButtonColor: '#6c757d',
        confirmButtonText: options.confirmText || '<i class="fas fa-ban me-1"></i> Cancel Item',
        cancelButtonText: 'Go Back',
        ...options
    });
};

// Generic action confirmation
window.confirmAction = function(action, options = {}) {
    const actionConfigs = {
        delete: { fn: confirmDelete, color: '#dc3545', icon: 'trash' },
        archive: { fn: confirmArchive, color: '#6c757d', icon: 'archive' },
        restore: { fn: confirmRestore, color: '#28a745', icon: 'trash-restore' },
        permanent_delete: { fn: confirmPermanentDelete, color: '#dc3545', icon: 'exclamation-triangle' },
        assign: { fn: confirmAssign, color: '#0d6efd', icon: 'user-check' },
        approve: { fn: confirmApprove, color: '#28a745', icon: 'check' },
        reject: { fn: confirmReject, color: '#dc3545', icon: 'times' },
        cancel: { fn: confirmCancel, color: '#ffc107', icon: 'ban' },
    };
    
    const config = actionConfigs[action];
    if (config && config.fn) {
        return config.fn(options);
    }
    return swalConfirm(options);
};

// Handle form submit with SweetAlert2 confirmation
// Usage: <form data-confirm="Are you sure?"> or <button data-confirm="...">
document.addEventListener('DOMContentLoaded', function () {

    // ── Flash messages from Laravel session ──────────────────────
    @if(session('success'))
        swalToast(@json(session('success')), 'success');
    @endif
    @if(session('error'))
        swalToast(@json(session('error')), 'error');
    @endif
    @if(session('warning'))
        swalToast(@json(session('warning')), 'warning');
    @endif
    @if(session('info'))
        swalToast(@json(session('info')), 'info');
    @endif

    // ── Intercept forms/buttons with data-confirm attribute ──────
    document.body.addEventListener('click', function (e) {
        const btn = e.target.closest('[data-confirm]');
        if (!btn) return;

        // If it's a submit button inside a form
        const form = btn.closest('form');
        if (form && (btn.type === 'submit' || btn.tagName === 'BUTTON')) {
            e.preventDefault();
            swalConfirm({
                title: btn.dataset.confirmTitle || 'Are you sure?',
                text: btn.dataset.confirm,
                icon: btn.dataset.confirmIcon || 'warning',
                confirmButtonText: btn.dataset.confirmOk || 'Yes',
                confirmButtonColor: btn.dataset.confirmColor || '#0d6efd',
            }).then(result => {
                if (result.isConfirmed) form.submit();
            });
        }
    });

    // ── Replace native confirm() on onclick="return confirm(...)" ─
    // Intercept all forms that have buttons with onclick confirm
    document.querySelectorAll('form button[onclick*="confirm("], form input[onclick*="confirm("]').forEach(function(btn) {
        const onclickAttr = btn.getAttribute('onclick') || '';
        const match = onclickAttr.match(/confirm\(['"](.+?)['"]\)/);
        if (!match) return;
        const message = match[1];
        btn.removeAttribute('onclick');
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const form = btn.closest('form');
            swalConfirm({ text: message }).then(result => {
                if (result.isConfirmed && form) form.submit();
            });
        });
    });

    // ── Notification delete confirm ───────────────────────────────
    document.querySelectorAll('.notification-delete-form').forEach(function(form) {
        form.removeAttribute('onsubmit');
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            swalConfirm({
                title: 'Delete notification?',
                text: 'This notification will be removed.',
                icon: 'question',
                confirmButtonText: 'Delete',
                confirmButtonColor: '#dc3545',
            }).then(result => {
                if (result.isConfirmed) form.submit();
            });
        });
    });

});
</script>
<script>
    // ── Theme System ──────────────────────────────────────────────
    const THEME_KEY = 'campfix_theme';
    const userDbTheme = @json(auth()->check() ? auth()->user()->theme : 'light');

    function applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        // Update button active states
        const lightBtn = document.getElementById('theme-light-btn');
        const darkBtn  = document.getElementById('theme-dark-btn');
        if (lightBtn && darkBtn) {
            lightBtn.style.borderColor = theme === 'light' ? '#4f6ef7' : '#dee2e6';
            darkBtn.style.borderColor  = theme === 'dark'  ? '#4f6ef7' : '#dee2e6';
        }
    }

    function setTheme(theme) {
        applyTheme(theme);
        localStorage.setItem(THEME_KEY, theme);
        // Persist to server (only if authenticated)
        const csrfToken = document.querySelector('meta[name="csrf-token"]');
        if (csrfToken) {
            fetch('/settings/theme', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken.content,
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ theme: theme }),
            }).catch(err => console.error('Theme update failed:', err));
        }
    }

    // Apply on load — DB value takes priority, fallback to localStorage
    (function() {
        const saved = userDbTheme || localStorage.getItem(THEME_KEY) || 'light';
        applyTheme(saved);
    })();

    document.addEventListener('DOMContentLoaded', function() {
        // Re-apply to update button states after DOM is ready
        const saved = userDbTheme || localStorage.getItem(THEME_KEY) || 'light';
        applyTheme(saved);
    });
    // ─────────────────────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', function () {
        const body = document.body;
        const userTimezone = body.dataset.userTimezone || 'Asia/Shanghai';
        const userLocale = body.dataset.userLocale === 'tl' ? 'fil-PH' : 'en-US';
        const userDateFormat = body.dataset.userDateFormat || 'Y-m-d';

        const buildIntlOptions = (hasTime) => {
            switch (userDateFormat) {
                case 'd/m/Y':
                    return hasTime
                        ? { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }
                        : { day: '2-digit', month: '2-digit', year: 'numeric' };
                case 'm/d/Y':
                    return hasTime
                        ? { month: '2-digit', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }
                        : { month: '2-digit', day: '2-digit', year: 'numeric' };
                case 'Y-m-d':
                default:
                    return hasTime
                        ? { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }
                        : { year: 'numeric', month: '2-digit', day: '2-digit' };
            }
        };

        document.querySelectorAll('[data-user-date]').forEach(function (element) {
            const rawValue = element.getAttribute('data-user-date');
            if (!rawValue) {
                return;
            }

            const parsedDate = new Date(rawValue);
            if (Number.isNaN(parsedDate.getTime())) {
                return;
            }

            const hasTime = element.getAttribute('data-has-time') === '1';
            const formatter = new Intl.DateTimeFormat(userLocale, {
                ...buildIntlOptions(hasTime),
                timeZone: userTimezone,
                hour12: true
            });

            element.textContent = formatter.format(parsedDate);
        });
    });
</script>

<!-- Notification Detail Modal -->
<div class="modal fade" id="notificationDetailModal" tabindex="-1" aria-labelledby="notificationDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="notificationDetailModalLabel">Notification from <span id="modalSenderName"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="notification-modal-sender">
                    <img id="modalSenderAvatar" src="" alt="" class="rounded-circle" width="50" height="50" style="display:none;">
                    <div>
                        <div class="fw-bold" id="modalSenderNameFull"></div>
                        <small class="text-muted">@ <span id="modalNotificationTime"></span></small>
                    </div>
                </div>
                <hr>
                <div class="notification-modal-subject">
                    <strong>Subject:</strong> <span id="modalSubject"></span>
                </div>
                <div class="notification-modal-message mt-3">
                    <div id="modalMessage"></div>
                </div>
                <div class="notification-modal-action mt-3" id="modalActionBtn" style="display:none;">
                    <button type="button" class="btn btn-primary btn-sm" id="modalWorkflowBtn"></button>
                </div>
            </div>
            <div class="modal-footer d-flex justify-content-between">
                <div>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="modalPrevBtn" onclick="navigateNotification('prev')">
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="modalNextBtn" onclick="navigateNotification('next')">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-primary btn-sm" id="modalUnreadBtn" onclick="markCurrentNotificationUnread()"><i class="fas fa-envelope"></i> Mark unread</button>
                    <button type="button" class="btn btn-danger btn-sm" id="modalDeleteBtn" onclick="deleteCurrentNotification()"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Enhanced Notification Styles */
.notification-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    border-bottom: 1px solid #e5e7eb;
    font-weight: 600;
}

.notification-count {
    background: #3b82f6;
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    min-width: 20px;
    text-align: center;
}

.notification-list {
    max-height: 400px;
    overflow-y: auto;
}

.notification-item {
    display: flex;
    align-items: center;
    padding: 12px 16px;
    border-bottom: 1px solid #f3f4f6;
    cursor: pointer;
    position: relative;
    transition: background 0.2s;
}

.notification-item:hover {
    background: #f9fafb;
}

.notification-item.unread {
    background: #eff6ff;
}

.notification-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    overflow: hidden;
    flex-shrink: 0;
    margin-right: 12px;
}

.notification-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.notification-avatar-initial {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3b82f6;
    color: white;
    font-weight: 600;
    font-size: 16px;
}

.notification-content {
    flex: 1;
    min-width: 0;
}

.notification-sender {
    font-weight: 600;
    font-size: 14px;
    color: #1e293b;
    margin-bottom: 4px;
}

.notification-message {
    font-size: 13px;
    color: #64748b;
    margin: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}

.notification-time {
    font-size: 11px;
    color: #94a3b8;
}

.notification-status-dot {
    width: 8px;
    height: 8px;
    background: #3b82f6;
    border-radius: 50%;
    flex-shrink: 0;
    margin: 0 8px;
}

.notification-delete-btn {
    background: none;
    border: none;
    color: #94a3b8;
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 4px;
    transition: all 0.2s;
    flex-shrink: 0;
    z-index: 10;
}

.notification-delete-btn:hover {
    background: #fee2e2;
    color: #dc2626;
}

.notification-footer {
    padding: 12px 16px;
    border-top: 1px solid #e5e7eb;
    text-align: center;
}

.notification-footer a {
    color: #3b82f6;
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
}

.notification-footer a:hover {
    text-decoration: underline;
}

/* Notification Modal Styles */
.notification-modal-sender {
    display: flex;
    align-items: center;
    gap: 12px;
}

.notification-modal-subject {
    padding: 12px;
    background: #f9fafb;
    border-radius: 6px;
}

.notification-modal-message {
    line-height: 1.6;
}

/* Dark theme support for notification modal */
[data-theme="dark"] .notification-item.unread {
    background: #1e3a5f;
}

[data-theme="dark"] .notification-sender {
    color: #e0e0e0;
}

[data-theme="dark"] .notification-message {
    color: #aaa;
}

[data-theme="dark"] .notification-modal-subject {
    background: #1e1e38;
}

[data-theme="dark"] .notification-footer {
    border-top-color: #2a2a45;
}

[data-theme="dark"] .notification-count {
    background: #4f6ef7;
}

[data-theme="dark"] .notification-time {
    color: #888;
}
</style>

<script>
// Notification System JavaScript
let currentNotificationId = null;
let currentNotificationData = null;

function escapeNotificationText(value) {
    const node = document.createElement('div');
    node.textContent = value ?? '';
    return node.innerHTML;
}

function renderNotificationModalContent(data) {
    const message = document.getElementById('modalMessage');
    const action = document.getElementById('modalActionBtn');
    const button = document.getElementById('modalWorkflowBtn');
    const ticket = data.concern_context;

    if (!ticket) {
        message.textContent = data.message || '';
        action.style.display = 'none';
        return;
    }

    const timing = [
        ticket.assigned_at ? '<p><strong>Assigned:</strong> ' + escapeNotificationText(ticket.assigned_at) + '</p>' : '',
        ticket.in_progress_at ? '<p><strong>Work started:</strong> ' + escapeNotificationText(ticket.in_progress_at) + '</p>' : '',
        ticket.resolved_at ? '<p><strong>Resolved:</strong> ' + escapeNotificationText(ticket.resolved_at) + '</p>' : ''
    ].join('');

    message.innerHTML = `
        <div class="border rounded-3 p-3 text-start">
            <div class="d-flex justify-content-between align-items-start gap-2 border-bottom pb-2 mb-3">
                <strong>${escapeNotificationText(ticket.title)}</strong>
                <span class="badge bg-secondary">${escapeNotificationText(ticket.status)}</span>
            </div>
            <div class="row g-2 small">
                <div class="col-md-6"><p><strong>Report #:</strong> #${String(ticket.report_id || ticket.id).padStart(4, '0')}</p><p><strong>Category:</strong> ${escapeNotificationText(ticket.category)}</p><p><strong>Location:</strong> ${escapeNotificationText(ticket.location)}</p></div>
                <div class="col-md-6"><p><strong>Reported by:</strong> ${escapeNotificationText(ticket.reported_by)}</p><p><strong>Date submitted:</strong> ${escapeNotificationText(ticket.created_at || 'N/A')}</p><p><strong>Report count:</strong> ${escapeNotificationText(ticket.report_count)}</p></div>
            </div>
            <hr><p><strong>Description:</strong></p><p class="mb-2" style="white-space:pre-wrap">${escapeNotificationText(ticket.description)}</p>
            ${ticket.details ? '<p><strong>Additional details:</strong></p><p class="mb-2" style="white-space:pre-wrap">' + escapeNotificationText(ticket.details) + '</p>' : ''}
            ${ticket.damaged_part ? '<p><strong>Damaged part:</strong> ' + escapeNotificationText(ticket.damaged_part) + '</p>' : ''}
            ${timing}
        </div>`;

    if (!ticket.can_manage || ['Resolved', 'Closed'].includes(ticket.status)) {
        action.style.display = 'none';
        return;
    }

    const labels = {
        'Pending': ['btn-primary', '<i class="fas fa-user-plus"></i> Assign'],
        'Assigned': ['btn-warning', '<i class="fas fa-play"></i> Start work'],
        'In Progress': ['btn-success', '<i class="fas fa-check"></i> Complete / Resolve']
    };
    const label = labels[ticket.status];
    if (!label) { action.style.display = 'none'; return; }
    button.className = 'btn btn-sm ' + label[0];
    button.innerHTML = label[1];
    button.onclick = () => handleNotificationWorkflow(ticket);
    action.style.display = 'block';
}

function notificationWorkflowRequest(url, payload) {
    return fetch(url, { method: 'POST', headers: { 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content, 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(payload) })
        .then(async response => {
            const data = await response.json().catch(() => ({}));
            if (!response.ok || !data.success) throw new Error(data.error || data.message || 'Unable to update this report.');
            return data;
        });
}

function refreshNotificationWorkflow(message) {
    return Swal.fire({ icon: 'success', title: 'Updated', text: message, timer: 1300, showConfirmButton: false })
        .then(() => openNotificationModal(currentNotificationId));
}

function handleNotificationWorkflow(ticket) {
    if (ticket.status === 'Pending') return assignNotificationReport(ticket);
    if (ticket.status === 'Assigned') {
        return notificationWorkflowRequest('/reports/' + ticket.report_id + '/update-status', { status: 'In Progress' })
            .then(data => refreshNotificationWorkflow(data.message))
            .catch(error => Swal.fire({ icon: 'error', title: 'Unable to start work', text: error.message }));
    }
    if (ticket.status === 'In Progress') return completeNotificationReport(ticket);
}

function assignNotificationReport(ticket) {
    const technology = String(ticket.category || '').trim().toLowerCase() === 'technology/internet';
    const endpoint = technology ? '/admin/mis-users' : '/admin/maintenance-users';
    const label = technology ? 'MIS staff' : 'maintenance staff';
    fetch(endpoint, { headers: { 'Accept': 'application/json' } })
        .then(response => response.json())
        .then(data => {
            if (!data.users?.length) throw new Error('No active ' + label + ' is available. Add or activate one in Management first.');
            const options = data.users.map(person => '<option value="' + person.id + '">' + escapeNotificationText(person.name) + '</option>').join('');
            return Swal.fire({
                title: 'Assign report',
                html: '<label class="form-label d-block text-start">Assign to</label><select id="notificationAssignee" class="swal2-select"><option value="">Select ' + label + '</option>' + options + '</select>' +
                    '<label class="form-label d-block text-start mt-3">Priority</label><select id="notificationPriority" class="swal2-select"><option value="">Select priority</option><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="urgent">Urgent</option><option value="safety_hazard">Safety hazard</option></select>',
                showCancelButton: true,
                confirmButtonText: 'Assign',
                preConfirm: () => {
                    const assignedTo = document.getElementById('notificationAssignee').value;
                    const priority = document.getElementById('notificationPriority').value;
                    if (!assignedTo || !priority) {
                        Swal.showValidationMessage('Select both a staff member and priority.');
                        return false;
                    }
                    return { assigned_to: assignedTo, priority };
                }
            }).then(result => result.isConfirmed ? notificationWorkflowRequest('/admin/report/' + ticket.report_id + '/assign', result.value) : null);
        })
        .then(data => data && refreshNotificationWorkflow(data.message))
        .catch(error => Swal.fire({ icon: 'error', title: 'Unable to assign report', text: error.message }));
}

function completeNotificationReport(ticket) {
    Swal.fire({ title: 'Complete report', html: '<textarea id="notificationResolutionNotes" class="swal2-textarea" placeholder="Resolution notes (optional)"></textarea><input id="notificationCost" type="number" min="0" step="0.01" class="swal2-input" placeholder="Recorded cost (optional)"><input id="notificationDamagedPart" class="swal2-input" placeholder="Damaged part (optional)"><input id="notificationReplacedPart" class="swal2-input" placeholder="Replaced part (optional)">', showCancelButton: true, confirmButtonText: 'Mark resolved', confirmButtonColor: '#198754', preConfirm: () => ({ status: 'Resolved', resolution_notes: document.getElementById('notificationResolutionNotes').value.trim(), cost: document.getElementById('notificationCost').value || null, damaged_part: document.getElementById('notificationDamagedPart').value.trim(), replaced_part: document.getElementById('notificationReplacedPart').value.trim() }) })
        .then(result => result.isConfirmed && notificationWorkflowRequest('/reports/' + ticket.report_id + '/update-status', result.value)
            .then(data => refreshNotificationWorkflow(data.message))
            .catch(error => Swal.fire({ icon: 'error', title: 'Unable to complete report', text: error.message })));
}

// Open notification modal
async function openNotificationModal(notificationId, event) {
    if (event) {
        event.stopPropagation();
        // Check if delete button was clicked
        if (event.target.closest('.notification-delete-btn')) {
            return;
        }
    }
    
    currentNotificationId = notificationId;
    
    // Check if modal is already open
    const modalElement = document.getElementById('notificationDetailModal');
    const existingModal = bootstrap.Modal.getInstance(modalElement);
    const isModalOpen = existingModal && modalElement.classList.contains('show');
    
    try {
        const response = await fetch(`/notifications/${notificationId}`, {
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'application/json'
            }
        });
        
        if (!response.ok) throw new Error('Failed to fetch notification');
        
        const data = await response.json();
        currentNotificationData = data;
        
        // Populate modal
        document.getElementById('modalSenderName').textContent = data.sender?.name || 'System';
        document.getElementById('modalSenderNameFull').textContent = data.sender?.name || 'System';
        document.getElementById('modalNotificationTime').textContent = data.created_at;
        document.getElementById('modalSubject').textContent = data.title;
        renderNotificationModalContent(data);
        
        // Set avatar
        const avatar = document.getElementById('modalSenderAvatar');
        if (data.sender?.profile_picture) {
            avatar.src = data.sender.profile_picture;
            avatar.style.display = 'block';
        } else {
            avatar.style.display = 'none';
        }
        
        
        // Enable/disable navigation buttons
        document.getElementById('modalPrevBtn').disabled = !data.prev_id;
        document.getElementById('modalNextBtn').disabled = !data.next_id;
        
        // Mark as read
        await fetch(`/notifications/${notificationId}/read`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'application/json'
            }
        });
        
        // Update UI to show as read
        const notifItem = document.querySelector(`.notification-item[onclick*="${notificationId}"]`);
        if (notifItem) {
            notifItem.classList.remove('unread');
            const statusDot = notifItem.querySelector('.notification-status-dot');
            if (statusDot) statusDot.remove();
        }
        
        // Update badge count
        updateNotificationCount();
        
        // Show modal only if it's not already open
        if (!isModalOpen) {
            const modal = new bootstrap.Modal(modalElement);
            modal.show();
            
            // Close notification dropdown
            const dropdown = document.getElementById('notificationDropdown');
            if (dropdown) dropdown.classList.remove('show');
        }
        
    } catch (error) {
        console.error('Error loading notification:', error);
        showNotificationToast('Failed to load notification', 'error');
    }
}

// Navigate to prev/next notification
async function navigateNotification(direction) {
    const targetId = direction === 'prev' ? currentNotificationData.prev_id : currentNotificationData.next_id;
    if (targetId) {
        currentNotificationId = targetId;
        
        try {
            const response = await fetch(`/notifications/${targetId}`, {
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json'
                }
            });
            
            if (!response.ok) throw new Error('Failed to fetch notification');
            
            const data = await response.json();
            currentNotificationData = data;
            
            // Update modal content without creating new instance
            document.getElementById('modalSenderName').textContent = data.sender?.name || 'System';
            document.getElementById('modalSenderNameFull').textContent = data.sender?.name || 'System';
            document.getElementById('modalNotificationTime').textContent = data.created_at;
            document.getElementById('modalSubject').textContent = data.title;
            renderNotificationModalContent(data);
            
            // Update avatar
            const avatar = document.getElementById('modalSenderAvatar');
            if (data.sender?.profile_picture) {
                avatar.src = data.sender.profile_picture;
                avatar.style.display = 'block';
            } else {
                avatar.style.display = 'none';
            }
            
            
            // Update navigation buttons
            document.getElementById('modalPrevBtn').disabled = !data.prev_id;
            document.getElementById('modalNextBtn').disabled = !data.next_id;
            
            // Mark as read
            await fetch(`/notifications/${targetId}/read`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json'
                }
            });
            
            // Update UI to show as read in the dropdown list
            const notifItem = document.querySelector(`.notification-item[onclick*="${targetId}"]`);
            if (notifItem) {
                notifItem.classList.remove('unread');
                const statusDot = notifItem.querySelector('.notification-status-dot');
                if (statusDot) statusDot.remove();
            }
            
            // Update badge count
            updateNotificationCount();
            
        } catch (error) {
            console.error('Error navigating notification:', error);
            showNotificationToast('Failed to load notification', 'error');
        }
    }
}

// Mark the open notification as unread so it returns to the unread list.
async function markCurrentNotificationUnread() {
    if (!currentNotificationId) return;

    try {
        const response = await fetch(`/notifications/${currentNotificationId}/unread`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'application/json'
            }
        });
        if (!response.ok) throw new Error('Failed to mark notification as unread');

        const notificationItem = document.querySelector(`.notification-item[onclick*="${currentNotificationId}"]`);
        if (notificationItem) notificationItem.classList.add('unread');
        updateNotificationCount();
        showNotificationToast('Notification marked as unread', 'success');
    } catch (error) {
        console.error('Error marking notification as unread:', error);
        showNotificationToast('Failed to mark notification as unread', 'error');
    }
}

// Delete current notification in modal
async function deleteCurrentNotification() {
    if (!currentNotificationId) return;
    
    if (!confirm('Are you sure you want to delete this notification?')) return;
    
    try {
        const response = await fetch(`/notifications/${currentNotificationId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'application/json'
            }
        });
        
        if (!response.ok) throw new Error('Failed to delete notification');
        
        // Remove from list
        const notifItem = document.querySelector(`.notification-item[onclick*="${currentNotificationId}"]`);
        if (notifItem) notifItem.remove();
        
        // Check if there are any notifications left
        const notificationList = document.querySelector('.notification-list');
        const remainingNotifications = notificationList.querySelectorAll('.notification-item');
        
        if (remainingNotifications.length === 0) {
            notificationList.innerHTML = `
                <div class="notification-empty">
                    <i class="fas fa-bell-slash"></i>
                    <p>No notifications</p>
                </div>
            `;
            // Hide footer
            const footer = document.querySelector('.notification-footer');
            if (footer) footer.style.display = 'none';
        }
        
        // Update count
        updateNotificationCount();
        
        // Close modal
        const modalElement = document.getElementById('notificationDetailModal');
        const modalInstance = bootstrap.Modal.getInstance(modalElement);
        if (modalInstance) modalInstance.hide();
        
        // Show success message
        showNotificationToast('Notification deleted successfully', 'success');
        
    } catch (error) {
        console.error('Error deleting notification:', error);
        showNotificationToast('Failed to delete notification', 'error');
    }
}

// Delete notification from list
async function deleteNotification(notificationId, event) {
    event.stopPropagation();
    
    if (!confirm('Are you sure you want to delete this notification?')) return;
    
    try {
        const response = await fetch(`/notifications/${notificationId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'application/json'
            }
        });
        
        if (!response.ok) throw new Error('Failed to delete notification');
        
        // Remove from list
        const notifItem = event.target.closest('.notification-item');
        if (notifItem) notifItem.remove();
        
        // Check if there are any notifications left
        const notificationList = document.querySelector('.notification-list');
        const remainingNotifications = notificationList.querySelectorAll('.notification-item');
        
        if (remainingNotifications.length === 0) {
            notificationList.innerHTML = `
                <div class="notification-empty">
                    <i class="fas fa-bell-slash"></i>
                    <p>No notifications</p>
                </div>
            `;
            // Hide footer
            const footer = document.querySelector('.notification-footer');
            if (footer) footer.style.display = 'none';
        }
        
        // Update count
        updateNotificationCount();
        
        showNotificationToast('Notification deleted successfully', 'success');
        
    } catch (error) {
        console.error('Error deleting notification:', error);
        showNotificationToast('Failed to delete notification', 'error');
    }
}

// Update notification badge count
async function updateNotificationCount() {
    try {
        const response = await fetch('/notifications/unread-count');
        const data = await response.json();
        const badge = document.querySelector('.notification-badge');
        const headerCount = document.querySelector('.notification-count');
        
        if (data.count > 0) {
            if (badge) {
                badge.textContent = data.count;
                badge.style.display = 'flex';
            }
            if (headerCount) headerCount.textContent = data.count;
        } else {
            if (badge) badge.style.display = 'none';
            if (headerCount) headerCount.textContent = '0';
        }
    } catch (error) {
        console.error('Error updating notification count:', error);
    }
}

// Simple toast notification
function showNotificationToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = 'notification-toast';
    toast.textContent = message;
    
    const bgColor = type === 'success' ? '#28a745' : '#dc3545';
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${bgColor};
        color: white;
        padding: 12px 20px;
        border-radius: 6px;
        z-index: 99999;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function openAllNotifications(event) {
    event.preventDefault();
    event.stopPropagation();
    // For now, just show an alert. You can create a dedicated page later
    showNotificationToast('All notifications page - coming soon!', 'success');
}

// Add animation keyframes
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
</script>

<!-- Push Notifications -->
<script src="{{ asset('js/push-notifications.js') }}"></script>
<script>
// Initialize push notifications when user is logged in
@auth
document.addEventListener('DOMContentLoaded', async function() {
    const vapidPublicKey = '{{ env('VAPID_PUBLIC_KEY') }}';
    
    if (vapidPublicKey && vapidPublicKey !== '') {
        // Initialize push notifications
        const initialized = await PushNotifications.init(vapidPublicKey);
        
        if (initialized) {
            // Check if already subscribed
            const isSubscribed = await PushNotifications.isSubscribed();
            
            // Auto-subscribe if not subscribed and permission granted
            if (!isSubscribed && Notification.permission === 'granted') {
                await PushNotifications.subscribe();
            }
            
            // Show subscribe button/prompt if not subscribed
            if (!isSubscribed && Notification.permission === 'default') {
                // You can show a prompt here to ask user to enable notifications
                console.log('Push notifications available - user can subscribe');
            }
        }
    }
});
@endauth
</script>

<script src="{{ asset('js/asset-replacement.js') }}"></script>
@yield('scripts')

</body>
</html>
